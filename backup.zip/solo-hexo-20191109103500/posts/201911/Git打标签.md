title: Git打标签
date: '2019-11-06 14:40:20'
updated: '2019-11-06 14:40:20'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573022420336.html
---
# Git打标签
像其他版本控制系统（VCS）一样，Git可以给历史中的某一个提交（commit）打上标签，标识这个commit重要，必要有代表性的是人们会使用这个功能来标记发布节点（V1.0等等，用来标识是测试版还是稳定版）

## 标签和指针的区别
1. 分支的指针是一个 可变的指针，随着每次commit他会都重新指向
2. 标签的指针是不可变得

## 列出当前标签 git tag

```bash
[root@zsf_node3 ~]# cd git_test/
[root@zsf_node3 git_test]# git tag
[root@zsf_node3 git_test]# 
// 当没有标签的时候输入 git tag是没有任何输出信息
```

通配符查看标签

```bash
// 只查看给V1 版本相关的版本
[root@zsf_node3 git_test]# git tag -l 'V1.*'
```

列出某个标签信息与对应的提交信息

```bash
[root@zsf_node3 git_test]# git tag -a V1.0 -m "my version 1.0"
[root@zsf_node3 git_test]# git tag 
V1.0git
[root@zsf_node3 git_test]# git show V1.0 
tag V1.0                                //标签版本信息
Tagger: zhangshoufu <18163201@qq.com>   //打标签的用户
Date:   Sat Nov 10 09:14:48 2018 +0800  //打标签的时间

my version 1.0                          //打标签时-m指定的说明信息

commit 8029914d93e4ad00868dc33dddeca674ebaf56d6     //commit_id信息
Author: zhangshoufu <18163201@qq.com>
Date:   Fri Nov 9 15:09:53 2018 +0800

    change node1

diff --git a/node1_file b/node1_file
new file mode 100644
index 0000000..e69de29
```

## 创建标签
Git使用两种主要类型的标签：
1. 轻量标签(Light-weight)：轻量标签很像一个不会改变的分支-它只是一个特定提交的引用。

2. 附注标签(annotated)：附注标签是存储在Git数据库中的一个完整对象。他们可以是被校验的；其中包含打标签者的名字、电子邮件地址、日期时间；还有一个标签信息；并且可以使用 GNU Privacy Vuard(GPG)签名与验证。通常建议创建附注标签，这样你可以拥有以上所有的信息；但是如果你只是想用一个临时的标签，或者因为某些原因不详保存那些信息，轻量标签也是可以的

**1) 附注标签**
创建附注标签最简单的就是在运行tag命令的时候指定-a选项

```bash
//如果没有执行commit_id 那个就按照现在HEAD指向的地方打标签
[root@zsf_node3 git_test]# git tag -a V1.0 -m "my version 1.0"
[root@zsf_node3 git_test]# git tag 
V1.0
```

**2）轻量标签**
轻量标签本质上将提交检验和存储到一个文件中-没有保存热河其他信息。创建轻量标签，不需要使用`-a`、`-s`或`-m`选项，只需要提供标签名字：
