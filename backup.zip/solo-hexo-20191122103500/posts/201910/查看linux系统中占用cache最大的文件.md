title: 查看linux系统中占用cache最大的文件
date: '2019-10-28 09:35:06'
updated: '2019-10-28 09:35:06'
tags: [scripts, Linux技巧]
permalink: /articles/2019/10/28/1572226506215.html
---
#查看linux系统中占用cache最大的文件
```bash
#!/bin/bash
export PATH=$PATH

#判断pcstat命令是否安装，如果没安装安装上
which pcstat 2>&1 /dev/null
if [ $? -ne 0 ];the
    echo "You have not installed the 'pcstat' command and will install it after 5 seconds;"
    if [ `uname -m` == "x86_64" ];then
        curl -L -o pcstat https://github.com/tobert/pcstat/raw/2014-05-02-01/pcstat.x86_64
    else
        curl -L -o pcstat https://github.com/tobert/pcstat/raw/2014-05-02-01/pcstat.x86_32
    fi
    mv ./pcstat /usr/local/bin
    chmod 755 /usr/local/bin/pcstat
fi

#查找使用内存占用率最大的十个程序,并获取他们的Pid，写入到一个文件内
#ps -e -o pid.rss 显示当前系统中运行程序的Pid和rss(内存使用),并排序
ps -e -o pid,rss|sort -nk2 -r|head -10 |awk '{print $1}'>/tmp/cache.pids

#删除上一次执行过后留下的文件
if [ -f /tmp/cache.files ]
then
    echo "the cache.files is exist, removing now "
    rm -f /tmp/cache.files
fi

while read line
do
    #循环读每个进程号,按照Pid来查看当前进程打开来那些文件,宾把他们写到一个文件里面
    lsof -p $line 2>/dev/null|awk '{print $9}' >>/tmp/cache.files
done</tmp/cache.pids

if [ -f /tmp/cache.pcstat ]
then
    echo "the cache.pcstat is exist, removing now"
    rm -f /tmp/cache.pcstat
fi

#过滤出程序打开的文件,方便后面查看是那个文件占用cache大
for i in `cat /tmp/cache.files`
do
    if [ -f $i ]
    then
	if [ `wc -c $i | awk '{print $1}'` -ne 0 ];then
            echo $i >>/tmp/cache.pcstat
	fi
    fi
done

if [ -f /tmp/cache.output ];then
    echo "the cache.output is exist, removing now"
    rm -f /tmp/cache.output
fi

#查看每个文件占用Cache的资源
pcstat  `cat /tmp/cache.pcstat` >> /tmp/cache.output

#统计出前十个占用缓存最大的文件
cat /tmp/cache.output | sort -n -t '|' -k 4 -r | head -10
rm -f /tmp/cache.{pids,files,pcstat,output}

<<-'EOF'
查看某个文件被那个进程打开
lsof filename
EOF
```