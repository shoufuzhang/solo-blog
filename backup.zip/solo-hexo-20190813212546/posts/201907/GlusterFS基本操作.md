title: GlusterFS基本操作
date: '2019-07-17 21:48:46'
updated: '2019-07-17 21:48:46'
tags: [分布式存储, GlusterFS]
permalink: /articles/2019/07/17/1563371326510.html
---
# 基本操作
## 集群节点
### 扩展集群
1,必须做hosts域名解析
其实通过IP地址也能做集群,但是不建议这种方式.

```bash
192.168.1.210 glusterfs04
```
2, 添加节点到集群中,在当前所有集群节点中都需要执行
```bash
gluster  peer probe glusterfs04
```

3,查看对等状态

```bash
gluster peer status
```
### 查看集群节点信息

```bash
gluster pool list
```

### 删除节点
从集群中删除节点

```bash
gluster peer detach glusterfs04
```

## 卷
### 创建卷
####  distribute volume分布式卷(默认)
**命令:**
```bash
> gluster volume create NEW-VOLNAME [transport [tcp | rdma | tcp,rdma]] NEW-BRICK...
```
**示例:**
```bash
> gluster volume create test-volume  transport tcp glutserfs01:/guiji/pv1 gluster02:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data
```
####  Striped Glusterfs Volume 条带卷
 **命令:**
```bash
> gluster volume create NEW-VOLNAME [stripe COUNT] [transport [tcp | dma | tcp,rdma]] NEW-BRICK...
```
**示例:**

```bash
> gluster volume create test-volume stripe 2 transport tcp glutserfs01:/guiji/pv1 gluster02:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data
```
#### Replicated Glusterfs Volume 复制卷(最少两个节点)
**命令:**
```bash
> gluster volume create NEW-VOLNAME [replica COUNT] [transport [tcp | rdma | tcp,rdma]] NEW-BRICK...
```
**示例:**

```bash
> gluster volume create test-volume replica 2 glutserfs01:/guiji/pv1 gluster02:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data
```

#### Distributed Replicated Glusterfs Volume  分布式复制卷
**命令:**
```bash
> gluster volume create NEW-VOLNAME [replica COUNT] [transport [tcp | rdma | tcp，rdma]] NEW-BRICK ......
```
**示例:**
两个节点组成分布式,镜像3份

```bash
>  gluster volume create test-volume replica 3 transport tcp glutserfs01:/guiji/pv1 gluster02:/guiji/pv1 glutserfs03:/guiji/pv1 gluster04:/guiji/pv1 glutserfs05:/guiji/pv1 glusterfs06:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data
```
glusterfs01和glusterfs02 组成分布式
glusterfs03和glusterfs04 组成分布式
glusterfs05和glusterfs06 组成分布式
然后在组成镜像

三个节点分布式镜像2份

```bash
>  gluster volume create test-volume replica 2 transport tcp glutserfs01:/guiji/pv1 gluster02:/guiji/pv1 glutserfs03:/guiji/pv1 gluster04:/guiji/pv1 glutserfs05:/guiji/pv1 glusterfs06:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data
```
glusterfs01 和glusterfs02 和glusterfs03 组成分布式
glusterfs04 和glusterfs05 和glusterfs06 组成分布式
然后在组成镜像

#### Distributed Striped Glusterfs Volume 分布式条带卷
先组条带在组分布
**命令:**
```bash
> gluster volume create NEW-VOLNAME [stripe COUNT] [transport [tcp | rdma | tcp,rdma]] NEW-BRICK...
```
**示例:**

```bash
> gluster volume create test-volume stripe 4 transport tcp
 glutserfs01:/guiji/pv1 glutserfs02:/guiji/pv1 glutserfs03:/guiji/pv1 glutserfs04:/guiji/pv1 glutserfs05:/guiji/pv1 glutserfs06:/guiji/pv1 glutserfs07:/guiji/pv1 glutserfs08:/guiji/pv1
Creation of test-volume has been successful
Please start the volume to access data.
```
前4个组成一个条带,然后在组成分布式,组成多少分布式和条带式根据条带数量完成的

### 

## 性能分析
### 开启性能分析

```bash
> gluster volume profile VOLUME_NAME start
```

### 显示I/O信息:

```bash
> gluster volume profile gv0 info
Brick: glusterfs01:/guiji/gv0
-----------------------------
Cumulative Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us            100     RELEASE
      0.00       0.00 us       0.00 us       0.00 us            559  RELEASEDIR
      0.24       1.35 us       1.26 us       1.47 us              3     OPENDIR
      9.77      55.54 us      32.78 us      75.29 us              3      LOOKUP
     14.98      63.89 us      26.12 us     119.58 us              4    GETXATTR
     75.01     213.27 us     156.84 us     320.37 us              6     READDIR

    Duration: 107828 seconds
   Data Read: 0 bytes
Data Written: 0 bytes

Interval 4 Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us              3  RELEASEDIR
      0.24       1.35 us       1.26 us       1.47 us              3     OPENDIR
      9.77      55.54 us      32.78 us      75.29 us              3      LOOKUP
     14.98      63.89 us      26.12 us     119.58 us              4    GETXATTR
     75.01     213.27 us     156.84 us     320.37 us              6     READDIR

    Duration: 740 seconds
   Data Read: 0 bytes
Data Written: 0 bytes

Brick: glusterfs02:/guiji/gv0
-----------------------------
Cumulative Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us            100     RELEASE
      0.00       0.00 us       0.00 us       0.00 us            554  RELEASEDIR
      0.52       3.71 us       1.48 us      14.44 us              6     OPENDIR
     11.62      82.22 us      37.44 us     147.80 us              6      LOOKUP
     12.57      66.66 us      18.57 us     142.96 us              8    GETXATTR
     75.29     266.29 us     179.21 us     344.17 us             12     READDIR

    Duration: 107826 seconds
   Data Read: 0 bytes
Data Written: 0 bytes

Interval 4 Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us              3  RELEASEDIR
      0.94       5.85 us       1.48 us      14.44 us              3     OPENDIR
      8.43      52.64 us      37.44 us      66.05 us              3      LOOKUP
     10.73      50.29 us      18.57 us      94.86 us              4    GETXATTR
     79.91     249.63 us     191.09 us     344.17 us              6     READDIR

    Duration: 740 seconds
   Data Read: 0 bytes
Data Written: 0 bytes

Brick: glusterfs03:/guiji/gv0
-----------------------------
Cumulative Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us            100     RELEASE
      0.00       0.00 us       0.00 us       0.00 us            554  RELEASEDIR
      0.29       1.93 us       1.43 us       2.35 us              6     OPENDIR
      8.94      45.14 us      11.47 us      90.38 us              8    GETXATTR
     11.13      74.94 us      53.80 us      99.02 us              6      LOOKUP
     79.65     268.26 us     183.24 us     391.81 us             12     READDIR

    Duration: 107826 seconds
   Data Read: 0 bytes
Data Written: 0 bytes

Interval 4 Stats:
 %-latency   Avg-latency   Min-Latency   Max-Latency   No. of calls         Fop
 ---------   -----------   -----------   -----------   ------------        ----
      0.00       0.00 us       0.00 us       0.00 us              3  RELEASEDIR
      0.35       2.14 us       1.89 us       2.35 us              3     OPENDIR
     10.78      66.56 us      53.80 us      87.93 us              3      LOOKUP
     11.22      51.96 us      29.15 us      65.53 us              4    GETXATTR
     77.65     239.74 us     183.24 us     307.17 us              6     READDIR

    Duration: 739 seconds
   Data Read: 0 bytes
Data Written: 0 bytes
```