title: podman初试-和docker对比,简单使用
date: '2019-11-05 11:53:53'
updated: '2019-11-05 11:53:53'
tags: [podman]
permalink: /articles/2019/11/05/1572926032968.html
---
# podman初试-和docker对比
## 1，什么是docker？
Docker 是一个开源的应用容器引擎，属于 Linux 容器的一种封装，Docker 提供简单易用的容器使用接口，让开发者可以打包他们的应用以及依赖包到一个可移植的容器中，然后发布到任何流行的 Linux 机器上。容器是完全使用沙箱机制，相互之间不会有任何接口。

## 2，什么是Podman？
Podman 是一个开源的容器运行时项目，可在大多数 Linux 平台上使用。Podman 提供与 Docker 非常相似的功能。正如前面提到的那样，它不需要在你的系统上运行任何守护进程，并且它也可以在没有 root 权限的情况下运行。
Podman 可以管理和运行任何符合 OCI（Open Container Initiative）规范的容器和容器镜像。Podman 提供了一个与 Docker 兼容的命令行前端来管理 Docker 镜像。

> 1. Podman 官网地址：https://podman.io/
> 2. Podman 项目地址：https://github.com/containers/libpod

## 3，Podman 和docker不同之处？
1. docker 需要在我们的系统上运行一个守护进程(docker daemon)，而podman 不需要
2. 启动容器的方式不同：
`docker cli` 命令通过API跟 `Docker Engine(引擎)`交互告诉它我想创建一个container，然后`docker Engine`才会调用`OCI container runtime(runc)`来启动一个container。这代表container的process(进程)不会是`Docker CLI`的`child process(子进程)`，而是`Docker Engine`的`child process`。
`Podman`是直接给`OCI containner runtime(runc)`进行交互来创建container的，所以`container process`直接是`podman`的`child process`。
3. 因为docke有docker daemon，所以docker启动的容器支持`--restart`策略，但是podman不支持，如果在k8s中就不存在这个问题，我们可以设置pod的重启策略，在系统中我们可以采用编写systemd服务来完成自启动
4. docker需要使用root用户来创建容器，但是podman不需要

## 4，podman的安装
### 4.1，Arch Linux & Manjaro Linux

```bash
sudo pacman -S podman
```
### 4.2，Fedora，Centos

```bash
sudo yum -y install podman
```
### 4.3，Gentoo

```bash
sudo emerge app-emulation/libpod
```

### 4.4，MacOS

```bash
brew cask install podman
```

## 5，Podman CLI介绍
Podman CLI 里面87%的指令都和DOcker CLI 相同，官方给出了这么个例子`alias docker=podman`,所以说经常使用DOcker CLI的人使用podman上手非常快
### 运行一个容器

```bash
podman run -dt -p 80:80 --name nginx -v /data:/data -e NGINX_VERSION=1.16 nginx:1.16.0
```
### 列出当前所有的容器

```bash
# podman  ps -a
CONTAINER ID  IMAGE                                       COMMAND               CREATED            STATUS             PORTS               NAMES
19f105d5dc1e  docker.io/library/nginx:1.16.0              nginx -g daemon o...  2 minutes ago      Up 2 minutes ago   0.0.0.0:80->80/tcp  nginx
```
### 查看一个镜像信息

```bash
# podman inspect nginx  | grep -i "ipaddress"
            "SecondaryIPAddresses": null,
            "IPAddress": "10.88.0.110",
```

### 查看容器运行的日志

```bash
podman logs   nginx
```

### 查看运行中容器资源使用情况

```bash
# podman  top nginx
USER    PID   PPID   %CPU    ELAPSED           TTY     TIME   COMMAND
root    1     0      0.000   5m26.420969043s   pts/0   0s     nginx: master process nginx -g daemon off;
nginx   6     1      0.000   5m26.421085502s   pts/0   0s     nginx: worker process

# podman  stats nginx
ID             NAME    CPU %   MEM USAGE / LIMIT   MEM %   NET IO           BLOCK IO   PIDS
19f105d5dc1e   nginx   --      2.036MB / 1.893GB   0.11%   978B / 10.55kB   -- / --    2
```

## 迁移容器
Podman 支持将容器从一台机器迁移到另一台机器。
首先，在源机器上对容器设置检查点，并将容器打包到指定位置。

```bash
$ sudo podman container checkpoint <container_id> -e /tmp/checkpoint.tar.gz
$ scp /tmp/checkpoint.tar.gz <destination_system>:/tmp
```
其次，在目标机器上使用源机器上传输过来的打包文件对容器进行恢复。

```bash
$ sudo podman container restore -i /tmp/checkpoint.tar.gz
```

## podman的程序如何设置自启动
由于 Podman 不再使用守护进程管理服务，所以不能通过守护进程去实现自动重启容器的功能。那如果要实现开机自动重启容器，又该如何实现呢？
其实方法很简单，现在大多数系统都已经采用 Systemd 作为守护进程管理工具。这里我们就可以使用 Systemd 来实现 Podman 开机重启容器，这里我们以刚才启动的nginx为例。
建立一个 Systemd 服务配置文件。
```bash
$ vim /etc/systemd/system/nginx_podman.service

[Unit]
Description=Podman Nginx Service
After=network.target
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/podman start -a nginx
ExecStop=/usr/bin/podman stop -t 10 nginx
Restart=always

[Install]
WantedBy=multi-user.target
```
接下来，启用这个 Systemd 服务

```bash
$ sudo systemctl daemon-reload
$ sudo systemctl enable nginx_podman.service
$ sudo systemctl start nginx_podman.service
```
之后每次系统重启后 Systemd 都会自动启动这个服务所对应的容器，容器死亡之后也会启动这个容器，我们可以用下面的例子做测试
打一个sleep 30的docker包，这个容器运行起来一次只能坚持30s
```yaml
$ vim Dockerfile
FROM busybox:latest
CMD ["sh","-c","sleep 30"]
```
然后按照上述方式设置启动自启动

## 演示下Podman 下启动的容器为Podman的子进程
我们刚才启动了一个nginx的podman 现在我们来看一下他的进程

```bash
# ps -ef | grep [n]ginx
root     19368 19359  0 11:38 pts/0    00:00:00 nginx: master process nginx -g daemon off;
101      19381 19368  0 11:38 pts/0    00:00:00 nginx: worker process
```
然后查看这个nginx的父进程是那个

```bash
# ps -ef | grep 19359
root     19359     1  0 11:38 ?        00:00:00 /usr/libexec/podman/conmon 。。。。
```
所以验证了我上面的说法