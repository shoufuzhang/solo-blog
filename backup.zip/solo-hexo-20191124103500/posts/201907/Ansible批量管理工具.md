title: Ansible 批量管理工具
date: '2019-07-19 18:03:54'
updated: '2019-07-19 18:03:54'
tags: [Ansible]
permalink: /articles/2019/07/19/1563530634282.html
---
# Ansible 批量管理工具
## Ansible软件特点
> 1.ansible不需要单独安装客户端，SSH相当于ansible客户端。
2.ansible不需要启动任何服务，仅需安装对应工具即可。
3.ansible依赖大量的python模块来实现批量管理。
> 4.ansible配置文件/etc/ansible/ansible.cfg

## Ansible内置变量
![image.png](https://img.hacpai.com/file/2019/07/image-854998ea.png)

## Ansible注意事项->提示颜色信息说明

> 翔黄色：对远程节点进行相应修改
帽子绿：对远程节点不进行相应修改，或者只是对远程节点信息进行查看
深红色：操作执行命令有异常
浅紫色：表示对命令执行发出警告信息（可能存在的问题，给你一下建议）

## ansible 的清单配置详解
**/etc/ansible/hosts 清单配置**
里面存放的是ansible能管理的是主机信息，里面有两个风格`INI`和`YAML`
> YAML示例
all:
  hosts:
    10.1.1.60:
    10.1.1.61:

> 上例相当于如下INI配置
10.1.1.60
10.1.1.61

> 先看一个INI风格的配置，示例如下
10.1.1.61
> 
[test1]
10.1.1.60
> 
[test2]
10.1.1.70
上述配置表示当前清单中有3台受管主机，主机61不属于任何组，主机60属于test1组，主机70属于test2组
> 
使用YAML语法进行同等效果的配置如下
注意，为了使缩进显得更加明显，此处每次缩进使用两个空格
all:
  hosts:
    10.1.1.61:
  children:
    test1:
      hosts:
        10.1.1.60:
    test2:
      hosts:
        10.1.1.70:
> 从上例可以看出，当直接在清单中创建组时，需要在all关键字内使用children关键字，而定义每个组时，有必须使用hosts关键字，指明组内的主机

> 仍然先写出INI风格的示例以作对比，如下
[proA]
10.1.1.60
> 
[proB]
10.1.1.70
> 
[pro:children]
proA
proB
> 
> 对应YAML格式的配置如下
all:
  children:
    pro:
      children:
        proA:
          hosts:
            10.1.1.60:
        proB:
          hosts:
            10.1.1.70:
> 上述配置表示，pro组有两个子组，分别为proA组和proB组，而这两个组分别有自己组内的主机。
> 
> test131 ansible_host=172.16.1.131 ansible_user=root ansible_port=22 ansible_ssh_private_key_file=/root/.ssh/test_id_rsa
> 上述写空格的地方一定不能省略
> all: 
  hosts:
    172.16.1.131
      test131:
        ansible_host: 172.16.1.131
        ansible_user: root
        ansible_port: 22
        ansible_ssh_private_key_file: /root/.ssh/test_id_rsa
> 上述冒号有空格一定千万要记住

## ansible  module 
获取ansible的所有module
`ansible-doc -l` 查看的是大概信息
获取ansible的某个模块的详细信息
`ansible-doc -s ping` 查看ping module的详细信息
##如果没有特殊指定，下面模块中的实例ansible的hosts文件如下
![image.png](https://img.hacpai.com/file/2019/07/image-ca02399f.png)

### fetch 拉取模块
![image.png](https://img.hacpai.com/file/2019/07/image-17c0b618.png)

把我们管理的两台服务器上的/etc/passwd文件拉取到本机的/tmp目录下
在命令行中我们可以这样写
![image.png](https://img.hacpai.com/file/2019/07/image-550fdb0d.png)

从返回信息可以看出，执行上述ansible命令后，主机test141和主机test131中的文件已经拉取成功，test141的passwd文件被拷贝到了本机的/tmp目录中，而且，ansible在/tmp目录中自动创建了目录结构 172.16.1.141/etc，由于我们是同时从多台受管主机中拉取相同名称的文件，所以ansible会自动为我们创建各个主机对应的目录，以区分存放不同主机中的同名文件

ansible具有幂等性，幂等性能够保证我们重复的执行一项操作时，得到的结果是相同的，我们再来回顾一下幂等性的概念。
**"幂等性"是什么意思：**
> 举个例子，你想把一个文件拷贝到目标主机的某个目录上，但是你不确定此目录中是否已经存在此文件，当你使用ansible完成这项任务时，就非常简单了，因为如果目标主机的对应目录中已经存在此文件，那么ansible则不会进行任何操作，如果目标主机的对应目录中并不存在此文件，ansible就会将文件拷贝到对应目录中，说白了，ansible是"以结果为导向的"，我们指定了一个"目标状态"，ansible会自动判断，"当前状态"是否与"目标状态"一致，如果一致，则不进行任何操作，如果不一致，那么就将"当前状态"变成"目标状态"，这就是"幂等性"，"幂等性"可以保证我们重复的执行同一项操作时，得到的结果是一样的。

我们就来实验一下，看看重复执行相同的ansible命令时，会得到什么效果，效果如下图：
![image.png](https://img.hacpai.com/file/2019/07/image-82468341.png)

从上图可以看出，返回信息仍然包含"SUCCESS"字样，证明ansible命令执行成功，不过很明显，这次的返回信息为"绿色"，而且细心如你一定发现了，这次绿色的返回信中，"changed"字段的值为false，而之前黄色的返回信息中，"changed"字段的值为true。

当返回信息为绿色时，"changed"为false，表示ansible没有进行任何操作，没有"改变什么"。
当返回信息为黄色时，"changed"为true，表示ansible执行了操作，"当前状态"已经被ansible改变成了"目标状态"。

> 这就是幂等性的体现，当第一次执行上述命令时，ansible发现当前主机中并没有我们需要的passwd文件，ansible就会按照我们指定的操作，拉取passwd文件，也就是说，ansible"改变"了"当前状态"，将当前"没有passwd文件的状态"变为了"有passwd文件的状态"，当我们再次执行同样的命令时，ansible发现对应文件已经存在与对应目录中，于是ansible并没有做出任何操作，也没有进行任何改变，因为"当前状态"与我们预期的"目标状态"一致，没有必要再做出重复的无用功。
> 
> 这就是为什么执行ansible命令时，会返回黄色的成功信息或者绿色的成功信息了吧？我们可以通过返回信息的颜色，更加精准的判断执行命令之前的状态是否与我们预期的一致。

从返回信息中可以看到，当ansible进行fetch操作时，会对对应文件进行哈希计算，算出文件哈希值，也就是说，如果我们改变了文件中的内容，哈希值也将随之发生改变，这个时候，即使对应目录中存在同名的文件，ansible也会判断出两个文件属于不同的文件，因为它们的哈希值并不相同，测试如下
> 我们在141这个服务器上创建一个用户，这个时候它的/etc/passwd文件发生了改变，在看看fetch动作的结果
![image.png](https://img.hacpai.com/file/2019/07/image-4ae5a9d3.png)

 
###copy 模块
拷贝文件，它和上面的fetch模块类似，只不过fetch是把远端文件拉到ansible服务器上，copy是把ansible的文件拷贝到客户机上。
*copy的参数*
> `dest`：用于指定文件将被拷贝到远程主机的哪个目录中，**dest为必须参数**
`src`：用于指定需要copy的文件或目录
`content`：当不使用src指定拷贝的文件时，可以使用content直接指定文件内容，src与content两个参数必有其一，否则会报错。
`force`:当远程主机的目标路径中已经存在同名文件，并且与ansible主机中的文件内容不同时，是否强制覆盖，可选值有yes和no，默认值为yes，表示覆盖，如果设置为no，则不会执行覆盖拷贝操作，远程主机中的文件保持不变。
`backup`:当远程主机的目标路径中已经存在同名文件，并且与ansible主机中的文件内容不同时，是否对远程主机的文件进行备份，可选值有yes和no，当设置为yes时，会先备份远程主机中的文件，然后再将ansible主机中的文件拷贝到远程主机。
`owner`:指定文件拷贝到远程主机后的属主，但是远程主机上必须有对应的组，否则会报错
`group`:指定文件拷贝到远程主机后的属组，但是远程主机上必须有对应的组，否则会报错。
> `mode`:指定文件拷贝到远程主机后的权限，如果你想将权限设置为"rw-r--r--"，则可以使用mode=0644表示，如果你想要在user对应的权限位上添加执行权限，则可以使用mode=u+x表示。

####实例
1. 把ansible主机上的/root/ansible.txt 拷贝到web（172.16.1.131）的tmp目录下，如果/tmp目录下已经存在这个文件，当两个文件内容不一样的时候web主机下的文件将被覆盖。
**`ansible web -m copy -a "src=/root/ansible.txt dest=/tmp"`**
![image.png](https://img.hacpai.com/file/2019/07/image-7fa2a991.png)


2. 在远程backup主机上创建一个/tmp/copy_test.txt的文件，并写入"This is ansible file;Welcome to the world of ansible "两行内容
    **`ansible backup -m copy -a 'content="This is ansible file\n welcome to the world of ansible\n" dest=/tmp/copy_test.txt'`**
    > 如果我们把`contnet`后面的内容给跟换了，那么copy_test.txt里面只有我们更换后的内容，相当于他把以前的文件内容给删除了。

3. 将ansible主机中的/etc/passwd文件拷贝到backup主机的/tmp/并改名为copy_test.txt，如果copy_tets.txt存在的话我们不拷贝（不覆盖）
**` ansible backup -m copy -a 'content="test ansible" dest=/tmp/copy_test.txt force=no'`**
 
4. 将ansible主机中的/etc/passwd文件拷贝到backup主机的/tmp/并改名为copy_test.txt，如果copy_tets.txt存在的话我们替换之前把原文件备份
**` ansible backup -m copy -a 'content="test ansible" dest=/tmp/copy_test.txt force=yes backup=yes'`**

5. 指定拷贝过去文件的属主和属主，并更改权限为600（注意这个属主和属组必须是客户机上真实存在的，否则会出错）
**`ansible backup -m copy -a 'src=/etc/hosts dest=/tmp owner=sshd group=sshd mode=0600'`**

### file模块
file模块可以帮助我们完成一些对文件的基本操作，比如，创建文件或目录、删除文件或目录、修改文件权限等
*file常用参数*
>  `path`：必须参数，用于指定要操作的文件或目录，在之前版本的ansible中，使用dest参数或者name参数指定要操作的文件或目录，为了兼容之前的版本，使用dest或name也可以。
>  `state`：此参数非常灵活，此参数对应的值需要根据情况设定，比如，当我们需要在远程主机中创建一个目录的时候，我们需要使用path参数指定对应的目录路径，假设，我想要在远程主机上创建/testdir/a/b目录，那么我则需要设置path=/testdir/a/b，但是，我们无法从"/testdir/a/b"这个路径看出b是一个文件还是一个目录，ansible也同样无法单单从一个字符串就知道你要创建文件还是目录，所以，我们需要通过state参数进行说明，当我们想要创建的/testdir/a/b是一个目录时，需要将state的值设置为directory，"directory"为目录之意，当它与path结合，ansible就能知道我们要操作的目标是一个目录，同理，当我们想要操作的/testdir/a/b是一个文件时，则需要将state的值设置为touch，当我们想要创建软链接文件时，需将state设置为link，想要创建硬链接文件时，需要将state设置为hard，当我们想要删除一个文件时（删除时不用区分目标是文件、目录、还是链接），则需要将state的值设置为absent，"absent"为缺席之意，当我们想让操作的目标"缺席"时，就表示我们想要删除目标。
 `src`：当state设置为link或者hard时，表示我们想要创建一个软链或者硬链，所以，我们必须指明软链或硬链链接的哪个文件，通过src参数即可指定链接源。
 `force`当state=link的时候，可配合此参数强制创建链接文件，当force=yes时，表示强制创建链接文件，不过强制创建链接文件分为两种情况，情况一：当你要创建的链接文件指向的源文件并不存在时，使用此参数，可以先强制创建出链接文件。情况二：当你要创建链接文件的目录中已经存在与链接文件同名的文件时，将force设置为yes，回将同名文件覆盖为链接文件，相当于删除同名文件，创建链接文件。情况三：当你要创建链接文件的目录中已经存在与链接文件同名的文件，并且链接文件指向的源文件也不存在，这时会强制替换同名文件为链接文件。
`owner`：用于指定被操作文件的属主，属主对应的用户必须在远程主机中存在，否则会报错。
`group`：用于指定被操作文件的属组，属组对应的组必须在远程主机中存在，否则会报错。
 `mode`：用于指定被操作文件的权限，比如，如果想要将文件权限设置为"rw-r-x---"，则可以使用mode=650进行设置，或者使用mode=0650，效果也是相同的，如果你想要设置特殊权限，比如为二进制文件设置suid，则可以使用mode=4700，很方便吧。
`recurse`：当要操作的文件为目录，将recurse设置为yes，可以递归的修改目录中文件的属性。 

####实例
在backup（172.16.1.141）主机上的/tmp目录下面创建一个test_ansible.txt文件，如果文件存更新时间戳
**`ansible backup -m file -a 'path=/tmp/test_anslible.txt state=touch'`**
在backup（172.16.1.141）主机上的/tmp/目录下面创建一个ansible目录，如果目录存在不进行任何操作
**`ansible backup -m file -a 'path=/tmp/ansible state=directory'`**
在backup（172.16.1.141）主机上的/tmp目录下建立一个/etc/passwd的软链接文件
**`ansible backup -m file -a 'path=/tmp/passwd state=link src=/etc/passwd'`**
在backup（172.16.1.141）主机上的/tmp目录下建立一个/etc/passwd的硬链接文件
**`ansible backup -m file -a 'path=/tmp/passwd_hard state=hard src=/etc/passwd'`** 
 如果链接的目标文件已经存在，或者源文件不存在我们也强制创建链接（会先删除已经存在的文件，然后建立链接文件，但是软连接失效）
  **`ansible backup -m file -a 'path=/tmp/passwd state=link force=yes src=/etc/123'`**  
  删除backup主机上的/tmp/passwd文件和/tmp/test目录,如果要操作的文件不存在也不报错  
 **`ansible backup -m file -a 'path=/tmp/passwd state=absent'`**
**`ansible backup -m file -a 'path=/tmp/test state=absent ' `**     
在创建文件或目录的时候指定属主，或者修改远程主机上的文件或目录的属主
**`ansible backup -m file -a 'path=/tmp/passwd state=touch owner=sshd'`**
**`ansible backup -m file -a 'path=/tmp/passwd owner=shutdown'`**
递归设置backup主机上/tmp目录下的权限是644，属主是sshd，属组是sshd
**`ansible bakcup -m file -a "path=/tmp state=directory owner=sshd group=sshd mode=0644 recurse=yes"`**

### blockinfile
blockinfile模块可以帮助我们在指定的文件中插入"一段文本"，这段文本是被标记过的，换句话说就是，我们在这段文本上做了记号，以便在以后的操作中可以通过"标记"找到这段文本，然后修改或者删除它.

 > `path`：必须参数，指定要操作的文件。 
 `block`: 此参数用于指定我们想要操作的那"一段文本"，此参数有一个别名叫"content"，使用content或block的作用是相同的。
`marker`:  ：假如我们想要在指定文件中插入一段文本，ansible会自动为这段文本添加两个标记，一个开始标记，一个结束标记，默认情况下，开始标记为# BEGIN ANSIBLE MANAGED BLOCK，结束标记为# END ANSIBLE MANAGED BLOCK，我们可以使用marker参数自定义"标记"，比如，marker=#{mark}test ，这样设置以后，开始标记变成了# BEGIN test，结束标记变成了# END test，没错，{mark}会自动被替换成开始标记和结束标记中的BEGIN和END，我们也可以插入很多段文本，为不同的段落添加不同的标记，下次通过对应的标记即可找到对应的段落。
`state`: state参数有两个可选值，present与absent，默认情况下，我们会将指定的一段文本"插入"到文件中，如果对应的文件中已经存在对应标记的文本，默认会更新对应段落，在执行插入操作或更新操作时，state的值为present，默认值就是present，如果对应的文件中已经存在对应标记的文本并且将state的值设置为absent，则表示从文件中删除对应标记的段落。
 `insertafter`：在插入一段文本时，默认会在文件的末尾插入文本，如果你想要将文本插入在某一行的后面，可以使用此参数指定对应的行，也可以使用正则表达式(python正则)，表示将文本插入在符合正则表达式的行的后面，如果有多行文本都能够匹配对应的正则表达式，则以最后一个满足正则的行为准，此参数的值还可以设置为EOF，表示将文本插入到文档末尾。
  `insertbefore`: 在插入一段文本时，默认会在文件的末尾插入文本，如果你想要将文本插入在某一行的前面，可以使用此参数指定对应的行，也可以使用正则表达式(python正则)，表示将文本插入在符合正则表达式的行的前面，如果有多行文本都能够匹配对应的正则表达式，则以最后一个满足正则的行为准，此参数的值还可以设置为BOF，表示将文本插入到文档开头。
`backup`: 是否在修改文件之前对文件进行备份。
`create`: 当要操作的文件并不存在时，是否创建对应的文件。  

#### 实例：
先复制ansible机器上的/etc/passwd文件到/tmp目录下面来做模拟环境
 **`ansible backup -m copy -a 'dest=/tmp src=/etc/passwd'`**
 在backup主机的backup的/etc/passwd的最后加入"welcome to ansible；test ansible txt"两句话，并在插入前先把文件备份
 **`ansible backup -m blockinfile -a 'path=/tmp/passwd block="welcome to ansible\ntest ansible txt" backup=yes'`**
自定义标记：
 **`ansible backup -m blockinfile -a 'path=/tmp/passwd block="welcome to ansible\ntest ansible txt" marker="#{mark} test ansible moudle blockinfile" backup=yes '`**  
 
### command命令模块
```
# 默认模块, 执行命令
[root@m01 ~]# ansible oldboy  -a "hostname"

# 如果需要一些管道操作，则使用shell
[root@m01 ~]# ansible oldboy -m shell -a "ifconfig|grep eth0" -f 50

# -f =forks   /etc/ansible/ansible.cfg #结果返回的数量
```
###script模块
```
# 编写脚本
[root@m01 ~]# mkdir -p /server/scripts
[root@m01 ~]# cat /server/scripts/yum.sh
#!/usr/bin/bash
yum install -y iftop

#在本地运行模块，等同于在远程执行，不需要将脚本文件进行推送目标主机执行
[root@m01 ~]# ansible oldboy -m script -a "/server/scripts/yum.sh"
```

###yum安装模块
```yaml
#推送脚本文件至远程，远程执行脚本文件
[root@m01 ~]# ansible oldboy -m yum -a "name=httpd state=installed"
name    ---指定要安装的软件包名称
state   ---指定使用yum的方法
    installed，present   ---安装软件包
    removed，absent      ---移除软件包
    latest               ---安装最新软件包 
```

###service服务模块
```yaml
[root@m01 ~]# ansible oldboy -m service -a "name=crond state=stopped enabled=yes"

name        --- 定义要启动服务的名称
state       --- 指定服务状态是停止或是运行，停止和运行指令要写成过去时
    started     --- 启动
    stopped     --- 停止
    restarted   --- 重启
    reloaded    --- 重载
enabled     --- 是否让服务开启自启动
```

###user模块
```yaml
[root@m01 ~]# echo "bgx"| openssl passwd -1 -stdin
$1$1KmeCnsK$HGnBE86F/XkXufL.n6sEb.

[root@m01 ~]# ansible oldboy -m user -a 'name=xlw password="$1$1KmeCnsK$HGnBE86F/XkXufL.n6sEb."'
```

###crond模块
```yaml
# 正常使用crond服务
[root@m01 ~]# crontab -l
* * * * *  /bin/sh /server/scripts/yum.sh

# 使用ansible添加一条定时任务
[root@m01 ~]# ansible oldboy -m cron -a "minute=* hour=* day=* month=* weekday=*  job='/bin/sh /server/scripts/test.sh'"
[root@m01 ~]# ansible oldboy -m cron -a "job='/bin/sh /server/scripts/test.sh'"

# 设置定时任务注释信息，防止重复，name设定
[root@m01 ~]# ansible oldboy -m cron -a "name='cron01' job='/bin/sh /server/scripts/test.sh'"

# 删除相应定时任务
[root@m01 ~]# ansible oldboy -m cron -a "name='ansible cron02' minute=0 hour=0 job='/bin/sh /server/scripts/test.sh' state=absent"
 
# 注释相应定时任务，使定时任务失效    
[root@m01 scripts]# ansible oldboy -m cron -a "name='ansible cron01' minute=0 hour=0 job='/bin/sh /server/scripts/test.sh' disabled=no"
```
###mount模块
```yaml
[root@m01 ~]# ansible oldboy -m mount -a "path=/backup src=10.0.0.31:/data fstype=nfs opts=defautls,noatime state=mounted"

mounted     ---挂载设备，并将配置写入/etc/fstab
present     ---仅将挂载的信息写入到/etc/fstab里面，但是并没挂载
unmounted   ---卸载设备，不会清除/etc/fstab写入的配置
absent      ---卸载设备，会清理/etc/fstab写入的配置
```
###ansible查看帮助方法
```yaml
[root@m01 ~]# ansible-doc -l    --- 查看所有模块说明信息
[root@m01 ~]# ansible-doc copy  --- 表示指定查看某个模块参数用法信息
```

### replace替换模块
```yaml
- replace:
    path: /etc/nginx/nginx.conf    //在哪个文件中替换
    regexp: '^user .*;$'           //替换那些内容
    replace: 'user www;'           //替换成什么内容
```
##Ansible Playbook
使用多个不同的模板，完成一件事情。
`playbook`是由一个或多个模块组成的，

`Playbooks`是`Ansible`的配置,部署,编排语言.
他们可以被描述为一个需要希望远程主机执行命令的方案,或者一组IT程序运行的命令集合.

注意: ansible是通过yaml语法识别配置描述文件。扩展名是yaml

1.YAML基础语法
```
YAML:
    1.缩进(层级关系)  2个空格，不能使用Tab。
    2.冒号  key: value
    3.短横线 - list1
            - list2
```
> 1.缩进
    YAML使用一个固定的缩进风格表示数据层级结构关系,每个缩进由两个空格组成, 不要使用tabs。
2.冒号
    以冒号结尾, 以冒号为路径的除外，其他所有冒号后面所有必须有空格。
3.短横线
    表示列表项，使用一个短横杠加一个空格。
> 多个项使用同样的缩进级别作为同一列表。

ansible playbook安装Apache
```yaml
[root@m01 ansible_playbook]# cat webserver.yaml
- hosts: 10.0.0.20
# 定义变量，后续jinja文件可以应用对应的变量
  vars:
    http_port: 80
  tasks:
  - name: ensure apache is at the latest version
    yum: pkg=httpd state=latest
  # 使用template模板，引用上面vars定义的变量，动态配置httpd文件
  - name: write the apache config file
    template: src=./conf/httpd.j2 dest=/etc/httpd/conf/httpd.conf
    # 监控配置文件变化，如果发生变化则调用name为restart apache的handlers
    notify: restart apache
  - name: ensure apache is running
    service: name=httpd state=started 
    # 在发生改变时执行的操作
  handlers:
    - name: restart apache
      service: name=httpd state=restarted
```


监控模式：当文件发生改变的时候我们触发什么动作
![image.png](https://img.hacpai.com/file/2019/07/image-d71ee395.png)



##playbook剧本案例
通过ansible批量管理三台服务器，使三台服务器实现备份，web01、nfs、backup，把web和nfs上的重要文件被分到backup上，主机ip地址分配如下

| Character | IP地址 | IP地址 | 主机名 |
| :-: | :-: | :-: | :-: |
| Rsync--server | 172.16.1.41 | 10.0.0.41 | backup-rsync-41 |
| NFS-client | 172.16.1.31 | 10.0.0.31 | Nfs01-31 |
| Web01 | 172.16.1.7 | 10.0.0.7 | web01-7 |

在m01上操作，编写ansible清单和剧本
目录规划：
    我们把所有的yaml文件都放在/playbook目录下，配置文件都放在/paly/conf目录下，脚本都放在/playbook/scripts目录下。

```
[root@m01-61 /]# mkdir /playbook/{conf,scripts}
[root@m01-61 /]# cat /etc/ansible/hosts     ---主机清单
[nfs]
172.16.1.31 ansible_ssh_private_key_file=/root/.ssh/test_id_rsa

[web]
172.16.1.7 ansible_ssh_private_key_file=/root/.ssh/test_id_rsa

[backup]
172.16.1.41 ansible_ssh_private_key_file=/root/.ssh/test_id_rsa

[host:children]
nfs
web
backup
```

构建基础的剧本，所有的服务器都应用这个剧本

```yaml
1，基础的额优化，关闭firewalld和selinux，修改ssh，修改dns的文件
2，安装构建epel源
3，安装nfs和rsyn服务
4，创建UID和GID为666的www用户
5，创建rsync推送使用的密钥文件
6，创建一个共同存放脚本的路径
7，创建备份的脚本，编写定时任务
[root@m01-61 /]# cd /playbook/
[root@m01-61 playbook]# cat base.yaml 
#zhe shi yi ge ji chu
- hosts: all
  tasks:
    
#    - name: stop firewall
    - name: Install Epel repos
      get_url: url=http://mirrors.aliyun.com/repo/epel-7.repo dest=/etc/yum.repos.d/epel.repo
# ssh firewall selinux hosts
    - name: Dns client file
      copy: src=./conf/resolv.conf dest=/etc/resolv.conf

    - name: Install service rsync nfs-utils
      yum: name=rsync,nfs-utils state=installed

    - name: create group 
      group: name=www gid=666
    
    - name: creat user
      user: name=www uid=666 group=www create_home=no shell=/sbin/nologin

    - name: rsync passwd file
      copy: content='1' dest=/etc/rsync.pass mode=0600

    - name: creat /server/scripts
      file: path=/server/scripts state=directory recurse=yes 

    - name: copy scripts
      copy: src=./scripts/client_rsync_backup.sh dest=/server/scripts/client_rsync_backup.sh

    - name: crontab sh /server/scripts/client_rsync_backup.sh
      cron: name="backup scripts" minute=0 hour=1 job="/usr/bin/bash /server/scripts/client_rsync_backup.sh &> /dev/null "
```
关闭backup的剧本

```yaml
1，配置邮件服务，推送校验客户端推送是否完整，并发送邮件
2，创建backup和data目录
3，生成rsync的配置文件， 和密码文件
4，当rsync配置文件修改的时候，自动重启服务
5，每天晚上校验托送过来的备份数据是不是完整
[root@m01-61 playbook]# cat rsync.yaml 
- hosts: backup
  tasks:

    - name: install mailx
      yum: name=mailx state=installed

    - name: configure rsync
      copy: src=conf/rsyncd.conf dest=/etc/rsyncd.conf
      notify: Restart rsync service

    - name: create dir /data
      file: path=/data state=directory owner=www group=www 

    - name: create dir /backup
      file: path=/backup state=directory owner=www group=www
 
    - name: create file rsync passwd
      copy: content='rsync_backup:1' dest=/etc/rsync.password motd=0600

    - name: configure mail
      copy: src=./conf/mail.rc dest=/etc/mail.rc

    - name: copt scripts check
      copy: src=./scripts/check_backup.sh dest=/server/scripts/check_backup.sh

    - name: cron root
      cron: name="check client backup" minute=0 hour=2 job='/usr/bin/bash /server/scripts/check_backup.sh &> /dev/null'

    - name: start rsync
      service: name=rsyncd state=started

  handlers:
    - name: Restart rsync service
      service: name=rsyncd state=restarted
      
[root@m01-61 playbook]# cat ./conf/rsyncd.conf 
uid = www
gid = www
port = 873
fake super = yes 
max connections = 200
timeout = 600
ignore errors
read only = false
list = false
auth users = rsync_backup
secrets file = /etc/rsync.password
log file = /var/log/rsyncd.log
[backup]
comment = welcome to backup!
path = /backup
[data]
path = /data      
```
编写nfs的配置文件

```yaml
1，配置nfs配置文件，然后编写一旦配置文件发生改变就重启服务
2，配置sersync服务，使一更改配置文件服务就杀死上次的进程，然后重启服务

[root@m01-61 playbook]# cat nfs.yaml 
- hosts: nfs
  tasks:

    - name: copy sersync
      copy: src=./conf/sersync dest=/usr/local recurse=yes mode=755 
      notify: statr sersync

    - name: create /data
      file: path=/data state=directory owner=www group=www

    - name: create nfs file
      copy: src=./conf/exports dest=/etc/exports
      notify: restart nfs service

    - name: start rpcbind rsync
      service: name=rpcbind state=started enabled=yes

    - name: statrt nfs start
      service: name=nfs-server state=started enabled=yes

  handlers:
    - name: restart nfs service
      service: name=nfs state=restarted
    
    - name: statr sersync
      shell: " ps aux | grep [s]ersync | awk '{print \"kill -9\"$2}' | bash && /usr/local/sersync/sersync2 -dro /usr/local/sersync/confxml.xml"
```
配置web剧本

```yaml
[root@m01-61 playbook]# cat web_nfs.yaml 
- hosts: web
  tasks:

    - name: mount nfs
      mount: src=172.16.1.31:/data path=/data fstype=nfs opts=defaults state=mounted
```
把所有的剧本合到一起来执行

```yaml
[root@m01-61 playbook]# cat all.yaml 
- import_playbook: /playbook/base.yaml
- import_playbook: /playbook/rsync.yaml
- import_playbook: /playbook/nfs.yaml
- import_playbook: /playbook/web_nfs.yaml 
```