title: Linux两行脚本实现微信推送消息
date: '2019-08-20 13:53:37'
updated: '2019-08-20 13:53:37'
tags: [Linux技巧]
permalink: /articles/2019/08/20/1566280417315.html
---
# Linux两行脚本实现微信推送消息
## 前言
今天线上要监控个东西，懒得搞zabbix，就写个脚本放到定时任务里面来监控下，触发了我的条件就通知我，本来写用邮件告警，但是苦于每天邮箱里面的邮件实在是太多了，就只能用微信来告警，百度下看看网上有没有简单的来实现微信告警的方式，很快就找到了如下方法，用起来是在是太方便了
## Server酱 
Server 酱，英文名字 ServerChan，地址：http://sc.ftqq.com
「Server酱」，英文名「ServerChan」，是一款「程序员」和「服务器」之间的通信软件。
说人话？就是从服务器推报警和日志到手机的工具。
开通并使用上它，只需要一分钟：

1，登入：用GitHub账号登入网站，就能获得一个SCKEY（在「发送消息」页面）
2，绑定：点击「微信推送」，扫码关注同时即可完成绑定
3，发消息：往 http://sc.ftqq.com/SCKEY.send 发GET请求，就可以在微信里收到消息啦
实现示意图：
![image.png](https://img.hacpai.com/file/2019/08/image-73b3e7e9.png)
代码示例：

```python
cat /scripts/java.py
#-*- coding: utf-8 -*-
import requests
requests.get("https://sc.ftqq.com/SCU57872T958ad6ee3ca620d49a362a6bb973b21a5d5b51dfba54f.send?text={}&desp={}".format('测试测试','凡事多查查多想想'))
```
在手机上显示如下图
![image.png](https://img.hacpai.com/file/2019/08/image-e8ab9ba0.png)
是不是很简单！1 行代码就搞定了微信消息推送，再也不用其他任何复杂的步骤！
另外，显示发现发件人是Server酱，另外点进去有推广，毕竟是免费的接口，还要啥自行车！
还有就是发送消息是有一些限制的：
> 每人每天发送上限 500 条，相同内容 5 分钟内不能重复发送，不同内容一分钟只能发送 30 条。主要是防止程序出错的情况。

对于我简单用下的人，这限制完全用不了。