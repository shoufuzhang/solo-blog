title: 初识 prometheus
date: '2019-10-11 09:11:51'
updated: '2019-10-11 09:12:08'
tags: [监控, prometheus]
permalink: /articles/2019/10/11/1570756311093.html
---
# 初识 prometheus
## prometheus是什么及其主要功能注意事项
### prometheus 是什么？
我现在目前的读者都肯定通过prometheus这个监控吧，那么它到底是什么呢？ prometheus是一个基于时间序列（time_series）的监控软件，它是由`soundCloud`开源监控告警解决方案，从2012年开始编写代码，再到2015年github上开源，已经很多大公司使用，2016年prometheus成为继kubernetes后，第二个CNCF（cloud native Computing Foundation云原生计算基金会）的成员。2017年底发布了基于全新存储层的2.0版本，能更好地与容器平台、云平台配合，并同时支持告警。
### prometheus的主要功能
* 多维数据模型（时序由metrics[指标]和k/v的labels构成）
* 灵活的查询语句（PromQL）支持基本数据运算和函数
* 无依赖存储，支持local和remote不同的模型
* 采用http协议，使用pull/push模式来获取数据
* 监控目标，可以采用服务发现和静态配置的方式
* 支持多种统计数据模型，配合grafana使用图形化友好

### prometheus的核心组件
* prometheus server：主要对获取的数据和存储时序数据，另外还提供查询和alert rule（报警规则）配置管理
* client libraries：用于对接prometheus server，可以查询和上报数据
* Pushgateway： 用于批量，短期的监控数据的汇总节点，监控主机上报给pushgeateway，然后pushgateway上报给prometheus sever。
* exporters： 各种汇报数据的exporters，例如汇报机器数据的node_exporter，汇报docker情况的cAdvisor
* alertmanager： 用于告警通知的

### prometheus基础架构图
下面这张图是官方的架构图
![image.png](https://img.hacpai.com/file/2019/10/image-e389acd4.png)

从上图中我们也能看出来prometheus的主要包含的模块，pushgateway，exporters，retrieval，TSDB（存储）HTTP，PromeQl，Alertmanager。

他的大致逻辑是这样的：
1，prometheus会定期从静态配置的targets或者服务发现的targets中向部署在被监控端的服务器上请求exporters来获取数据，或者由客户端通过定时任务定期向pushgateway发送数据，然后有pushgateway向prometheus发送数据。
2，当新的数据大于配置内存缓存区的时候，prometheus会将数据持久化到磁盘，（如果使用remote storage将持久到云端）
3，prometheus可以配合grafana通过特定的表达是来获取我们想要的监控图形
4，prometheus可以配置rules（规则），然后定时查询数据，当出发告警条件的时候，会通知alertmanager推送到配置的告警信息上去
4，alertmanager收到告警信息的时候，可以根据配置，聚合，去重，降噪最后发送警告

### promethesus使用的注意事项
* prometheus的数据是基于时间序列（time-series）的fload64的值，
* prometheus不适合做审计计费，因为他的数据是按照时间间隔来采集的，关注的更多是系统的运行的瞬时状态以及趋势，即使有少量的数据没有采集也能容忍，但是审计计费需要记录每个请求，并且数据长期存储，这个prometheus无法满足。

## prometheus和其他监控的对比
### prometheus相对于其他软件的优势
**1，易于管理**
    prometheus核心部分只有一个单独的用golang编写的二进制文件，不存在任何的第三方依赖（数据库，缓存等）。唯一需要做的就是本地磁盘和内存，所以他可以运行在各种平台。
    prometheus是基于pull和push模型的架构方式，在任何地方搭建我们的监控系统，对于一些复杂的情况，还可以使用prometheus服务发现（server Discovery）的能力动态管理监控目标。
   
**2，监控服务的内部运行状态**
prometheus鼓励用户监控服务的内部状态，基于prometheus丰富的client库，用户可以轻松的在应用程序中添加的对prometheus的支持，从而让用户可以获取服务和应用内部真正的运行状态。

**3，强大的数据模型**
所有采集的监控数据均以指标（metric）的形式保存在内置的时间序列数据库当中（TSDB）。所有的样本除来基本的指标名称以外，还包含一组用于描述该样本特征的标签。

**4，强大的查询语言PromQL**
prometheus内置来一个强大的数据查询语言promQL，通过PromQL可以实现对监控数据的查询/聚合。同时PromeQL也被应用于数据可视化（grafana）以及告警中。

**5，高效**
对于监控系统而言，大量的监控任务必然导致有大量的数据产生。而Prometheus可以高效地处理这些数据，对于单一Prometheus Server实例而言它可以处理：
* 数以百万的监控指标
* 每秒处理数十万的数据点。 

**6，可扩展性**
Prometheus是如此简单，因此你可以在每个数据中心、每个团队运行独立的Prometheus Sevrer。Prometheus对于联邦集群的支持，可以让多个Prometheus实例产生一个逻辑集群，当单实例Prometheus Server处理的任务量过大时，通过使用功能分区(sharding)+联邦集群(federation)可以对其进行扩展。

**7，易于集成**
因为prometheus采用的是http的协议来进行通信获取数据的，所以所有语言只要支持http协议都可以被当作exporters来使用

**8，可视化**
prometheus配合grafana制定精美的监控图表

### prometheus VS zabbix
* Zabbix 使用的是 C 和 PHP, Prometheus 使用 Golang, 整体而言 Prometheus 运行速度更快一点。
* Zabbix 属于传统主机监控，主要用于物理主机，交换机，网络等监控，Prometheus 不仅适用主机监控，还适用于 Cloud, SaaS, docker，kubernetes，Container 监控。
* Zabbix 在传统主机监控方面，有更丰富的插件。
* Zabbix 可以在 WebGui 中配置很多事情，但是 Prometheus 需要手动修改文件配置。

### prometheus vs nagios
* Nagios 数据不支持自定义 Labels, 不支持查询，告警也不支持去噪，分组, 没有数据存储，如果想查询历史状态，需要安装插件。
* Nagios 是上世纪 90 年代的监控系统，比较适合小集群或静态系统的监控，显然 Nagios 太古老了，很多特性都没有，相比之下Prometheus 要优秀很多。

### prometheus vs InfluxDB
* InfluxDB 是一个开源的时序数据库，主要用于存储数据，如果想搭建监控告警系统， 需要依赖其他系统。
* InfluxDB 在存储水平扩展以及高可用方面做的更好, 毕竟核心是数据库。