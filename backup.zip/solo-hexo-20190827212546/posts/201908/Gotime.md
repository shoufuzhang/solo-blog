title: Go time
date: '2019-08-21 16:59:32'
updated: '2019-08-21 16:59:32'
tags: [GO]
permalink: /articles/2019/08/21/1566377972430.html
---
# time package
go语言中用来访问获取指定时间的包
## 时间单位转换

```go
time包：
1年=365天，day
1天=24小时，hour
1小时=60分钟，minute
1分钟=60秒，second
1秒=1000毫秒，millionsecond
```
## 1,获取当前的时间

```go
t1 := time.Now()
fmt.Printf("%T\n", t1)
fmt.Println(t1) //2019-08-19 16:53:40.912239 +0800 CST m=+0.000319688
```

## 2,获取指定时间的格式
```go
t2 := time.Date(2018, 8, 19, 16, 58, 00, 0, time.Local)
fmt.Println(t2) //2019-08-19 16:58:00 +0800 CST
```
## 3,time转换成string
t1.Format("模板格式") ---> string
			模板格式的日期必须是固定的： 2006年1月2日 3点4分5秒，上面格式如何写，下面转换的为对应的格式
```go
fmt.Println(t1.Format("2006年1月2日 03:04:05"))   //2019年8月19日 05:05:02
fmt.Println(t1.Format("01月02日2006年 03:04:05")) //08月19日2019年 05:06:06
fmt.Println(t1.Format("2006-01-02"))           //2019-08-19
```
## 4,字符串转换成time格式
time.Parse("模板",数据)
```go
t4 := "2019年07月12日"
T4, err := time.Parse("2006年01月02日", t4)
if err != nil {
	fmt.Println(err)
	return
}
fmt.Println(T4)  //2019-07-12 00:00:00 +0000 UTC
```
## 5,根据当前时间获取指定的内容
```go
year, month, day := t1.Date()
fmt.Println(year, month, day) //2019 August 19

//根据当前时间，获取指定内容
hour, min, sec := t1.Clock()
fmt.Println(hour, min, sec) //8 45 24

//获取今年是哪一年
fmt.Println("年：", t1.Year()) //今年是：  2019
fmt.Println("月：", t1.Month())
fmt.Println("天：", t1.Day())
fmt.Println("时：", t1.Hour())
fmt.Println("分：", t1.Minute())
fmt.Println("秒：", t1.Second())

//获取今年过去了多长时间
fmt.Println("今年过去了", t1.YearDay()) //今年过去了 233
```
## 6,获取时间戳

```go
s6 := t1.Unix()
fmt.Println("当前的时间戳：", s6) //返回的结果是1970年0月0日 到目前的之间戳
```
## 7，某个时间向前，或者向后多少长时间
```go
fmt.Println(t1)
fmt.Println("当前时间后一小时", t1.Add(time.Hour))
fmt.Println("当前时间的后一天", t1.Add(24*time.Hour))
fmt.Println("当前时间的下一年", t1.AddDate(1, 0, 0))
```
## 8,指定时间的时间间隔
```go
	t8 := time.Date(2019, 8, 28, 14, 14, 14, 0, time.Local)
	d1 := t8.Sub(t1)
	fmt.Println("t8 and t1 时间差", d1)
```
## 9,让程序暂停 30 S
```go
time.Sleep(30 * time.Second)
```
## 10，生成随机数 [1-10]
```go
//生成一个随机种子
rand.Seed(time.Now().UnixNano())
randNum := rand.Intn(10) + 1
fmt.Println(randNum)
//生成随机睡眠时间
time.Sleep(time.Duration(randNum) * time.Second)
```

