title: 'JenKins '
date: '2019-11-06 14:54:23'
updated: '2019-11-06 14:54:23'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573023263695.html
---
# JenKins 
## Jenkins简介：
JENKINS 是一个用 JAVA 编写的开源的持续集成工具。在与 ORACLE 发生争执后，项目从 HUDSON 项目独立出来。 • JENKINS 提供了软件开发的持续集成服务。它运行在 SERVLET 容 器中(例如 APACHE TOMCAT)。它支持软件配置管理(SCM)工具(包括 ACCUREV SCM、CVS、 SUBVERSION、GIT、PERFORCE、CLEARCASE 和 RTC)，可以执行基于 APACHE ANT 和 APACHE MAVEN 的项目，以及任意的 SHELL 脚本和 WINDOWS 批处理命令。JENKINS 的主要开发者是 川口耕介。JENKINS 是在 MIT 许可证下发布的自由软件。
官方网站:https://jenkins.io/ 清华镜像地址:https://mirrors.tuna.tsinghua.edu.cn/jenkins/
![image.png](https://img.hacpai.com/file/2019/11/image-02de6536.png)


## 企业代码上线发展史
代码发布上线是每一个 IT 企业必须要面临的，而且不管是对开发或者是运维来说，代码上 线本身就是一个件非常痛苦的事情，很多时候每一次发布都是一次考验。为了提高上线的效 率，代码上线的方式，方法，工具也不断的发展，基本上可以分为以下几个阶段:

**阶段 1-没有构建服务器**
软件在开发者的机器上通过 Ant 或其它脚本手动构建，代码保存在中央源码仓库中，但是开 发者不是经常提交本地的修改。每次需要发布的时候，开发者手动合并修改，这个过程是相 当痛苦的。

**阶段 2-晚上进行构建**
在这个阶段，团队有构建服务器，自动化的构建在晚上进行。构建过程只是简单的编译代码， 没有可靠的和可重复的单元测试。然而，开发人员每天提交代码。如果某个开发人员提的代 码和其他人的代码冲突的话，构建服务器会在第二天通过邮件通知团队。所以又一段时间构 建是处于失败状态的。

**阶段 3-晚上进行构建并进行自动化测试**
团队对 CI 和自动化测试越来越重视。无论什么时候版本管理系统中的代码改变了都会触发 编译构建过程，团队成员可以看到是代码中的什么改变触发了这个构建。并且，构建脚本会 编译应用并且会执行一系列的单元测试或集成测试。除了邮件，构建服务器还可以通过其他 方式通知团队成员，如:IM。失败的构建被快速的修复。

**阶段 4-代码质量度量**
自动化的代码质量和测试覆盖率的度量手段有助于评价代码的质量和测试的有效性。代码质 量的构建会产生 API 文档。

**阶段 5-更加认真地对待测试**
CI 和测试紧密相关。如今，像测试驱动开发被广泛地使用，使得对自动化的构建更加有信心。应用不仅仅是简单地编译和测试，而是如果测试成功会被自动的部署到一个应用服务器上来 进行更多的综合的 end-to-end 测试和性能测试。

**阶段 6-验收测试和更加自动化的部署**
验收测试驱动的开发被使用，使得我们能够了解项目的状态。这些自动化的测试使用行为驱 动的开发和测试驱动的开发工具来作为交流和文档工具，发布非开发人员也能读懂的测试结 果报告。由于测试在开发的早起就已经被自动化的执行了，所以我们能更加清楚地了解到什 么已经做了，什么还没有做。每当代码改变或晚上，应用被自动化地部署到测试环境中，以 供 QA 团队测试。当测试通过之后，软件的一个版本将被手工部署到生产环境中，团队也可 以在出现问题的时候回滚之前的发布。

**阶段 7-持续部署**
对自动化的单元测试，集成测试和验收测试的信心使得我们可以使用自动化的部署技术将软 件直接部署到生产环境中。但是测试还是有可能不能真正的反映现实的环境。

## Jenkins安装
1）环境准备：
最小硬件需求:256M 内存、1G 磁盘空间，通常根据需要 Jenkins 服务器至少 1G 内存，50G+ 磁盘空间。
软件需求:由于 jenkins 是使用 java 语言编写的，所以需要安装 java 运行时环境(jdk)
上面这个配置是官方给出的，现在我们使用虚拟机环境，个人建议给jenkins虚拟机3个G内存，

2）获取安装包
可以从 Jenkins 官方网站及清华镜像站下载 jenkins 安装包，也可以通过本教程配套的百度网 盘下载对应的安装包。本次课程采用 jenkins-2.72-1 版本，jdk-8u121-linux-x64。

3）因为Jenkins是java编写的，需要安装Jdk环境

```bash
[root@node_2_13 /]# yum -y install java-1.8.0-openjdk
[root@node_2_13 local]# vim /etc/sysconfig/jenkins 
[root@node_2_13 local]# java -version
java version "1.8.0_121"
Java(TM) SE Runtime Environment (build 1.8.0_121-b13)
Java HotSpot(TM) 64-Bit Server VM (build 25.121-b13, mixed mode)
```

4）安装jenkins

```bash
[root@node_2_13 /]# rpm -ivh https://mirrors.tuna.tsinghua.edu.cn/jenkins/redhat/jenkins-2.98-1.1.noarch.rpm
[root@node_2_13 /]# sed -i '/^JENKINS_USER/c JENKINS_USER="root"' /etc/sysconfig/jenkins
```

5) 启动jenkins

```bash
[root@node_2_13 local]# systemctl start jenkins
[root@node_2_13 local]# systemctl enable jenkins
[root@node_2_13 local]# netstat -ntalp | grep java
tcp6       0      0 :::8080                 :::*                    LISTEN      1595/java  
```

6）在web界面配置登录jenkins，
因为是java的项目，启动可能会很慢，我们需要稍作等待
![image.png](https://img.hacpai.com/file/2019/11/image-497c1412.png)
![image.png](https://img.hacpai.com/file/2019/11/image-82882f68.png)

然后会经历一个漫长的等待，他联网获取插件信息，如果想他快点我们可以直接断开网络连接
此页面要用户选择初始化安装的插件，我们选择跳过此步，后面我们采用其他方式安装插件。
![image.png](https://img.hacpai.com/file/2019/11/image-92339aa1.png)

点击完成 jenkins 安装配置，
![image.png](https://img.hacpai.com/file/2019/11/image-052d9857.png)

进入 Jenkins 主页面
![image.png](https://img.hacpai.com/file/2019/11/image-94e4e2ae.png)

由于默认 jenkins 的密码较复杂，所以我首先更改 admin 用户的密码。
![image.png](https://img.hacpai.com/file/2019/11/image-954c4320.png)
![image.png](https://img.hacpai.com/file/2019/11/image-8e7041a6.png)



## jenkins的插件管理
Jenkins 本身是一个引擎、一个框架，只是提供了很简单功能，其强大的功能都是通过插件 来实现的，jenkins 有一个庞大的插件生态系统，为 Jenkins 提供丰富的功能扩展。下面我们 来介绍常用的几种插件安装方式。

### 自动插件安装：
![image.png](https://img.hacpai.com/file/2019/11/image-51754210.png)
![image.png](https://img.hacpai.com/file/2019/11/image-2f4cdbf6.png)


安装完成后，一般情况下不需要重启jenkins，具体根据提示操作

### 手工安装插件
除了上面的插件安装方法，Jenkins 还为我们提供了手工安装插件的方式，特别是在国 内，由于网络的原因，有时候我们使用上述方法安装插件会经常不成功，所以我们可以采用 下载插件，然后再上传的方式来安装插件。
官方的插件下载地址:http://updates.jenkins-ci.org/
国内的源:https://mirrors.tuna.tsinghua.edu.cn/jenkins/plugins/ 
如果是在官方网站下载插件，最好下载与你 jenkins 版本对应的插件，如果是在清华镜像下 载插件，则不存在版本的问题。下载后得到的一个以.hpi 为扩展名的文件，
![image.png](https://img.hacpai.com/file/2019/11/image-baced17d.png)

下载 ssh.hpi 后，我们手动安装 ssh 插件，进入到插件管理页面:
![image.png](https://img.hacpai.com/file/2019/11/image-69790bd8.png)

按上图提示，上传完成后，重新启动 jenkins，完成插件的安装。

### 覆盖插件目录
我们可以备份已经安装好插件的 Jenkins 服务器上的/var/lib/jenkins/plugins 目录，然后 把备份文件上传到我们需要安装插件的新 Jenkins 服务器的对应目录上，然后重启 Jenkins。 这种方法其实给我们提供了一种更加快速的安装 Jenkins 插件的方法。建议在初始安装 jenkins 时，可以使用此方法，其他时候尽量使用前两种方式。我们本教程使用此方式安装 插件。前面我们在初始化 jenkins 的时候，跳过了插件的安装，现在我们的 Jenkins 插件目录 为空，因为我们没有安装任何插件:

```bash
[root@node_2_13 local]# cd /var/lib/jenkins/plugins/
[root@node_2_13 plugins]#  ll
total 0
```
从本博文配套的百度网盘下载 [plugins.tar.gz](https://pan.baidu.com/s/189DMngZA8HlKaLoaSbOBNw) 包，该文件包提供了我博客上所内容所涉及的所 有插件，上传该压缩包至 jenkins 服务器，解压后将所有文件都移动到 jenkins 的插件目录，

```bash
[root@node_2_13 plugins]# ls
plugins.tar.gz
[root@node_2_13 plugins]# tar xf plugins.tar.gz  -C ./
[root@node_2_13 plugins]# mv plugins/* ./
[root@node_2_13 plugins]# systemctl restart jenkins.service 
```
完成后，重启 jenkins 服务，然后我们到插件管理页面可以看到我们已经安装的插件
![image.png](https://img.hacpai.com/file/2019/11/image-1c572970.png)


## jenkins常用目录及文件
学习 Jenkins，首先要明白一点，那就是 jenkins 下一切兼文件，也就是说 jenkins 没有数据库， 所有的数据都是以文件的形式存在，所以我要了解 Jenkins 的主要目录及文件，通过命令我 们可以查看到所有的 jenkins 目录及文件的位置

```bash
[root@node_2_13 plugins]# cd /
[root@node_2_13 /]# rpm -ql jenkins
/etc/init.d/jenkins
/etc/logrotate.d/jenkins    //日志切割文件
/etc/sysconfig/jenkins      //主配置文件
/usr/lib/jenkins            //jenkins默认配置的主工作目录
/usr/lib/jenkins/jenkins.war//升级jenkins只需要替换这个war包即可
/usr/sbin/rcjenkins
/var/cache/jenkins
/var/lib/jenkins
/var/log/jenkins            //日志目录
```

Jenkins的工作目录

```bash
[root@node_2_13 /]# cd /var/lib/jenkins/
jobs                // 存放jobs配置及每次构建的结果
logs                // 
nodes
plugins             // jenkins插件目录，存放我们已经安装的插件
secrets
updates
userContent
users               // 存放与用户相关的配置文件
workflow-libs
worksspace          // 工作区目录，每次 job 执行构建时的工作 目录，
```

## JenKins创建freestyle项目
构建作业是一个持续集成服务器的基本职能，构建叙利亚的形式多种多样，可以是编译和单 元测试，也可能是打包及部署，或者是其他类似的作业。在 Jenkins 中，构建作业很容易建 立，而且根据你的需要你可以安装各种插件，来创建多种形式的构建作业，下面我们先来学习创建自由式构建作业。 自由式的构建作业是最灵活和可配置的选项，并且可以用于任何类型的项目，它的配置相对 简单，其中很多配置在的选项也会用在其他构建作业中。
在 Jenkins 主页面，点击左侧菜单栏的“新建”或者“New job”
![image.png](https://img.hacpai.com/file/2019/11/image-6895ff16.png)

注意:
* 1、job 名称需要有规划，以便于后面的权限管理;
* 2、创建 job 后不要轻易更改名称， 因为 jenkins 一切皆文件，很多关于 job 的文件，都是以该名称命名，当你改名后，一般不 会删除旧文件，而是会再重新创建一份新的文件。
![image.png](https://img.hacpai.com/file/2019/11/image-51c3f807.png)


输入 job 名称，选择类型后，点击 OK 后创建 job，进入 job 配置页面，此时在 Jenkins 的主 目录下的 jobs 目录已经生成了以你 Job 名称命名的文件夹

```bash
[root@node_2_13 jobs]# pwd 
/var/lib/jenkins/jobs
[root@node_2_13 jobs]# ls 
My_freestyle_jobs 
```
Job配置页面，主要包括通用配置、源码管理、构建触发器、构建环境、构建后操作等几个部分，根据你选择的构建类型不同，可能配置项会有一些小的差别。

### 构建执行shell命令
![image.png](https://img.hacpai.com/file/2019/11/image-a32c5d61.png)
![image.png](https://img.hacpai.com/file/2019/11/image-0ff25fab.png)


然后点击保存
![image.png](https://img.hacpai.com/file/2019/11/image-ea730679.png)
![image.png](https://img.hacpai.com/file/2019/11/image-2cc22d98.png)


我们点击console output 来查看输出的内容，和构建的执行过程
![image.png](https://img.hacpai.com/file/2019/11/image-9348372d.png)

我们进一步也可以看到 job 主页面，工作空间所对应的位置也是此目录。通过这个例子， 我们可以联想到，我们可以使用 Jenkins 执行任何 linux 命令，这也就是我们前面讲的要注意 Jenkins 启动用户的配置，如果是 root 用户启动的 Jenknis，那 Jenkins 的安全及权限配置一定 要做好控制。我们在学习初期，为了节省时间，可以使用 root 用户启动 jenkins。

### 连接Gitlab仓库获取源代码
现在Gitlab仓库上导入一个项目源码包
![image.png](https://img.hacpai.com/file/2019/11/image-67379cc4.png)

拉去代码成功之后去jenkins上创建源码管理
![image.png](https://img.hacpai.com/file/2019/11/image-9b16739a.png)

如果上面有报如下错误的，只有两种情况：
* 1，秘钥没有配置正确，是哪个身份用户启动的jenkins就需要在哪个用户上配置对应用户上的key
* 2，在Jenkins这台服务器上没有安装 git 软件
![image.png](https://img.hacpai.com/file/2019/11/image-41ad2827.png)


这个配置完成之后我们点击立即构建，测试是否能拉去源代码
![image.png](https://img.hacpai.com/file/2019/11/image-c556e16e.png)


```bash
[root@node_2_13 jobs]# cd ../workspace/My_freestyle_jobs/
[root@node_2_13 My_freestyle_jobs]# ls 
404.html              deviceManager.html       form-validation.html  login.html               readme.md
alerts.html           dianfei.html             images-icons.html     media                    real-time.html
assets                efficiencyAnalysis.html  img                   media.html               sa.html
buttons.html          energy_consumption.html  index.html            messages.html            tables.html
calendar.html         file-manager.html        js                    mstp_105_SuperAdmin.iml  typography.html
charts.html           fonts                    keyInfo.html          mstp_map.html            userMng.html
components.html       form-components.html     labels.html           other-components.html
content-widgets.html  form-elements.html       LICENSE               profile-page.html
css                   form-examples.html       list-view.html        QHME.iml
```
网站源代码拉去成功

### 构建触发器，当触发了那个动作，自动执行构建
![image.png](https://img.hacpai.com/file/2019/11/image-59be64b2.png)
![image.png](https://img.hacpai.com/file/2019/11/image-1cb24b52.png)
![image.png](https://img.hacpai.com/file/2019/11/image-d1febf81.png)

然后保存，去测试` jenkins `能不能自动完成构建，当我们pus到Gitlab的时候，jenkins帮我们自动拉去代码

我用`master_11`来充当开发的客户机，先配置秘钥连接，在这里不啰嗦
获取monitor的项目源代码，然后在里面创建一个新的文件`test.html`，
```bash
[root@master_11 ~]# git clone git@10.0.0.11:test_directort/monitor.git
Cloning into 'monitor'...
remote: Counting objects: 435, done.
remote: Compressing objects: 100% (372/372), done.
remote: Total 435 (delta 53), reused 435 (delta 53)
Receiving objects: 100% (435/435), 8.78 MiB | 0 bytes/s, done.
Resolving deltas: 100% (53/53), done.
Checking connectivity... done.
[root@master_11 ~]# ls
anaconda-ks.cfg  git_data  monitor
[root@master_11 ~]# cd monitor/
[root@master_11 monitor]# touch test.html
[root@master_11 monitor]# git add test.html
[root@master_11 monitor]# git commit -m "test jenkins push touch test.html" test.html
[master ee6b22e] test jenkins push touch test.html
 1 file changed, 0 insertions(+), 0 deletions(-)
 create mode 100644 test.html
[root@master_11 monitor]# git push -u origin master 
Counting objects: 3, done.
Compressing objects: 100% (2/2), done.
Writing objects: 100% (3/3), 283 bytes | 0 bytes/s, done.
Total 3 (delta 1), reused 1 (delta 0)
To 10.0.0.11:test_directort/monitor.git
   f6070e1..ee6b22e  master -> master
Branch master set up to track remote branch master from origin.
```
然后到Jenkins上查看
![](media/15420298567453/15426218229358.jpg)
![](media/15420298567453/15426218445873.jpg)
触发构建成功
### 我们基于这个直接布置一个静态的web站点
我们在本地更改好网站代码之后，自动部署到web站点

1）利用node_1_12机器充当web服务器，上面安装nginx服务，并做好相应的配置
```
[root@node_1_12 /]# yum -y install nginx
[root@node_1_12 /]# cat /etc/nginx/conf.d/test.conf 
server {
        listen 80;
        server_name 10.0.0.12;
        location / {
        root /code/web;
        index index.html;
        }
}
[root@node_1_12 /]# mkdir /code ; chown -R nginx.nginx /code
```

2) 在jenkins服务器上编写一个触发之后的脚本，推送web站点到指定的目录

```bash
#!/bin/sh
DATE=$(date +%Y-%m-%d-%H-%M-%S)
CODE_DIR="/var/lib/jenkins/workspace/$1"
WEB_DIR="/code"
Host=$2

get_code_tar(){
        cd $CODE_DIR && tar zcf /opt/web-$DATE.tar.gz ./*
}

scp_code_web(){
        scp /opt/web-$DATE.tar.gz $Host:$WEB_DIR
}

code_tarxf(){
        ssh $Host "cd $WEB_DIR &&mkdir web-$DATE && tar xf web-$DATE.tar.gz -C web-$DATE"

}
ln_html(){
         ssh $Host "cd $WEB_DIR && rm -rf web && ln -s web-$DATE web"
}

main(){

        get_code_tar;
        scp_code_web;
        code_tarxf;
        ln_html;
}
main
```
在jenkins上配置构建的操作
![image.png](https://img.hacpai.com/file/2019/11/image-28a35cd2.png)

没更改源代码之前
![image.png](https://img.hacpai.com/file/2019/11/image-f8205e05.png)

在node_1_12上更改源代码并push，看看web站点会不会改变
![image.png](https://img.hacpai.com/file/2019/11/image-d60da7a5.png)

自动构建成功，

### 配置构建后的操作
#### 配置构建后通知 GitLab
现在Gitlab上配置一个token，后面jenkins需要用这个token来连接他
![image.png](https://img.hacpai.com/file/2019/11/image-b408a70c.png)
![image.png](https://img.hacpai.com/file/2019/11/image-8351f829.png)


首先在jenkins上配置，可以访问GitLab，打开jenkins 系统管理 --> 系统设置页面，下拉找到Gitlab部分
![image.png](https://img.hacpai.com/file/2019/11/image-1e76bcdf.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c3afcae4.png)
![image.png](https://img.hacpai.com/file/2019/11/image-a84351f9.png)
![image.png](https://img.hacpai.com/file/2019/11/image-7893f397.png)

然后我们立即构建一次，看看能不能给gitlab传递信息
![image.png](https://img.hacpai.com/file/2019/11/image-01bec235.png)
![image.png](https://img.hacpai.com/file/2019/11/image-7f3168f0.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c2a6cf66.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c4c3d75d.png)

#### 配置构建后发邮件通知用户
到jenkins的主页面 --> 系统管理 --> 系统设置  
![image.png](https://img.hacpai.com/file/2019/11/image-b9be4f57.png)

然后下拉到最下面`邮件通知`部分
![image.png](https://img.hacpai.com/file/2019/11/image-a22dc413.png)

我们先点击`Test configuration`测试看看能不能收到邮件，我们已经能成功接收到邮件，然后说明我们邮件配置没问题，直接点击保存
![image.png](https://img.hacpai.com/file/2019/11/image-edb83b54.png)

然后进入项目的构建后操作，配置构建完成之后发送邮件
![image.png](https://img.hacpai.com/file/2019/11/image-baf0c0be.png)
![image.png](https://img.hacpai.com/file/2019/11/image-ef80c922.png)
![image.png](https://img.hacpai.com/file/2019/11/image-c5712a28.png)
![image.png](https://img.hacpai.com/file/2019/11/image-3f4cd4df.png)

