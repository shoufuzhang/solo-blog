title: MFS 数据恢复
date: '2019-07-17 21:34:05'
updated: '2019-07-17 21:34:05'
tags: [分布式存储, MFS]
permalink: /articles/2019/07/17/1563370445625.html
---
# 数据恢复
## 误删除数据从垃圾箱恢复
1）client我们已经挂载过目录了，直接在这个文件里面删除一个文件并给他恢复

```bash
> [root@node_5_16 tmp]# echo "this is test del file" >> test.png
[root@node_5_16 tmp]# ls 
test_file.txt
```
2）挂载垃圾箱

```bash
先查看删除的文件在垃圾箱存放的时间
[root@node_5_16 tmp]# mfsgettrashtime /tmp/
/tmp/: 3600

//挂载垃圾箱
[root@node_5_16 tmp]# mfsmount -m /mnt/ -H 10.0.0.11:/mfs_test
mfsmaster accepted connection with parameters: read-write,restricted_ip
```
3）删除数据，找到文件在垃圾箱的所在位置

```bash
[root@node_5_16 tmp]# rm -f test.png 
[root@node_5_16 trash]# find /mnt/ -name *test.txt
/mnt/trash/0F9/000000F9|test.txt
```
被删除的文件名在垃圾箱里面其实还是可以找到的，文件名是由一个8位16进制数的i-node和被删的文件名组成。在文件名和i-node之间不可以用"/"，而是以“|” 替代。如果一个文件名的长度超过操作系统的限制（通常是255字符），那么超出部分将被删除。从挂载点起全部路径的文件名被删除的文件仍然可以被读写。需要注意的是，被删除的文件在使用文件名（注意文件名是两部分），一定要用单引号引起来。

4）恢复数据
```bash
[root@node_5_16 tmp]# cd /mnt/trash/0F9/
[root@node_5_16 0F9]# ls 
000000F9|1.txt  undel
[root@node_5_16 0F9]# mv 000000F9\|1.txt undel/
[root@node_5_16 0F9]# cd /tmp/
[root@node_5_16 tmp]# ls
1.txt
[root@node_5_16 tmp]# cat test.txt 
this is test del file
```

5）注意：
垃圾回收站不一定需要时刻都挂载，你可以等到你想从垃圾箱里面恢复数据的时候在挂载就行了

