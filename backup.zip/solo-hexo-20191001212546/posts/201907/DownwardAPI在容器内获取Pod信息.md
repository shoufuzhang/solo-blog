title: Downward API（在容器内获取Pod信息）
date: '2019-07-19 17:47:45'
updated: '2019-07-19 17:47:45'
tags: [kubernetes]
permalink: /articles/2019/07/19/1563529665705.html
---
# Downward API（在容器内获取Pod信息）
在每个Pod被成功创建出来之后，都会被系统分配唯一的名字，并且处于某个`Namespace`中，我们可以使用`Downward API`来在容器中获取这些值
Downward APi可以通过两种方式将Pod信息注入容器内部：
1）环境变量：用于单个变量，可以将Pod信息注入容器内部
2）volume挂载：将数组类信息生成为文件并挂载到容器内部

## 通过环境变量方式
### 将Pod信息注入为环境变量
下面例子通过Downward API将Pod的IP、名称、和所在的namespaces注入容器变量中，然后在打印到标准输出中
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: test-nginx
spec:
  containers:
    - name: test-nginx
      image: busybox
      command: ["/bin/sh", "-c", "env"]
      env:
      - name: MY_POD_NAME
        valueFrom:
          fieldRef:
            fieldPath: metadata.name
      - name: MY_POD_NAMESPACE
        valueFrom:
          fieldRef:
            fieldPath: metadata.namespace
      - name: MY_POD_IP
        valueFrom:
          fieldRef:
            fieldPath: status.podIP
  restartPolicy: Never
```
* metadata.name: Pod的名称，当Pod通过RC生成是，其名称是RC随机产生的唯一名称
* status.podIP: Pod的IP地址，因为Pod的IP数组状态数据
* metadata.namespace: 当前pod的命令空间

### 将容器资源信息注入为环境变量
通过Downward API将容器的资源请求和限制信息注入容器的环境变量中：

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: test-nginx
spec:
  containers:
    - name: test-nginx
      image: busybox
      command: ["/bin/sh", "-c", "env"]
      env:
      - name: MY_CPU_REQUEST
        valueFrom:
          resourceFieldRef:
            containerName: test-nginx
            resource: requests.cpu
      - name: MY_CPU_LIMIT
        valueFrom:
          resourceFieldRef:
            containerName: test-nginx
            resource: limits.cpu
      - name: MY_MEM_REQUEST
        valueFrom:
          resourceFieldRef:
            containerName: test-nginx
            resource: requests.memory
      - name: MY_MEM_LIMIT
        valueFrom:
          resourceFieldRef:
            containerName: test-nginx
            resource: limits.memory
      resources:
        requests:
          memory: 1Gi
          cpu: 1000m
        limits:
          memory: 1Gi
          cpu: 1000m
```
