title: Dash macOS 激活授权文件
date: '2019-07-31 10:36:25'
updated: '2019-07-31 10:36:25'
tags: [工具]
permalink: /articles/2019/07/31/1564540585513.html
---
Dash 是 macOS 系统里一个非常好用的 API 文档查询软件。

> Dash is an API Documentation Browser and Code Snippet Manager. Dash stores snippets of code and instantly searches offline documentation sets for 200+ APIs, 100+ cheat sheets and more. You can even generate your own docsets or request docsets to be included.

官网 [https://kapeli.com/dash](https://kapeli.com/dash)  
下载地址 [https://singapore.kapeli.com/downloads/v4/Dash.zip](https://singapore.kapeli.com/downloads/v4/Dash.zip)

授权文件`license.dash-license`
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Product</key>
    <string>Dash</string>
    <key>Name</key>
    <string>Yang Wang</string>
    <key>Email</key>
    <string>lizhixiangwang@gmail.com</string>
    <key>Licenses</key>
    <string>1</string>
    <key>Timestamp</key>
    <string>1487632616</string>
    <key>Version</key>
    <string>4</string>
    <key>TransactionID</key>
    <string>KAP170220-3181-48919</string>
    <key>Signature</key>
    <data>DxmY4cUBFC/iYn/zRodj/5EwhL/7TD5BKyqXAOHoE/K19lNCorbnTvWKGmTrWJC242/mT8DJ7Zod
db5J98m8h0Q/YOfDHeDTyTkz5o5gYRAplIzBOqCGwdUjn1YHOI4OsMKH6LIML5VoHIpkxAOQwmmH
iHrpg4CHXopKW1uB45Q=
</data>
</dict>
</plist>
```
文件另存为 license.dash-license

打开软件设置，找到 License 导入授权文件，完美激活。
转载：https://kakarot.net/cgi-bin/dash-macos-license