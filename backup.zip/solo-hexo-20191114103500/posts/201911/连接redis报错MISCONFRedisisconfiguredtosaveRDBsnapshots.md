title: 连接redis报错MISCONF Redis is configured to save RDB snapshots
date: '2019-11-11 16:19:40'
updated: '2019-11-11 16:19:40'
tags: [redis, 生产问题]
permalink: /articles/2019/11/11/1573460380600.html
---
#  连接redis报错MISCONF Redis is configured to save RDB snapshots

```bash
date: Mon Nov 11 16:11:24 CST 2019
笔者：张首富
```
## 程序报错如下


> redis.exceptions.ResponseError: MISCONF Redis is configured to save RDB snapshots, but it is currently not able to persist on disk. Commands that may modify the data set are disabled, because this instance is configured to report errors during writes if RDB snapshotting fails (stop-writes-on-bgsave-error option). Please check the Redis logs for details about the RDB error.

翻译：
> redis.exceptions.ResponseError：MISCONF Redis配置为保存RDB快照，但当前无法持久保存在磁盘上。 禁用了可能修改数据集的命令，因为此实例配置为在RDB快照失败时在写入过程中报告错误（stop-writes-on-bgsave-error选项）。 请检查Redis日志以获取有关RDB错误的详细信息。

## 分析处理
从上面报错信息我们很清楚的可以看的出来试redis在进行RDB持久化操作的时候写入磁盘的时候出现了问题，出现这类问题有大概下面几种情况：
1，磁盘出现损坏(很少出现)
2，写持久化数据的磁盘满了
3，磁盘访问不到了(针对远程存储)
4，对磁盘的访问权限不足(应该是最多发生的)

我们到redis上查看redis的日志发现符合上面的第四点，所以我们对目录的权限进行了修改，然后问题得以解决