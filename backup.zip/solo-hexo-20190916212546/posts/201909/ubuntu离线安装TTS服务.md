title: ubuntu离线安装TTS服务
date: '2019-09-06 14:41:53'
updated: '2019-09-06 14:41:53'
tags: [工具, 生产经验]
permalink: /articles/2019/09/06/1567752113431.html
---
# ubuntu离线安装TTS服务

```bash
笔者: 张首富
时间: 2019-02-01
```
## 安装NVIDIA显卡(离线安装,在root下执行)
### 关闭X server

```bash
/etc/init.d/lightdm stop
```
###屏蔽开源驱动 nouveau
```bash
cat >> /etc/modprobe.d/blacklist.conf <<'EOF'
blacklist vga16fb
blacklist nouveau
blacklist rivafb
blacklist nvidiafb
blacklist rivatv
EOF
sudo update-initramfs -u
```
重启后执行：

```bash
lsmod | grep nouveau
//无输出表示成功
```
### 删除旧NVIDIA驱动

```bash
sudo apt-get --purge remove nvidia-*(需要清除干净)
sudo apt-get --purge remove xserver-xorg-video-nouveau
```

### 安装NVIDIA显卡驱动
显卡驱动从nvidia官网自行下取
```bash
 /bin/bash  NVIDIA-Linux-x86_64-384.145.run –no-x-check -no-nouveau-check -no-opengl-files
```

### 检查NVIDIA显卡是否安装正常

```bash
root@TTS:~# nvidia-smi
Fri Feb  1 16:08:55 2019
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 384.130                Driver Version: 384.130                   |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|===============================+======================+======================|
|   0  GeForce GTX 108...  Off  | 00000000:02:00.0 Off |                  N/A |
| 23%   31C    P0    57W / 250W |      0MiB / 11172MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+
|   1  GeForce GTX 108...  Off  | 00000000:03:00.0 Off |                  N/A |
| 23%   40C    P0    58W / 250W |      0MiB / 11172MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+
|   2  GeForce GTX 108...  Off  | 00000000:82:00.0 Off |                  N/A |
| 23%   39C    P0    58W / 250W |      0MiB / 11172MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+
|   3  GeForce GTX 108...  Off  | 00000000:83:00.0 Off |                  N/A |
| 23%   38C    P0    58W / 250W |      0MiB / 11172MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+

+-----------------------------------------------------------------------------+
| Processes:                                                       GPU Memory |
|  GPU       PID   Type   Process name                             Usage      |
|=============================================================================|
|  No running processes found                                                 |
+-----------------------------------------------------------------------------+
```
### 重启服务器

```bash
init 6 或者 reboot
```

### 重启之后不能通过图形化桌面进入系统,按`Ctrl+Alt+F1`进入字符界面