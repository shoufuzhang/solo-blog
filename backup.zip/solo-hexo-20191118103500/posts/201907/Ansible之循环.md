title: Ansible之循环
date: '2019-07-19 18:05:19'
updated: '2019-07-19 18:05:19'
tags: [Ansible]
permalink: /articles/2019/07/19/1563530719692.html
---
# Ansible之循环
## 标准循环
为了保持playbook的简洁，重复的任务可以以下面的方式简写

```yaml
[root@master_11 playbook]# cat z10.yaml 
- hosts: node3
  tasks:
    - name: touch file
      file: name=/tmp/{{ item }} state=touch
      with_items:
        - testfile1
        - testfile2
```

还可以利用vars里面定义的列表来完成此次循环

上述代码就等于：

```yaml
[root@master_11 playbook]# cat z10.yaml 
- hosts: node3
  tasks:
    - name: touch testfile1
      touch: name=testfile1 state=touch
    
    - name: touch testfile2
      touch: name=testfile2 state=touch
```

##  一次循环多个值

```yaml
- hosts: node3
  tasks:
    - name: add several users
      user: name={{ item.name }} state=present groups={{ item.groups }}
      with_items:
        - { name: 'testuser1', groups: 'wheel' }
        - { name: 'testuser2', groups: 'root' }
```

## 列表循环

利用vars提前定义列表变量，然后with_items来引用他
```yaml
[root@master_11 playbook]# cat z10.yaml 
- hosts: node3
  vars:
    - list: [test_file_1,test_file_2]
  tasks:
    - name: touch file
      file: name=/tmp/{{ item }} state=touch
      with_items: '{{ list }}'
```

**执行结果**

```yaml
[root@master_11 playbook]# ansible-playbook z10.yaml 

PLAY [node3] *****************************************************************

TASK [Gathering Facts] *******************************************************
ok: [10.0.0.13]

TASK [touch file] *************************************************************
changed: [10.0.0.13] => (item=test_file_1)
changed: [10.0.0.13] => (item=test_file_2)

PLAY RECAP ********************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0   
```
在touch file过程中，明显看到item被变量替换了

## 哈希列表的循环
```yaml
[root@master_11 playbook]# cat z11.yaml 
- hosts: node3
  tasks:
    - name: new user add
      user: name={{ item.username }} groups={{ item.groups }} state=present
      with_items:
        - { username: "zsf", groups: "root" }
        - { username: "zmy", groups: "root" }
```

执行结果
```yaml
[root@master_11 playbook]# ansible-playbook z11.yaml 

PLAY [node3] ***********************************************************************

TASK [Gathering Facts] **********************************************************
ok: [10.0.0.13]

TASK [new user add] *********************************************************
ok: [10.0.0.13] => (item={u'username': u'zsf', u'groups': u'root'})
ok: [10.0.0.13] => (item={u'username': u'zmy', u'groups': u'root'})

PLAY RECAP ******************************************************************
10.0.0.13                  : ok=2    changed=0    unreachable=0    failed=0 
```

## 嵌套循环

```yaml
[root@master_11 playbook]# cat z12.yaml 
- hosts: node3
  tasks:
  - name:  recursively touch mkdir
    file: name=/tmp/{{ item[0]}}/{{ item[1] }} state=directory
    with_nested:
      - [ 'test_1','test_2']
      - [ 'dir_1','dir_2','dir_3']
```

执行结果：

```yaml
[root@master_11 playbook]# ansible-playbook z12.yaml 

PLAY [node3] *************************************************************************

TASK [Gathering Facts] **************************************************************
ok: [10.0.0.13]

TASK [recursively touch mkdir] ******************************************************
changed: [10.0.0.13] => (item=[u'test_1', u'dir_1'])
changed: [10.0.0.13] => (item=[u'test_1', u'dir_2'])
changed: [10.0.0.13] => (item=[u'test_1', u'dir_3'])
changed: [10.0.0.13] => (item=[u'test_2', u'dir_1'])
changed: [10.0.0.13] => (item=[u'test_2', u'dir_2'])
changed: [10.0.0.13] => (item=[u'test_2', u'dir_3'])

PLAY RECAP *************************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0  
```
从上述执行结果可以看书，嵌套循环，循环层次是按照with_netste的循环列表的上下位置所决定的，最上面一层就对应着列表的最外面一层

利用预定义变量的写法

```yaml
[root@master_11 playbook]# cat z12.yaml 
- hosts: node3
  vars:
    dir_test: [ 'test_1','test_2']
  tasks:
  - name:  recursively touch mkdir
    file: name=/tmp/{{ item[0] }}/{{ item[1] }} state=absent
    with_nested:
      - [ 'dir_1','dir_2','dir_3']
      - "{{ dir_test }}"
```

## 对哈希表循环：（key values模式）

```yaml
[root@master_11 playbook]# cat z13.yaml 
- hosts: node3
  vars:
    users:
      alice:
        name: Alice Appleworth
        telephone: 123-456-7890
      bob:
        name: Bob Bananarama
        telephone: 987-654-3210
  tasks:
    - name: print phone records
      debug: msg="User {{ item.key }} is {{ item.value.name }} ({{ item.value.telephone }})"
      with_dict: "{{ users }}"
```

执行结果：
```yaml
[root@master_11 playbook]# ansible-playbook z13.yaml 

PLAY [node3] *************************************************************************************************

TASK [Gathering Facts] ***************************************************************************************
ok: [10.0.0.13]

TASK [print phone records] ***********************************************************************************
ok: [10.0.0.13] => (item={'value': {u'name': u'Bob Bananarama', u'telephone': u'987-654-3210'}, 'key': u'bob'}) => {
    "msg": "User bob is Bob Bananarama (987-654-3210)"
}
ok: [10.0.0.13] => (item={'value': {u'name': u'Alice Appleworth', u'telephone': u'123-456-7890'}, 'key': u'alice'}) => {
    "msg": "User alice is Alice Appleworth (123-456-7890)"
}

PLAY RECAP ***************************************************************************************************
10.0.0.13                  : ok=2    changed=0    unreachable=0    failed=0   
```
* bob和alice是变量的key，然后name，telephone 是变量值对应的名称