title: kubernetes 之 Ingress
date: '2019-07-19 17:48:35'
updated: '2019-07-19 17:48:35'
tags: [kubernetes, Network, Ingress]
permalink: /articles/2019/07/19/1563529715618.html
---
# kubernetes 之 Ingress
## 什么是Ingress
在Kubernetes中，服务和Pod的IP地址仅可以在集群网络内部使用，对于集群外的应用是不可见的。为了使外部的应用能够访问集群内的服务，在Kubernetes中可以通过NodePort和LoadBalancer这两种类型的服务，或者使用Ingress。Ingress本质是通过http代理服务器将外部的http请求转发到集群内部的后端服务。Kubernetes目前支持GCE和nginx控制器；另外，F5网络为Kubernetes提供了F5 Big-IP控制器。通过Ingress，外部应用访问群集内容服务的过程如下所示。
![image.png](https://img.hacpai.com/file/2019/07/image-8e453f1e.png)
Ingress控制器通常会使用负载均衡器来负责实现Ingress，尽管它也可以通过配置边缘路由器或其它前端以HA方式处理流量.

## Ingress配置文件
Ingress的yaml文件
```yaml
apiVersion: extensions/v1beta1 
kind: Ingress 
metadata: 
  name: test-ingress 
spec: 
  rules: 
  - host: test.crm.com
    http: 
    paths: 
    - path: /admin 
      backend: 
        serviceName: test 
        servicePort: 80
```
* 前4行代表和所有的yaml文件一样,定义了apiVersion,kind(类型),metadata(元数据).
* 下面就是代理的一些规则,
一定要注意paths:下面的 每个http规则都包含以下信息：一个主机（例如：test.crm.com，在这个例子中为*），一个路径列表（例如：/testpath），每个路径都有一个相关的后端（test：80）。在负载均衡器将业务引导到后端之前，**主机和路径都必须匹配传入请求的内容。** 意思就是:你网站有多个层级就要写多少次

## Ingress类型
### 代理单一服务

```bash
apiVersion: extensions/v1beta1 
kind: Ingress 
metadata: 
  name: test-ingress 
spec: 
  rules: 
  - host: test.crm.com
    http: 
    paths: 
    - path: /admin 
      backend: 
        serviceName: test 
        servicePort: 80
    - path: /mould 
      backend: 
        serviceName: test 
        servicePort: 80 
```
通过kubectl create -f创建上述的Ingress，在创建后可以通过kubectl get ing的命令获取Ingress的列表信息：

### 代理多个服务

```bash
foo.bar.com -> 178.91.123.132 -> / foo    service1:4200
                                 / bar    service2:8080
```


```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: simple-fanout-example
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: foo.bar.com
    http:
      paths:
      - path: /foo
        backend:
          serviceName: service1
          servicePort: 4200
      - path: /bar
        backend:
          serviceName: service2
          servicePort: 8080
```