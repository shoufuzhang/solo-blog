title: prometheus 基础概念
date: '2019-10-29 08:30:57'
updated: '2019-10-29 08:30:57'
tags: [prometheus]
permalink: /articles/2019/10/29/1572309057261.html
---
# prometheus 基础概念
不管做什么事情，我们都需要做好充足的准备。盖房子需要打地基，根基不稳地动山摇。我们学习也一样，所以我们想学好一个东西必须根基要打牢。好了废话不多说了，我们来打下prometheus的根基。
##数据模型
prometheus存储是时序数据（time-series），即按照相同时许（相同的名字和标签），以时间维度存储连续的数据的集合。
### 时序索引
时序（time series）是由名字（metrice），以及一组`key/value`标签定义的，具有相同的名字以及标签属于同一时间序列。
时序的名字有ASCLL字符，数字，下划线，以及冒号组成，它必须满足正则表达式`[a-zA-Z_:][a-zA-Z0-9_:]*`，其名字因该具有语义化（看到名字就知道这个抓取的是什么值），一般表示一个可以度量的指标，例如：`http_requset_total`，表示http的总请求数。
时序的标签可以使prometheus的数据更加丰富，能够区分具体不同的实例，例如`http_requests_total{method="POST"}`，可以表示所有的POST请求。
标签名称有ASCLL字符，数字，以及下划线组成，其中`_`开头的属于prometheus保留，标签的只可以是任何ubicode字符，支持中文

### 时序样本
按照莫哥时序以时间维度采集的数据，称之为样本，其值包含：
* 一个float64值
* 一个毫秒级的unix时间戳

### 格式
prometheus 时序格式 与OPenTSDB相似
<metric name>{<label name>=<label value>,....}
其中包含时序名字以及时序的标签。

## Metrice types
### counter 计数器
获取的数值，只增加（减少），理想状态下是不会减少(增加)的。我们往往用它记录服务的请求总量，错误总数

### Gauge 瞬时值
最简单的度量指标，只有一个简单的返回值，或者叫做瞬时状态，例如：监控硬盘或者内存的使用量，在当前时间只有一个值，因为硬盘的容量和内存的使用量是随着时间的推移不断变化，没有规律可循

### Histogram
统计数据的分布情况，比如最大值，最小值，中间值还有中位数，75百分位，这是一种特殊的metrics数据类型，代表的是一种近似百分比

### summary
summary和histogram类似，由`<basename>{quantile="<>"}`,`<basename>_sum`,`<basename>_count`组成，主要用于表示一段时间内数据采样结果（通常是请求持续时间或响应大小），它直接存储了quantile数据，而不是根据统计出区间计算出来的