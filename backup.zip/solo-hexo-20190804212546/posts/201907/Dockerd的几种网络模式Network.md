title: Dockerd的几种网络模式Network
date: '2019-07-17 21:21:00'
updated: '2019-07-17 21:24:08'
tags: [Docker, Network]
permalink: /articles/2019/07/17/1563369660642.html
---
# Docker Network
## docker默认网络
安装docker时他会自动创建三个网络。使用`docker network ls` 命令来查看
```bash
[root@docker ~]# docker network ls 
NETWORK ID          NAME                DRIVER              SCOPE
08fa0d8334fc        bridge              bridge              local
8708a8affa68        host                host                local
4c2dcdaeb0e9        none                null                local
```

在`docker run`运行一个新的容器的时候，使用`--network network_name`指定这个容器使用的网络模式。
docker continue 启动时默认使用`bridge`网络。使用`docker run --network network_name`选项可以更改容器默认的网络
## bridge网络模式
相当于Vmware中的Nat模式，容器使用独立network Namespaces，并连接到Docker0虚拟网卡（默认）。通过docker0网桥以及`iptables nat`表配置与宿主机通信；bridge模式是docker默认的网络设置，此模式会为每一个容器分配Network Namespace，设置IP等，并将一个主机上的Docker continue 连接到一个虚拟网桥上。
### docker bridge模式的拓扑
当Docker server启动时，会在主机上创建一个名为`docker0`的虚拟网桥，此主机上启动的`Docker`容器会连接到这个虚拟网桥上。虚拟网桥的工作方式和物理交换机类似，这样主机上的所有容器就通过交换机连在了一个二层网络中。接下来就是为容器分配`IP`了，Docker会从`RFC1918`所定义的私有IP网段中，选择一个和宿主机不同的IP地址和子网分配给Docker0，连接到Docker0的容器就从这个子网中选择一个未占用的IP使用。现在docker默认的是`172.17.0.1/24`这个网段。

每当我们启动一个`docker continue`的时候，他会生成一对虚拟网卡，一块在docker continue另外一块在docker宿主机上，网络拓扑图如下
![image.png](https://img.hacpai.com/file/2019/07/image-7d1f7ff1.png)
![-w949](media/15433175514122/15434207899576.jpg)
Docker 完成以上网络配置的过程大概是这样的：
* 1，在主机上创建一对虚拟网卡`veth pair`设备。Veth设备总是城管队出现的，他们组成了一个数据的通道，数据从一个设备进入，就会从另外一个设备出来。因此，veth设备常用来连接两个网络设备。
* 2，docker将`veth pair`设备的一端放在心创建的容器中，并命名为eth0。另外一端放在主机中，以`veth70e436b`这样类似的名字命令，并将这个网络设备加入到`docker0`网桥中，

```bash
[root@docker ~]# ifconfig veth70e436b
veth70e436b: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet6 fe80::40d:67ff:feb1:331  prefixlen 64  scopeid 0x20<link>
        ether 06:0d:67:b1:03:31  txqueuelen 0  (Ethernet)
        RX packets 0  bytes 0 (0.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 16  bytes 1296 (1.2 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

[root@docker ~]# yum -y install bridge-utils 
[root@docker ~]# brctl show
bridge name	bridge id		STP enabled	interfaces
docker0		8000.0242c641b55c	no		veth70e436b
```
查看容器和宿主机之间的网桥
```bash
[root@docker ~]# docker run -it --name test_bridge --rm busybox:latest 
/ # ip link show
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
5: eth0@if6: <BROADCAST,MULTICAST,UP,LOWER_UP,M-DOWN> mtu 1500 qdisc noqueue 
    link/ether 02:42:0a:0a:0a:02 brd ff:ff:ff:ff:ff:ff
    
[root@docker ~]# ip link show
6: veth70e436b@if5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master docker0 state UP mode DEFAULT group default 
    link/ether 06:0d:67:b1:03:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
```
### 模拟不同net Namespace之间的通信

```bash
[root@docker ~]# ip netns add n1
[root@docker ~]# ip netns add n2
[root@docker ~]# ip netns list 
n2
n1
[root@docker ~]# ip link  add  name veth1.1 type veth peer name veth1.2
[root@docker ~]# ip link show type veth
6: veth70e436b@if5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master docker0 state UP mode DEFAULT group default 
    link/ether 06:0d:67:b1:03:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
7: veth1.2@veth1.1: <BROADCAST,MULTICAST,M-DOWN> mtu 1500 qdisc noop state DOWN mode DEFAULT group default qlen 1000
    link/ether c2:1a:9f:59:ad:f9 brd ff:ff:ff:ff:ff:ff
8: veth1.1@veth1.2: <BROADCAST,MULTICAST,M-DOWN> mtu 1500 qdisc noop state DOWN mode DEFAULT group default qlen 1000
    link/ether 76:c9:b1:c3:02:3f brd ff:ff:ff:ff:ff:ff
    
    [root@docker ~]# ip link set dev veth1.2 netns n2
[root@docker ~]# ifconfig veth1.1 172.16.1.1/24 up
[root@docker ~]# ifconfig veth1.1
veth1.1: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.16.1.1  netmask 255.255.255.0  broadcast 172.16.1.255
        inet6 fe80::74c9:b1ff:fec3:23f  prefixlen 64  scopeid 0x20<link>
        ether 76:c9:b1:c3:02:3f  txqueuelen 1000  (Ethernet)
        RX packets 8  bytes 648 (648.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 8  bytes 648 (648.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
        
[root@docker ~]# ip netns exec n2 ifconfig veth1.2 172.16.1.2/24 up
[root@docker ~]# ip netns exec n2 ifconfig veth1.2
veth1.2: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.16.1.2  netmask 255.255.255.0  broadcast 172.16.1.255
        inet6 fe80::c01a:9fff:fe59:adf9  prefixlen 64  scopeid 0x20<link>
        ether c2:1a:9f:59:ad:f9  txqueuelen 1000  (Ethernet)
        RX packets 8  bytes 648 (648.0 B)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 8  bytes 648 (648.0 B)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
veth1.1相当于docker continue里面的虚拟网卡在宿主机上虚拟网桥的网卡
veth1.2就是docker continue里面的虚拟网卡，他们两个是成对的
```

### bridge模式下容器的通信
在bridge模式下，连在同一个网桥上的容器可以直接互相通信（因为他们处于在同一个局域网），出于安全考虑我们禁止他们之间通信，方法是在`DOCKER_OPTS变量中设置-icc=false`，设置完这个参数之后，只有`run`运行的时候使用`--link`的容器才能互相通信。

### 更改默认bridge使用的网络

```bash
[root@docker ~]# cat /etc/docker/daemon.json
{
  "bip": "10.10.10.1/24",
}
```
## host网路模式

## none网络模式

## docker continue使用host名称通信
