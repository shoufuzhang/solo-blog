title: FastDFS集群搭建
date: '2019-07-17 21:42:52'
updated: '2019-07-17 21:42:52'
tags: [分布式存储, FastDFS]
permalink: /articles/2019/07/17/1563370972893.html
---
# FastDFS集群搭建
## 环境搭建与主机说明
1) 主机环境
```bash
[root@zsf_shell skel]# uname -a
Linux zsf_shell 3.10.0-862.el7.x86_64 #1 SMP Fri Apr 20 16:44:24 UTC 2018 x86_64 x86_64 x86_64 GNU/Linux
```

2) 主机名和IP地址的规划

```bash
10.0.0.10/24 zsf_tar_ser
10.0.0.21/24 zsf_stor_01
10.0.0.22/24 zsf_stor_02
10.0.0.61/24 zsf_nginx
10.0.0.66/24 zsf_mysql
```

3) 基础环境准备
在所有的tracker和storage上安装基础环境包
```bash
yum -y install gcc gcc-c++ -y
yum -y install tree  lsof lrzsz net-tools
//关闭selinux和firewalld防火墙
cd /usr/local/
 wget https://github.com/happyfish100/libfastcommon/archive/V1.0.36.tar.gz
 tar xf V1.0.36.tar.gz 
 ln -s libfastcommon-1.0.36/ libfastcommon
 cd libfastcommon
 ./make.sh && ./make.sh install
```

4）编译安装tracker节点

```bash
[root@zsf_tra_ser local]# wget https://github.com/happyfish100/fastdfs/archive/V5.08.zip
[root@zsf_tra_ser local]# unzip V5.08.zip
[root@zsf_tra_ser local]# ln -s fastdfs-5.08/ fastdfs
[root@zsf_tra_ser local]# cd fastdfs
[root@zsf_tra_ser fastdfs]# ./make.sh  && ./make.sh install 
```

5) 编译安装storage节点

```bash
[root@zsf_stor_01 local]# wget https://github.com/happyfish100/fastdfs/archive/V5.08.zip
[root@zsf_stor_01 local]# unzip V5.08.zip
[root@zsf_stor_01 local]# ln -s fastdfs-5.08/ fastdfs
[root@zsf_stor_01 local]# cd fastdfs
[root@zsf_stor_01 fastdfs]# ./make.sh  && ./make.sh install 
```

6）测试启动

```bash
[root@zsf_tra_ser fastdfs]# cd /etc/fdfs/
[root@zsf_tra_ser fdfs]# cp tracker.conf.sample tracker.conf
[root@zsf_tra_ser fdfs]# mkdir -p /home/yuqing/fastdfs
// 创建这个目录是因为配置文件里面base_path路径是这个，如果不想创建请自行更改配置文件
[root@zsf_tra_ser fdfs]# /etc/init.d/fdfs_trackerd start
[root@zsf_tra_ser fdfs]# lsof -i:22122
COMMAND    PID USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
fdfs_trac 3320 root    5u  IPv4  37213      0t0  TCP *:22122 (LISTEN)
[root@zsf_tra_ser fdfs]# ps -ef | grep [f]dfs
root       3320      1  0 19:37 ?        00:00:00 /usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf
```

## 配置tracker节点
### tracker配置文件详解
```bash
# 这个配置文件是否无效，false表示有效
disabled=false

# 是否绑定IP
# bind_addr= 后面为绑定的IP地址 (经常使用于服务器有多个IP但仅仅希望一个IP提供服务)。假设不填则表示全部的(一般不填就OK)
bind_addr=

# 提供服务的端口
port=22122

# 连接超时时间，针对socket套接字函数connect
connect_timeout=30

# tracker server的网络超时，单位为秒。
network_timeout=60

base_path=/home/yuqing/fastdfs

# base_path 文件夹地址(根文件夹必须存在,子文件夹会自己主动创建)
# 附文件夹说明: 
#  tracker server文件夹及文件结构：
#  ${base_path}
#    |__data
#    |     |__storage_groups.dat：存储分组信息
#    |     |__storage_servers.dat：存储服务器列表
#    |__logs
#          |__trackerd.log：tracker server日志文件

#数据文件storage_groups.dat和storage_servers.dat中的记录之间以换行符（\n）分隔，字段之间以西文逗号（,）分隔。
#storage_groups.dat中的字段依次为：
#  1. group_name：组名
#  2. storage_port：storage server端口号

#storage_servers.dat中记录storage server相关信息，字段依次为：
#  1. group_name：所属组名
#  2. ip_addr：ip地址
#  3. status：状态
#  4. sync_src_ip_addr：向该storage server同步已有数据文件的源服务器
#  5. sync_until_timestamp：同步已有数据文件的截至时间（UNIX时间戳）
#  6. stat.total_upload_count：上传文件次数
#  7. stat.success_upload_count：成功上传文件次数
#  8. stat.total_set_meta_count：更改meta data次数
#  9. stat.success_set_meta_count：成功更改meta data次数
#  10. stat.total_delete_count：删除文件次数
#  11. stat.success_delete_count：成功删除文件次数
#  12. stat.total_download_count：下载文件次数
#  13. stat.success_download_count：成功下载文件次数
#  14. stat.total_get_meta_count：获取meta data次数
#  15. stat.success_get_meta_count：成功获取meta data次数
#  16. stat.last_source_update：近期一次源头更新时间（更新操作来自客户端）
#  17. stat.last_sync_update：近期一次同步更新时间（更新操作来自其它storage server的同步）

# 系统提供服务时的最大连接数。
max_connections=256

#工作线程数，通常设置为CPU数
work_threads=4

# 上传组(卷) 的方式 0:轮询方式 1: 指定组 2: 平衡负载(选择最大剩余空间的组(卷)上传)
# 这里假设在应用层指定了上传到一个固定组,那么这个參数被绕过
# the method of selecting group to upload files
# 0: round robin
# 1: specify group
# 2: load balance, select the max free space group to upload file
store_lookup=2

# 当上一个參数设定为1 时 (store_lookup=1，即指定组名时)，必须设置本參数为系统中存在的一个组名。假设选择其它的上传方式。这个參数就没有效了
# which group to upload file
# when store_lookup set to 1, must set store_group to the group name
store_group=group2

# 选择哪个storage server 进行上传操作(一个文件被上传后，这个storage server就相当于这个文件的storage server源，会对同组的storage server推送这个文件达到同步效果)
# 0: 轮询方式 
# 1: 依据ip 地址进行排序选择第一个服务器（IP地址最小者）
# 2: 依据优先级进行排序（上传优先级由storage server来设置，參数名为upload_priority）
# which storage server to upload file
# 0: round robin (default)
# 1: the first server order by ip address
# 2: the first server order by priority (the minimal)
store_server=0

# 选择storage server 中的哪个文件夹进行上传。

storage server能够有多个存放文件的base path（能够理解为多个磁盘）。


# 0: 轮流方式。多个文件夹依次存放文件
# 2: 选择剩余空间最大的文件夹存放文件（注意：剩余磁盘空间是动态的。因此存储到的文件夹或磁盘可能也是变化的）
store_path=0

# 选择哪个 storage server 作为下载服务器 
# 0: 轮询方式，能够下载当前文件的任一storage server
# 1: 哪个为源storage server 就用哪一个 (前面说过了这个storage server源 是怎样产生的) 就是之前上传到哪个storage server服务器就是哪个了
download_server=0

# storage server 上保留的空间，保证系统或其它应用需求空间。能够用绝对值或者百分比（V4開始支持百分比方式）。
#(指出 假设同组的服务器的硬盘大小一样,以最小的为准,也就是仅仅要同组中有一台服务器达到这个标准了,这个标准就生效,原因就是由于他们进行备份)
reserved_storage_space = 10%

# 选择日志级别
log_level=info

# 操作系统执行FastDFS的用户组 (不填 就是当前用户组,哪个启动进程就是哪个)
run_by_group=

# 操作系统执行FastDFS的用户 (不填 就是当前用户,哪个启动进程就是哪个)
run_by_user=

# 能够连接到此 tracker server 的ip范围（对全部类型的连接都有影响，包含客户端，storage server）
allow_hosts=*

# 同步或刷新日志信息到硬盘的时间间隔，单位为秒
sync_log_buff_interval = 10

# 检測 storage server 存活的时间隔，单位为秒。
check_active_interval = 120

# 线程栈的大小。

FastDFS server端採用了线程方式。

tracker server线程栈不应小于64KB
# 线程栈越大，一个线程占用的系统资源就越多。

假设要启动很多其它的线程（V1.x相应的參数为max_connections，
thread_stack_size = 64KB

# 这个參数控制当storage server IP地址改变时，集群是否自己主动调整。
注：仅仅有在storage server进程重新启动时才完毕自己主动调整
storage_ip_changed_auto_adjust = true

# V2.0引入的參数。存储服务器之间同步文件的最大延迟时间。缺省为1天。
依据实际情况进行调整
# 注：本參数并不影响文件同步过程。本參数仅在下载文件时，推断文件是否已经被同步完毕的一个阀值（经验值）
storage_sync_file_max_delay = 86400

# V2.0引入的參数。存储服务器同步一个文件须要消耗的最大时间。缺省为300s。即5分钟。

# 注：本參数并不影响文件同步过程。本參数仅在下载文件时，作为推断当前文件是否被同步完毕的一个阀值（经验值）
storage_sync_file_max_time = 300


#是否使用小文件合并存储特性，缺省是关闭的
use_trunk_file = false 

# V3.0引入的參数。


# trunk file分配的最小字节数。比方文件仅仅有16个字节。系统也会分配slot_min_size个字节
slot_min_size = 256

假设一个文件的大小大于这个參数值。将直接保存到一个文件里（即不採用合并存储方式）。
slot_max_size = 16MB

# V3.0引入的參数。
# 合并存储的trunk file大小，至少4MB，缺省值是64MB。

不建议设置得过大
trunk_file_size = 64MB

# 是否提前创建trunk file。仅仅有当这个參数为true，以下3个以trunk_create_file_打头的參数才有效
trunk_create_file_advance = false

# 提前创建trunk file的起始时间点（基准时间）。02:00表示第一次创建的时间点是凌晨2点
trunk_create_file_time_base = 02:00

# 创建trunk file的时间间隔，单位为秒。假设每天仅仅提前创建一次，则设置为86400
trunk_create_file_interval = 86400

# 提前创建trunk file时，须要达到的空暇trunk大小
# 比方本參数为20G。而当前空暇trunk为4GB，那么仅仅须要创建16GB的trunk file就可以
trunk_create_file_space_threshold = 20G

# trunk初始化时，是否检查可用空间是否被占用
trunk_init_check_occupying = false

# 是否无条件从trunk binlog中载入trunk可用空间信息
trunk_init_reload_from_binlog = false

# 是否使用server ID作为storage server标识
use_storage_id = false

# use_storage_id 设置为true，才须要设置本參数
storage_ids_filename = storage_ids.conf

#文件名称中的id类型，有ip和id两种，仅仅有当use_storage_id设置为true时该參数才有效
id_type_in_filename = ip

# 存储从文件是否採用symbol link（符号链接）方式
store_slave_file_use_link = false

# 是否定期轮转error log。眼下仅支持一天轮转一次
rotate_error_log = false

# error log定期轮转的时间点，仅仅有当rotate_error_log设置为true时有效
error_log_rotate_time=00:00

# error log按大小轮转
# 设置为0表示不按文件大小轮转。否则当error log达到该大小。就会轮转到新文件里
rotate_error_log_size = 0

# 是否使用连接池
use_connection_pool = false

# 假设一个连接的空暇时间超过这个值将会被自己主动关闭
connection_pool_max_idle_time = 3600

# 用于提供http服务的端口
http.server_port=8080

# 检查http server是否还在工作的时间间隔。假设该值小于0则永远不检查
http.check_alive_interval=30

# 检查http server是否存活的类型，有tcp和http两种
# tcp方式仅仅有http端口被连接
# http方式检查必须返回状态值200
http.check_alive_type=tcp
```

更改tarcker端的配置文件

```bash
[root@zsf_tra_ser fdfs]# grep -E '^[a-Z]' tracker.conf
disabled=false
bind_addr=10.0.0.10                 //绑定的IP
port=22122                          //绑定的端口
connect_timeout=30                  //连接超时时间
network_timeout=60                  //网络超时时间
base_path=/data/fdfs_tracker/base   //存放数据和日志文件的路径
max_connections=20480               //最大并发连接数
work_threads=1                      //工作线程数，最好设置的跟CPU核心数一致
reserved_storage_space = 5%         //保留的磁盘空间
```

### storage节点配置文件
配置文件详解

```bash
#这个配置文件是否失效
disabled=false
 
# 本storage server所属的group名
group_name=group1
 
# 可以版定一个ip，默认为空，绑定所有ip
bind_addr=
 
# 本配置只有在bind_addr设置以后才生效
# 本机作为客户端访问其他服务时，是否使用绑定的ip去访问其他服务器
client_bind=true
 
# storage server监听端口
port=23000
 
# 连接超时时间，针对socket套接字函数connect，默认为30秒
connect_timeout=30
 
# 网络通讯超时时间，默认是60秒
network_timeout=60
 
# 向tracker server发送心跳时间间隔，默认30秒
heart_beat_interval=30
 
# 向tracker server汇报磁盘使用情况时间间隔，默认为60秒
stat_report_interval=60
 
# 工作文件夹，日志也存在此(这里不是上传的文件存放的地址)
base_path=/home/yuqing/fastdfs
 
# 本traceserver最大连接数
max_connections=256
 
# 发送或接收数据的buffer大小，工作队列消耗的内存大小 = buff_size * max_connections
# 建议这个设置大于8k，默认256k
buff_size = 256KB
 
# 接收数据的线程数
# 默认1个
# since V4.07
accept_threads=1
 
# 工作线程数，小于max_connections
# 默认4个，通常设置为CPU核数，效率最高
work_threads=4
 
# 磁盘读写是否分离，默认为true
disk_rw_separated = true
 
# 磁盘读取的线程数（每个工作文件夹）
# 对于磁盘读写不分离的模式，这个参数可以设置为0
# 默认为1
disk_reader_threads = 1
 
# 磁盘写的线程数（每个工作文件夹）
# 对于磁盘读写不分离的模式，这个参数可以设置为0
# 默认为1
disk_writer_threads = 1
 
# 当发现没有需要同步的文件时，需要等待sync_wait_msec毫秒再去binlog中检查
# 不能设置为0，默认为50毫秒
sync_wait_msec=50
 
# 同步完一个文件后，休眠sync_interval毫秒后继续同步下一个文件
sync_interval=0
 
# 允许存储同步的开始时间
# Hour from 0 to 23, Minute from 0 to 59
sync_start_time=00:00
 
# 允许存储同步的结束时间，也就是说，storage server只能在sync_start_time到sync_end_time这段时间内同步数据
# 默认是全天都可以同步
# Hour from 0 to 23, Minute from 0 to 59
sync_end_time=23:59
 
# 同步完write_mark_file_freq个文件后，如果markfile有变化，将mark file写入磁盘
write_mark_file_freq=500
 
# 工作路径个数（可以挂载多个磁盘），默认是1个
store_path_count=1
 
# 工作路径列表，如果store_path0不设置，那么使用base_path存储
# 设置的路径一定是存在的文件夹
# 需要配置store_path_count个
store_path0=/home/yuqing/fastdfs
#store_path1=/home/yuqing/fastdfs2
 
# FastDFS是通过二级目录来存储文件的，该配置是每级目录的文件夹数据
# 如果设置为256，那么会生成256*256＝65535个文件夹
# 这个值默认大小256，可以设置区间1-256
subdir_count_per_path=256
 
# tracer server列表，多个tracer server的话，分行列出
tracker_server=192.168.209.121:22122
 
#日志级别
### emerg for emergency
### alert
### crit for critical
### error
### warn for warning
### notice
### info
### debug
log_level=info
 
# 运行本进程的Unix用户组，如果不设置，默认是当前用户所在的group
run_by_group=
 
# 运行本进程的用户名，如果不设置，默认是当前用户的用户名
run_by_user=
 
# 可以连接到本机的主机ip范围,*代表允许所有服务器
# 支持这样的表达式:10.0.1.[1-15,20] or host[01-08,20-25].domain.com
allow_hosts=*
 
# 文件分布式存储策略
# 0: 轮询
# 1: 根据文件名hash结果随机存储
file_distribute_path_mode=0
 
# 本配置在 file_distribute_path_mode=0 时有效
# 当写文件数据达到file_distribute_rotate_count值时，换轮换到另外一个路径继续写入
# 本配置默认值是100
file_distribute_rotate_count=100
 
# 是否在写大文件的时候，调用fsync落地文件
# 0:永远不调用
# 其他数值：每写入fsync_after_written_bytes个字节，调用一次fsync
# 默认为0
fsync_after_written_bytes=0
 
# 将缓存中的日志落地到磁盘的间隔时间，默认是10秒
sync_log_buff_interval=10
 
# 将缓存中的binlog落地到磁盘的间隔时间，默认是10秒
sync_binlog_buff_interval=10
 
# 将storage server缓存中的状态数据落地到磁盘的间隔时间，默认是10秒
sync_stat_file_interval=300
 
# 线程栈大小，默认64k，不建议设置小于64k，默认512k
thread_stack_size=512KB
 
# 和 tracker.conf 中store_server= 2时的配置相对应，本storage server作为目标服务器，上传文件的优先级，可以为负数。值越小，优先级越高。
# tracker.conf 中store_server参数的描述:
# 上传文件选择服务器的规则:
# 0:轮询（默认）
# 1:按照IP排序，排在第一的server
# 2:按照优先级排序，最小的server
upload_priority=10
 
# 网卡别名，用ifconfig -a可以看到很多本机的网卡别名，类似eth0,eth0:0等等
# 多个网卡别名使用逗号分割，默认为空，让系统自动选择
if_alias_prefix=
 
# 是否检查重复文件，如果设置成true，使用FastDHT来存储文件索引
# 1 or yes: 需要检查
# 0 or no: 不需要检查
# 默认值是 0
check_file_duplicate=0
 
# 文件签名形式，hash或md5，用来做文件排重，默认为hash
file_signature_method=hash
 
# 存储文件索引的命名空间（在check_file_duplicate=1是生效）
key_namespace=FastDFS
 
# 是否和FastDHT之间使用长连接
# 0代表短链接，1代表长连接
# 默认值为0
keep_alive=0
 
# 可以使用#include filename来加载FastDHT服务器列表，filename可以是相对路径（基于base_path）
# 在check_file_duplicate=1时有效
# 更多信息参见FastDHT的安装须知
##include /home/yuqing/fastdht/conf/fdht_servers.conf
 
# 是否记录访问日志
use_access_log = false
 
# 是否定期轮转访问日志，目前仅支持一天轮转一次
rotate_access_log = false
 
# 如果按天轮转访问日志，具体生成新错误日志文件的时间
# Hour from 0 to 23, Minute from 0 to 59
access_log_rotate_time=00:00
 
# 是否定期轮转错误日志，目前仅支持一天轮转一次
rotate_error_log = false
 
# 如果按天轮转错误日志，具体生成新错误日志文件的时间
# Hour from 0 to 23, Minute from 0 to 59
error_log_rotate_time=00:00
 
# 是否在错误访问文件达到一定大小时生成新的访问日志文件
# 0代表对日志文件大小不敏感
rotate_access_log_size = 0
 
# 是否在错误日志文件达到一定大小时生成新的错误日志文件
# 0代表对日志文件大小不敏感
rotate_error_log_size = 0
 
# 日志文件保存日期
# 0表示永久保存，不删除
# 默认为0
log_file_keep_days = 0 
 
# if skip the invalid record when sync file
# default value is false
# since V4.02
file_sync_skip_invalid_record=false
 
# 是否使用连接池
use_connection_pool = false
 
# 连接闲置超时时间，连接如果闲置的时间超过本配置，则关闭次连接，单位秒
connection_pool_max_idle_time = 3600
 
# storage server的http访问方式的域名，如果域名为空，则只能使用ip访问
http.domain_name=
 
# HTTP端口
http.server_port=8888

```


**更改两台storage节点，让他们为两个卷（组）**

```bash
[root@zsf_stor_01 fdfs]#  grep -E '^[a-Z]'  storage.conf
group_name=zsf
bind_addr=10.0.0.21
port=23000
base_path=/data/fdfs_storage/zsf/base
max_connections=256
store_path0=/data/fdfs_storage/zsf/store
tracker_server=10.0.0.10:22122
work_threads=1

[root@zsf_stor_02 fdfs]#  grep -E '^[a-Z]'  storage.conf
group_name=zmy
bind_addr=10.0.0.22
port=23000
base_path=/data/fdfs_storage/zmy/base
max_connections=256
store_path0=/data/fdfs_storage/zmy/store
tracker_server=10.0.0.10:22122
work_threads=1
```

### 集群状态说明
通过命令：`fdfs_monitor /etc/fdfs/client.conf`
```bash
# INIT :初始化，尚未得到同步已有数据的源服务器  

# WAIT_SYNC :等待同步，已得到同步已有数据的源服务器  

# SYNCING :同步中  # DELETED :已删除，该服务器从本组中摘除  

# OFFLINE :离线  

# ONLINE :在线，尚不能提供服务  

# ACTIVE :在线，可以提供服务
```
##启动测试

```bash
[root@zsf_tra_ser fdfs]# /usr/bin/fdfs_trackerd /etc/fdfs/tracker.conf restart
[root@zsf_stor_01 fdfs]# /usr/bin/fdfs_storaged /etc/fdfs/storage.conf start
[root@zsf_stor_02 fdfs]# /usr/bin/fdfs_storaged /etc/fdfs/storage.conf start
```

## 使用客户端操作FastDFS
先安装一个客户端

```bash
yum -y install gcc gcc-c++ tree  lsof lrzsz net-tools -y 
cd /usr/local/
wget https://github.com/happyfish100/libfastcommon/archive/V1.0.36.tar.gz
tar xf V1.0.36.tar.gz 
ln -s libfastcommon-1.0.36/ libfastcommon
cd libfastcommon
./make.sh && ./make.sh install
wget https://github.com/happyfish100/fastdfs/archive/V5.08.zip
cd ../
wget https://github.com/happyfish100/fastdfs/archive/V5.08.zip
unzip V5.08.zip
ln -s fastdfs-5.08/ fastdfs
cd fastdfs
./make.sh  && ./make.sh install
echo $?
cd /etc/fdfs/
ls 
cp client.conf.sample client.conf
vim client.conf

```

client配置文件

```bash
[root@zsf_nginx fdfs]# cat client.conf
# connect timeout in seconds
# default value is 30s
connect_timeout=30

# network timeout in seconds
# default value is 30s
network_timeout=60

# the base path to store log files
base_path=/data/fdfs_clinet/log

# tracker_server can ocur more than once, and tracker_server format is
#  "host:port", host can be hostname or ip address
tracker_server=10.0.0.10:22122

#standard log level as syslog, case insensitive, value list:
### emerg for emergency
### alert
### crit for critical
### error
### warn for warning
### notice
### info
### debug
log_level=info

# if use connection pool
# default value is false
# since V4.05
use_connection_pool = false

# connections whose the idle time exceeds this time will be closed
# unit: second
# default value is 3600
# since V4.05
connection_pool_max_idle_time = 3600

# if load FastDFS parameters from tracker server
# since V4.05
# default value is false
load_fdfs_parameters_from_tracker=false

# if use storage ID instead of IP address
# same as tracker.conf
# valid only when load_fdfs_parameters_from_tracker is false
# default value is false
# since V4.05
use_storage_id = false

# specify storage ids filename, can use relative or absolute path
# same as tracker.conf
# valid only when load_fdfs_parameters_from_tracker is false
# since V4.05
storage_ids_filename = storage_ids.conf


#HTTP settings
http.tracker_server_port=80

#use "#include" directive to include HTTP other settiongs
##include http.conf
```

上传文件
```bash
[root@zsf_nginx fdfs]# fdfs_upload_file /etc/fdfs/client.conf /etc/passwd
zmy/M00/00/00/CgAAFlvgPjuAZr0nAAAD_sONnPI7456944
```

指定分组(卷)上传
```bash
[root@zsf_nginx fdfs]# fdfs_upload_file /etc/fdfs/client.conf /etc/passwd 10.0.0.21:23000
zsf/M00/00/00/CgAAFVvgPk2ASldHAAAD_sONnPI5277577
```

下载文件
```bash
[root@zsf_nginx fdfs]# fdfs_download_file /etc/fdfs/client.conf zmy/M00/00/00/CgAAFlvgPjuAZr0nAAAD_sONnPI7456944
```

删除文件

```bash
[root@zsf_nginx fdfs]# fdfs_delete_file /etc/fdfs/client.conf zmy/M00/00/00/CgAAFlvgPjuAZr0nAAAD_sONnPI7456944
```


测试

```bash
// 先生成一个文件
[root@zsf_nginx tmp]# echo "test fastDFS file" >> test.txt
//上传到storage节点
[root@zsf_nginx tmp]# fdfs_upload_file /etc/fdfs/client.conf test.txt 
zmy/M00/00/00/CgAAFlvgP9eAGdMYAAAAElb_onE787.txt
//删除本地的文件
[root@zsf_nginx tmp]# rm -rf test.txt 
// 下载刚才那个文件
[root@zsf_nginx tmp]# fdfs_download_file /etc/fdfs/client.conf zmy/M00/00/00/CgAAFlvgP9eAGdMYAAAAElb_onE787.txt
[root@zsf_nginx tmp]# ls 
CgAAFlvgP9eAGdMYAAAAElb_onE787.txt
[root@zsf_nginx tmp]# cat CgAAFlvgP9eAGdMYAAAAElb_onE787.txt 
test fastDFS file
```

到此环境搭建完成，我们在实际工作中应该配合开发，来完成文件的上传和读取，这个东西不是 我们现在单纯测试能完成的