title: Docker 端口映射客户不能正常访问
date: '2019-09-02 16:52:24'
updated: '2019-09-02 16:52:24'
tags: [Docker, 生产经验]
permalink: /articles/2019/09/02/1567414344660.html
---
# Docker 端口映射客户不能正常访问

```bash
作者： 张首富
时间： 2019-09-02
```
## 问题描述
我在A服务器上启动了个apache的docker，使用命令如下

```bash
docker run -id -p 8080:80 --name test_apache -v /var/www/houtai:/var/www/houtai apache:latest
```
docker启动之后，使用`netstat -ntalp | grep 8080` 发现端口监听成功，然后就到客户机去发起请求发现请求不成功，提示连接失败，然后使用`telnet`发现8080端口不通，这个时候去检查`firewalld` 和`selinux`发现都是处于关闭状态，在A服务器上`telnet`8080端口发现正常通信，使用`iptables -t nat -L`检查`iptables`转发正常，但是就是不通，
## 问题解决办法
根据上面问题排查分析后 肯定是转发那一块出问题了，于是想到Linux转发要开启内核转发功能`net.ipv4.ip_forward`，于是检查内核转发是否打开

```bash
[root@localhost ~]# sysctl net.ipv4.ip_forward
net.ipv4.ip_forward = 0
```
发现状态为0代表内核转发没有打开，估计问题就是这个鬼造成的，于是打开内核转发参数

```bash
[root@localhost ~]# echo 1 > /proc/sys/net/ipv4/ip_forward
[root@localhost ~]# sysctl -p #刷新下内核参数
```
然后客户端再次请求发现正常。

## 反思
1，docker 的proxy在1.7 版本之后全部都依赖于`iptables`了
2，所以docker转发的时候实际上是在iptables上创建了一个转发规则，然后根据这个转发规则来进行转发
3，iptables需要转发就必须要开启网卡转发功能，也就是`net.ipv4.ip_forward`要出于开启状态

检查流程：
> 1, 检查docker 容器是否启动正常
> 2，使用docker port Name 查看容器端口是否映射成功
> 3，使用iptables -t nat -nL 查看iptables转发链是否配置成功
> 4，检查网卡转发是否开启