title: ' Git 基本操作'
date: '2019-11-06 14:32:25'
updated: '2019-11-06 14:32:25'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573021945007.html
---
# Git 基本操作
![image.png](https://img.hacpai.com/file/2019/11/image-8fd347f5.png)


## 1）查看Git的状态

```bash
[root@node1 .git]# git status 
fatal: This operation must be run in a work tree（必须在工作目录中执行）
// 查看git状态的命令必须在git的工作区来执行，要不然就会提示这个

[root@zsf_node1 .git]# cd ../
[root@zsf_node1 git_test]# git status  
# On branch master      当前处在哪个分支
nothing to commit, working directory clean  没有需要提交的内容，工作目录清理
```

## 2）创建一个文件查看git的状态

```bash
[root@zsf_node1 git_test]# touch test_file
[root@zsf_node1 git_test]# git status 
# On branch master
# Untracked files:      未被跟踪的文件，只是在工作目录创建了
#   (use "git add <file>..." to include in what will be committed)
#
#       test_file
nothing added to commit but untracked files present (use "git add" to track)
你没有提交文件，但是你有存在未跟踪的文件，我们可以使用git add 把这个未跟踪的文件提交到暂存区
```

## 3）把文件从工作区提交到暂存区

```bash
[root@zsf_node1 git_test]# git add test_file
[root@zsf_node1 git_test]# git status 
On branch master        //当前所处于的分支

Initial commit          //初始化提交

Changes to be committed://要提交的更改
  (use "git rm --cached <file>..." to unstage)
  //如果你认为直接提交的有问题，你可以使用这个命令把他撤销下来

        new file:   test_file
[root@zsf_node1 git_test]# ll -d .git/index 
-rw-r--r-- 1 root root 104 Nov  8 09:53 .git/index
//当第一次提交到暂存区会生成一个index文件

//git add 可以用它开始跟踪新文件，或者把已跟踪的文件放到暂存区，还能用于合并时把有冲突的文件标记为已解决状态等。 
//将这个命令理解为“添加内容到下一次提交中”而不是“将一个文件添加到项目中”要更加合适。 
```

## 4）把文件暂存区 commit 到本地仓库

```bash
[root@zsf_node1 git_test]# git commit -m "test commit add test_file" test_file
[master (root-commit) 6182c28] test commit add test_file
 1 file changed, 0 insertions(+), 0 deletions(-)
 create mode 100644 test_file
[root@zsf_node3 git_test]# git status 
On branch master
nothing to commit, working tree clean
```
勤劳和细心的你一定会发现，每一次用git add提交一个新的文件的时候都会在最下面出现一行`create  mode 100644 File_Name`这句话，那么`100644`这串数字代表什么含义呢？下面经过试验来看一下

```bash
100 代表普通文件（regular file）
644 为权限
也可以去这个文件里面查看/usr/share/doc/git-1.8.3.1/technical/index-format.txt

  32-bit mode, split into (high to low bits)

    4-bit object type
      valid values in binary are 1000 (regular file), 1010 (symbolic link)
      and 1110 (gitlink)

    3-bit unused

    9-bit unix permission. Only 0755 and 0644 are valid for regular files.
    Symbolic links and gitlinks have value 0 in this field.
```



## 5) 查看状态

```bash
[root@zsf_node3 git_test]# git status 
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

        modified:   test_file

no changes added to commit (use "git add" and/or "git commit -a")

//紧凑型输出，不显示多余的信息
[root@zsf_node3 git_test]# git status -s 
 M test_file                
```
说明：git status -s符号的说明
> ??: 新添加的未跟踪文件前面有 ?? 标记
> 
> A : 新添加到暂存区中的文件前面有 A 标记
> 
> M : 修改过的文件前面有 M 标记。 你可能注意到了 M 有两个可以出现的位置，出现在右边的 M (红色)表示该文件被修改了但是还没放入暂存区，出现在靠左边的 M 表示该文件被修改了并放入了暂存区。
> 
> 空: 当工作目录和暂存区和本地仓库文件内容一样的时候，什么都不输出 

## 6）更改工作区文件的内容，比对文件

```bash
[root@zsf_node3 git_test]# echo "test git diff " >> test_file 
[root@zsf_node3 git_test]# git status -s 
 M test_file
 
 // 工作区和暂存区文件的对比，如果后面不跟文件修改的是所有文件的差别
[root@zsf_node3 git_test]# git diff test_file
diff --git a/test_file b/test_file
index 766ebe2..8072794 100644
--- a/test_file
+++ b/test_file
@@ -1 +1,2 @@
 test git status -s 
+test git diff  //工作区文件里面的文件和暂存区里面文件的对比

//把工作区改变的内容提交到暂存区
[root@zsf_node3 git_test]# git add test_file

//比对暂存区和本地仓库这个文件的差别，如果不加是比对多有更改的值
[root@zsf_node3 git_test]# git diff --cached 
diff --git a/test_file b/test_file
index 766ebe2..8072794 100644
--- a/test_file
+++ b/test_file
@@ -1 +1,2 @@
 test git status -s 
+test git diff 

```

## 7）撤销修改

```bash
//测试文件准备
[root@zsf_node3 git_test]# cat test_file 
test git status -s 
test git diff 
[root@zsf_node3 git_test]# echo 'test git checkout -- ' >> test_file 
[root@zsf_node3 git_test]# cat test_file 
test git status -s 
test git diff 
test git checkout -- 
[root@zsf_node3 git_test]# git add test_file
[root@zsf_node3 git_test]# git diff test_file
[root@zsf_node3 git_test]# git diff --cached test_file
diff --git a/test_file b/test_file
index 8072794..d92353f 100644
--- a/test_file
+++ b/test_file
@@ -1,2 +1,3 @@
 test git status -s 
 test git diff 
+test git checkout --
//环境模拟成功，现在就是暂存区和本地目录一致，和本地仓库不一致

//从本地仓库撤销到暂存区,撤销到最后一次commit
[root@zsf_node3 git_test]# git reset HEAD test_file 
Unstaged changes after reset:
M       test_file
//我们可以通过这个命令可以看出开我们已经把文件从本地仓库撤销到暂存区了
[root@zsf_node3 git_test]# git diff
diff --git a/test_file b/test_file
index 8072794..d92353f 100644
--- a/test_file
+++ b/test_file
@@ -1,2 +1,3 @@
 test git status -s 
 test git diff 
+test git checkout -- 

//把文件从暂存区撤销到工作目录
[root@zsf_node3 git_test]# git checkout -- test_file
[root@zsf_node3 git_test]# cat test_file 
test git status -s 
test git diff 
//发现我们刚才追加进去的内容已经不存在了

diff比较的符号说明
+ 文件里面有新增的内容
- 文件里面删除了内容
如果是替换的话，他换先删除原先的行，在把更改后的行增加上去

//从本地仓库拉去指定commit的文件
[root@zsf_node3 git_test]# git reflog       //先查看所有commit的记录
e98d2e5 HEAD@{0}: commit: test git diff
bb0deb3 HEAD@{1}: commit: git status -s test
6182c28 HEAD@{2}: commit (initial): test commit add test_file

//直接从本地仓库撤销到工作目录
[root@zsf_node3 git_test]# git reset --hard 6182c28
HEAD is now at 6182c28 test commit add test_file[root@zsf_node3 git_test]# git diff 
[root@zsf_node3 git_test]# cat test_file 
[root@zsf_node3 git_test]# 
```

## 8）跳过暂存区，直接把文件提交到本地仓库

```bash
[root@zsf_node3 git_test]# git  commit -a -m "test git commit -a"
[master b140339] test git commit -a
 1 file changed, 1 insertion(+)
 //把所有被git跟踪的文件直接提交到本地仓库
 [root@zsf_node3 git_test]# git commit -a -m "test git commit -a " test_file
fatal: Paths with -a does not make sense.
// 如果这个文件没有被git跟踪，是不能跳过space暂存区域的
```

## 9）移除文件
从git中移除某个文件，就必须要从已经跟踪文件清单中移除(从暂存区移除),然后commit提交。我们可以使用`git rm`命令完成此项工作，并连带冲工作目录中删除指定的文件，这样以后就不会出现在未跟中文件清单中了。

如果只是简单地从工作目录中手工删除文件，运行`git status`就会在“Changes not staged for commit”部分（也就是 未暂存清单）

```bash
[root@zsf_node3 git_test]# rm -f test_file 
[root@zsf_node3 git_test]# git status 
On branch master
Changes not staged for commit:  未提交的更改
  (use "git add/rm <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

        deleted:    test_file

no changes added to commit (use "git add" and/or "git commit -a")

//然后运行git rm 删除
[root@zsf_node3 git_test]# git rm test_file
rm 'test_file'
[root@zsf_node3 git_test]# git status 
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

        deleted:    test_file
//当下次再提交的时候test_file 这个文件就完成了删除了

[root@zsf_node3 git_test]# git commit  -a -m "delete test_file"
[master 47a2f61] delete test_file
 1 file changed, 1 deletion(-)
 delete mode 100644 test_file
[root@zsf_node3 git_test]# git status
On branch master
nothing to commit, working tree clean
```
如果删除之前修改过并且已经放到暂存区域的话，则必须要用强制删除选项 -f（译注：即 force 的首字母）。 这是一种安全特性，用于防止误删还没有添加到快照的数据，这样的数据不能被 Git 恢复。

**只删除本地仓库里面的，不删除本地工作目录中的文件**
```bash
[root@zsf_node3 git_test]# git rm --cached test_file
rm 'test_file'
[root@zsf_node3 git_test]# ls 
test_file
[root@zsf_node3 git_test]# git status 
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

        deleted:    test_file

Untracked files:
  (use "git add <file>..." to include in what will be committed)

        test_file
```

**Git 批量删除文件**

```bash
git rm *.log 支持通配符
```

## 10) 移动文件，更改文件名

```bash
//更改文件名称
[root@zsf_node3 git_test]# git mv test_file file_test
[root@zsf_node3 git_test]# git status 
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

        renamed:    test_file -> file_test
[root@zsf_node3 git_test]# ls 
file_test

执行了上面这个命令相当于执行了下面这三个命令
[root@zsf_node3 git_test]# mv test_file  file_test
[root@zsf_node3 git_test]# git rm test_file
[root@zsf_node3 git_test]# git add test_file
```

## 11)查看提交的历史
在提交了若干更新，又或者克隆了某个项目之后，你也许想回顾下提交历史。 完成这个任务最简单而又有效的工具是 `git log` 命令。

创建我们实验的环境

```bash
[root@zsf_node3 git_test]# touch test_file
[root@zsf_node3 git_test]# git add  test_file
[root@zsf_node3 git_test]# git commit -m "touch test_file" test_file
[master (root-commit) 578e3c2] touch test_file
 1 file changed, 0 insertions(+), 0 deletions(-)
 create mode 100644 test_file
[root@zsf_node3 git_test]# echo -e "add one line\nadd two line" >> test_file 
[root@zsf_node3 git_test]# cat test_file 
add one line
add two line
[root@zsf_node3 git_test]# git commit -a -m "add two line "
[master 6f6a758] add two line
 1 file changed, 2 insertions(+)
[root@zsf_node3 git_test]# git status
On branch master
nothing to commit, working tree clean
[root@zsf_node3 git_test]# vim test_file 
[root@zsf_node3 git_test]# git commit -a -m "del one line"
[master 9a65100] del one line
 1 file changed, 1 deletion(-)
```

**查看git log的信息**

```bash
[root@zsf_node3 git_test]# git log 
commit 9a65100ca154a29484146982902d1b156eccc955    //commit提交的镜像ID
Author: zhangshoufu <18163201@qq.com>             //当前提交这个内容的作者
Date:   Thu Nov 8 15:51:38 2018 +0800             //commit的时间

    del one line                                  //commit提交的说明信息

commit 6f6a758ec24962b9f38da14154fadc7b9d8a9d39
Author: zhangshoufu <18163201@qq.com>
Date:   Thu Nov 8 15:46:59 2018 +0800

    add two line

commit 578e3c2c001c20e29425aeef1a02ee157cfc374e
Author: zhangshoufu <18163201@qq.com>
Date:   Thu Nov 8 15:45:36 2018 +0800

    touch test_file
```
默认不用任何参数的话，git log 会按提交时间列出所有的更新，最近的更新排在最上面。

**以单行的模式去查看**
只显示commit id的前几位和 -m的说明信息
```bash
[root@zsf_node3 git_test]# git log --oneline 
9a65100 del one line
6f6a758 add two line
578e3c2 touch test_file
```

**查看每次commit提交的改变**

```bash
//  -1 显示最近一次
[root@zsf_node3 git_test]# git log -p -1
commit 9a65100ca154a29484146982902d1b156eccc955
Author: zhangshoufu <18163201@qq.com>
Date:   Thu Nov 8 15:51:38 2018 +0800

    del one line

diff --git a/test_file b/test_file
index dac4493..429b530 100644
--- a/test_file
+++ b/test_file
@@ -1,2 +1 @@
 add one line
-add two line
```

另外一个常用的选项是 --pretty。 这个选项可以指定使用不同于默认格式的方式展示提交历史。 这个选项有一些内建的子选项供你使用。 比如用 oneline 将每个提交放在一行显示，查看的提交数很大时非常有用。 另外还有 short，full 和 fuller 可以用，展示的信息或多或少有些不同，请自己动手实践一下看看效果如何。

```bash
$ git log --pretty=oneline
ca82a6dff817ec66f44342007202690a93763949 changed the version number
085bb3bcb608e1e8451d4b2432f8ecbe6306e7e7 removed unnecessary test
a11bef06a3f659402fe7563abf99ad00de2209e6 first commit
```
但最有意思的是 format，可以定制要显示的记录格式。 这样的输出对后期提取分析格外有用 — 因为你知道输出的格式不会随着 Git 的更新而发生改变：

```bash
$ git log --pretty=format:"%h - %an, %ar : %s"
ca82a6d - Scott Chacon, 6 years ago : changed the version number
085bb3b - Scott Chacon, 6 years ago : removed unnecessary test
a11bef0 - Scott Chacon, 6 years ago : first commit
```
![image.png](https://img.hacpai.com/file/2019/11/image-5480e531.png)


**显示所有的更改操作**

```bash
[root@zsf_node3 git_test]# git reflog 
9a65100 HEAD@{0}: commit: del one line
6f6a758 HEAD@{1}: commit: add two line
578e3c2 HEAD@{2}: commit (initial): touch test_file
```

**显示那个分支提交的**

```bash
[root@zsf_node3 git_test]# git log --oneline --decorate
9a65100 (HEAD -> master) del one line
6f6a758 add two line
578e3c2 touch test_file
```

## 12) 切换commit，HEAD当前所在的位置，回滚

```bash
[root@master_11 git_data]# git reflog
98c3c1a HEAD@{0}: commit: clean all
e6f6a91 HEAD@{1}: reset: moving to e6f6a91
a976d01 HEAD@{2}: commit: touch b file
e6f6a91 HEAD@{3}: commit (initial): add touch a file
[root@master_11 git_data]# git reset --hard a976d01
HEAD is now at a976d01 touch b file
```