title: 通过kubeadm 安装kubernetes集群
date: '2019-07-19 17:36:32'
updated: '2019-07-19 17:36:32'
tags: [kubernetes]
permalink: /articles/2019/07/19/1563528992447.html
---
# 通过kubeadm 安装kubernetes集群
## 机器列表
## 安装前准备
### 关闭selinux

```bash
setenforce 0
sed -i "s#SELINUX=enforcing#SELINUX=disabled#g" /etc/selinux/config
```
### 关闭防火墙

```bash
systemctl stop firewalld
systemctl disable firewalld
```
### 关闭swap分区

```bash
vim /etc/fstab
注释掉swap哪一行,
```
### 配置转发相关参数，否则可能会出错

```bash
cat <<EOF >  /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
vm.swappiness=0
EOF
sysctl --system
```

### 在master节点中配置 cgroup driver
查看docker使用的cgroup driver:

```bash
[root@localhost ~]# docker info | grep -i cgroup
Cgroup Driver: cgroupfs
```
而 kubelet 使用的 cgroupfs 为system，不一致故有如下修正：`sudo vim /etc/systemd/system/kubelet.service.d/10-kubeadm.conf`

```bash
#加上如下配置
Environment="KUBELET_CGROUP_ARGS=--cgroup-driver=cgroupfs"
```
### 配置完之后要重启

## 配置一系列源
### 配置阿里云的k8s源
如果我们不配置默认使用国外源安装`kubeadm`,但是出于国内大环境所影响,我们不能访问国外的源
```bash
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF
```

### 配置docker源

```bash
yum -y install  yum-utils
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

## 安装docker 和 k8s组件
### 安装kubeadm

```bash
yum -y install kubeadm
systemctl enable kubelet.service && systemctl start kubelet.service
```

### 安装docker

```bash
yum install -y device-mapper-persistent-data lvm2
sudo yum makecache fast
yum -y install docker-ce-18.06.0.ce-3.el7
systemctl start docker && systemctl enable docker
```
## 开始正式的安装k8s集群
### 手动拉去镜像
因为我们防火墙问题导致不能直接去google上面拉去,所以我们先手动拉去
查看需要安装的镜像版本

```bash
[root@localhost ~]# kubeadm config images list
I0210 16:11:46.227035    2745 version.go:94] could not fetch a Kubernetes version from the internet: unable to get URL "https://dl.k8s.io/release/stable-1.txt": Get https://storage.googleapis.com/kubernetes-release/release/stable-1.txt: net/http: request canceled while waiting for connection (Client.Timeout exceeded while awaiting headers)
I0210 16:11:46.227103    2745 version.go:95] falling back to the local client version: v1.13.3
k8s.gcr.io/kube-apiserver:v1.13.3
k8s.gcr.io/kube-controller-manager:v1.13.3
k8s.gcr.io/kube-scheduler:v1.13.3
k8s.gcr.io/kube-proxy:v1.13.3
k8s.gcr.io/pause:3.1
k8s.gcr.io/etcd:3.2.24
k8s.gcr.io/coredns:1.2.6
```
#docker.io仓库对google的容器做了镜像，可以通过下列命令下拉取相关镜像：但是这样还是有点慢,我们先配置镜像加速
```bash
#镜像加速
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://ll9gv5j9.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

拉取镜像
```bash
docker pull mirrorgooglecontainers/kube-apiserver-amd64:v1.11.3
docker pull mirrorgooglecontainers/kube-controller-manager-amd64:v1.11.3
docker pull mirrorgooglecontainers/kube-scheduler-amd64:v1.11.3
docker pull mirrorgooglecontainers/kube-proxy-amd64:v1.11.3
docker pull mirrorgooglecontainers/pause:3.1
docker pull mirrorgooglecontainers/etcd-amd64:3.2.24
docker pull coredns/coredns:1.2.6
```

利用`docker tag`改标签,要不然kubeadm还是不识别
```bash
docker tag coredns/coredns:1.2.6 k8s.gcr.io/coredns:1.2.6
docker tag mirrorgooglecontainers/etcd-amd64:3.2.24 k8s.gcr.io/etcd:3.2.24
docker tag mirrorgooglecontainers/kube-proxy-amd64:v1.11.3       k8s.gcr.io/kube-proxy:v1.13.3
docker tag mirrorgooglecontainers/kube-apiserver-amd64:v1.11.3   k8s.gcr.io/kube-apiserver:v1.13.3
docker tag mirrorgooglecontainers/kube-controller-manager-amd64:v1.11.3  k8s.gcr.io/kube-controller-manager:v1.13.3
docker tag mirrorgooglecontainers/kube-scheduler-amd64:v1.11.3   k8s.gcr.io/kube-scheduler:v1.13.3
docker tag mirrorgooglecontainers/pause:3.1   k8s.gcr.io/pause:3.1
```

删除以前的标签
```bash
docker images  | awk -vOFS=: '$0~/^mirror|^coredns/{print "docker rmi " $1,$2}'  | bash
```
### 创建kubernetes master端

```bash
kubeadm init --apiserver-advertise-address=10.0.0.100 --pod-network-cidr=192.168.0.0/16
```
* --pod-network-cidr: 指定pod网络的IP地址范围，它的值取决于你在下一步选择的哪个网络网络插件，比如我在本文中使用的是Calico网络，需要指定为192.168.0.0/16。
* --apiserver-advertise-address: 指定master服务发布的Ip地址，如果不指定，则会自动检测网络接口，通常是内网IP。

创建完成之后按照提示执行下面命令

```bash
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```
需要这三句配置命令的原因是:kubernetes集群默认访问时加密的,所以这几条命令就是将刚刚部署生成的kubernetes集群的安全配置文件,保存到当前用户的.kube目录下,kubectl默认会使用这个目录下的授权信息访问kubernetes集群,如果不这么做的话我们需要每次通过 export KUBECONFIG环境变量告诉kubectl这个安全配置文件的位置

### 测试看看是否正常

```bash
[root@master ~]# curl https://10.0.0.100:6443 -k
{
  "kind": "Status",
  "apiVersion": "v1",
  "metadata": {

  },
  "status": "Failure",
  "message": "forbidden: User \"system:anonymous\" cannot get path \"/\"",
  "reason": "Forbidden",
  "details": {

  },
  "code": 403
}
```
### 查看节点状态
使用命令`kubectl get nodes`

```bash
[root@master ~]# kubectl get nodes
NAME               STATUS     ROLES    AGE   VERSION
master.kuber.com   NotReady   master   37m   v1.13.3
```
我们可以看到这个node节点状态为`Notready`,我们使用这个命令排查错误`kubectl describe nodes master.kuber.com`

```bash
[root@master ~]# kubectl describe nodes master.kuber.com
......
Conditions:
.....
  Ready            False   Sun, 10 Feb 2019 20:28:16 +0800   Sun, 10 Feb 2019 19:49:51 +0800   KubeletNotReady              runtime network not ready: NetworkReady=false reason:NetworkPluginNotReady message:docker: network plugin is not ready: cni config uninitialized
  ....
```
通过`kubectl describe`指令我们可以看出是因为`NodeNotReady`的原因,未安装部署任何网络插件