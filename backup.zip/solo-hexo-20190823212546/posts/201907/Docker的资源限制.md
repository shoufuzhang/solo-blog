title: Docker的资源限制
date: '2019-07-17 21:22:12'
updated: '2019-07-17 21:22:12'
tags: [Docker]
permalink: /articles/2019/07/17/1563369732297.html
---
# Docker的资源限制
## [内存资源的限制](https://docs.docker.com/config/containers/resource_constraints/#limit-a-containers-access-to-memory)
### docker占用过大内存导致的危害
如果docker容器占用过多的宿主机内存.在linux主机上存在这样一个机制:"如果内核探测 到没有足够的内存来执行重要的系统进程, 它就会抛出 `OOME(out of memory exception内存不足)`"并随机杀死一个进程来释放内存.不管什么进程都有可能被杀死,(一般杀死内存占用最大的那个进程)这包括Docker或其他非常重要的进程.This can effectively bring the entire system down if the wrong process is killed.

docker 尝试通过调整Docker守护进程上的`OOM`优先级来降低docker container被杀死的风险,以便他在内存不足的时候不会被杀死.如果在docker container的`OOM`为调整的时候,这使内存占用最大的docke container 比其他docker container或其他system processes 被杀死的可能性更大.你不应该使用`--oom-score-adj`调整为负数或者`--oom-kill-disable`直接使用这个参数

有关更多Linux内核的OOM管理信息的,请自行查阅:[Out Of Memory Management](https://www.kernel.org/doc/gorman/html/understand/understand016.html)

* 在应用程序投入生产中,请先测试好你这个docker程序需要使用的内存
* 确保您的应用程序仅在具有足够资源的主机上运行
* 限制容器可以使用的内存大小
* 在docker宿主机上配置交换分区的时候要小心,因为交换分区比内存更慢并且性能更低,但可以考虑提供缓冲区以防止系统内存耗尽
* 

### 降低Linux内核OOME异常导致的系统不稳定
![-w975](media/15450596569198/15455698556282.jpg)
-m 限制内存的实际使用大小空间
--memory-swap * 必须先设置-m, 依赖于-m来成立,设置交换分区的使用大小
![-w1143](media/15450596569198/15450599056749.jpg)

--memory-swappiness 设置容器使用交换分区的倾向性
--memory-reservation 预留的内存空间,值0-100 ,0表示你能不用就不用,100是有一丝可能性就使用
--oom-kill-disable   禁止这个docker容器被杀掉,也需要配合-m

## CPU资源限制
默认的事一个容器可以使用宿主机上所有的cpu资源
--cpu-shares cpu资源共享,按照比例切分当前cpu可用资源(根据权重比来占用cpu资源,只要别人不用他就可以占用全部的cpu资源)(一个核心就是百分之百,两个全部用完就是百分之二百)
--cpus=<value> 限制一个容器最多使用多少个CPU核心数,可以使用小数 --cpus=1.5

--cpuset-cpus 1,3 限制使用那几个核心,那些个cpu核心上,这个只运行在1和3上



测试镜像
docker pull lorel/docker-stress-ng

