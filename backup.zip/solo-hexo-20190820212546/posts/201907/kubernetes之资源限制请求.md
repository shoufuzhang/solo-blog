title: kubernetes之资源限制,请求
date: '2019-07-19 17:49:32'
updated: '2019-07-19 17:49:32'
tags: [kubernetes, kuberneteslimit]
permalink: /articles/2019/07/19/1563529772658.html
---
# kubernetes之资源限制,请求
## kubernetes可以使用LimitRange 对资源进行默认限制
先创建一个命令空间,我们在命名空间里面指定资源限制

```yaml
# cat limit-namespaces.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: limit-namespace
```

创建命名空间

```bash
kubectl create -f limit-namespaces.yaml
```

查看命名空间是否创建完成

```bash
# kubectl get namespace limit-namespace
NAME              STATUS   AGE
limit-namespace   Active   29m
```

以下是一个LimitRange对象的配置文件。该配置指定了默认的内存请求与默认的内存限额。我们选择的是对limit-namespace空间里面的进行资源限制

```yaml
# cat limitRange.yaml
apiVersion: v1
kind: LimitRange
metadata:
  name: limiti-range-test
  namespace: limit-namespace
spec:
  limits:
  - default:
      memory: 1Gi
    defaultRequest:
      memory: 512Mi
    type: Container
```
下面通过例子来解释default 和defaultRequest分别代表什么

### 我们这个时候创建一个默认不做任何资源的pod

```yaml
# cat nginx-test.yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx-limit-test
  namespace: limit-namespace
spec:
  containers:
  - name: nginx-limit-test
    image: nginx:1.14.2
```

输出显示该Pod的容器的内存请求值是512MiB，内存限额值是1Gi。这些是由LimitRange指定的默认值。

```bash
# kubectl describe pods -n limit-namespace nginx-limit-test
...
    Ready:          True
    Restart Count:  0
    Limits:
      memory:  1Gi
    Requests:
      memory:     512Mi
    Environment:  <none>
...
```
我们通过上面的例子可以看出来:
default         是limit的限制
defaultRequest  是默认的request的请求

### 创建一个限制limit值的pod
我们只做了他的limits限制
```yaml
# cat nginx-test-limit.yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx-limit-test-2
  namespace: limit-namespace
spec:
  containers:
  - name: nginx-limit-test
    image: nginx:1.14.2
    resources:
      limits:
        memory: 2Gi
```

输出显示该Pod的容器的内存请求值是2Gi，内存限额值是2Gi。
```bash
# kubectl describe pods -n limit-namespace nginx-limit-test-2
    Restart Count:  0
    Limits:
      memory:  2Gi
    Requests:
      memory:     2Gi
    Environment:  <none>
```
输出显示该容器的内存请求值与它的限额值相等。
注意该容器并未被赋予默认的内存请求值512Mi。

### 我们定义了request未定义limit会发生什么呢?

```yaml
# cat nginx-test-request.yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx-limit-test-3
  namespace: limit-namespace
spec:
  containers:
  - name: nginx-limit-test
    image: nginx:1.14.2
    resources:
      requests:
        memory: 256Mi
```
测试结果如下:
```bash
# kubectl describe -n limit-namespace pods nginx-limit-test-3
    Ready:          True
    Restart Count:  0
    Limits:
      memory:  1Gi
    Requests:
      memory:     256Mi
    Environment:  <none>
```
所以说如果我们单存的只限制了一个request,limit会继承我们默认设置的那个
### 如果我们定义的request的值超过了limit的值的时候又会发生什么事情呢?
创建的yaml文件如下,我们故意把request的值比limit大,看会发生什么

```yaml
# cat nginx-test-request.yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx-limit-test-3
  namespace: limit-namespace
spec:
  containers:
  - name: nginx-limit-test
    image: nginx:1.14.2
    resources:
      requests:
        memory: 2Gi
```
创建pod报错如下
```bash
# kubectl create -f nginx-test-request.yaml
The Pod "nginx-limit-test-3" is invalid: spec.containers[0].resources.requests: Invalid value: "2Gi": must be less than or equal to memory limit
```
提示request的值必须小于limit的值.

