title: ansible Playbook 剧本
date: '2019-07-19 18:04:42'
updated: '2019-07-19 18:04:42'
tags: [Ansible]
permalink: /articles/2019/07/19/1563530682387.html
---
# ansible Playbook 剧本
测试使用的主机

```bash
[root@master_11 playbook]# cat /etc/ansible/hosts 
[node3]
10.0.0.13

[node2]
10.0.0.12
```
## Playbook初识
1.什么是playbook，playbook翻译过来就是“剧本”，那playbook组成如下

play: 定义的是主机的角色
task: 定义的是具体执行的任务
playbook: 由一个或多个play组成，一个play可以包含多个task任务
简单理解为: 使用不同的模块完成一件事情

2.playbook的优势

1.功能比ad-hoc更全
2.能很好的控制先后执行顺序, 以及依赖关系
3.语法展现更加的直观
4.ad-hoc无法持久使用，playbook可以持久使用

3.playbook的配置语法是由yaml语法描述的，扩展名是yaml

缩进
- YAML使用固定的缩进风格表示层级结构,每个缩进由两个空格组成, 不能使用tabs

冒号
- 以冒号结尾的除外，其他所有冒号后面所有必须有空格。

短横线
- 表示列表项，使用一个短横杠加一个空格。
- 多个项使用同样的缩进级别作为同一列表。


```yaml
[root@master_11 playbook]# cat z1.yaml 
- hosts: node3
  remote_user: root
  vars:                                 //定义变量，必须先定义在调用
    File_Name: zhangshoufu              //定义一个File_Name的变量
  tasks:
    - name: create new file
      file: name=/tmp/{{ File_Name }} state=touch   //用{{ 变量名 }}的方式来引用变量
      
[root@master_11 playbook]# ansible-playbook z1.yaml  //使用playbook方式执行

PLAY [node3] ****************************************************************************

TASK [Gathering Facts] ***********************************************************************
ok: [10.0.0.13]

TASK [create new file] ******************************************************************
changed: [10.0.0.13]

PLAY RECAP ****************************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0   
```

Playbook执行结果返回颜色状态
> 红色： 表示有task执行失败或者提醒的信息
黄色：表示执行了且改变了远程主机状态
绿色：表示执行成功

## PlayBook的变量定义应用
Playbook定义变量的四种方式
- 1）playbook的yaml文件中定义变量赋值
- 2）--extra-vars执行参数赋给变量（命令行传参）
- 3）在hosts文件中定义变量
- 4）注册变量*

### 1）playbook的yaml文件中变量赋值

```bash
[root@master_11 playbook]# cat z2.yaml 
- hosts: node3
  vars:
    File_Name: zhangshoufu

  tasks:
    - name: del one file
      file: name=/tmp/{{ File_Name }} state=absent
```

### 2) --extra-vars 执行参数赋给变量

```bash
[root@master_11 playbook]# cat z3.yaml 
- hosts: node3

  tasks:
    - name: del one file
      file: name=/tmp/{{ File_Name }} state=touch

[root@master_11 playbook]# ansible-playbook --extra-vars "File_Name=zhangshoufu" z3.yaml 

PLAY [node3] ***********************************************************************

TASK [Gathering Facts] ***********************************************************************
ok: [10.0.0.13]

TASK [del one file] ***********************************************************************
changed: [10.0.0.13]

PLAY RECAP **************************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0 
```

### 3）在文件中定义变量：可以在/etc/ansible/hosts主机组中定义，然后使用playbook进行调度该变量

```bash
[root@master_11 playbook]# cat /etc/ansible/hosts
[node3]
10.0.0.13
[node3:vars]
File_Name=zhangshoufu

[node2]
10.0.0.12

[root@master_11 playbook]# cat z4.yaml 
- hosts: node3
  tasks:
    - name: del one file
      file: name=/tmp/{{ File_Name }} state=absent

[root@master_11 playbook]# ansible-playbook z4.yaml 

PLAY [node3] ***********************************************************************

TASK [Gathering Facts] ***********************************************************************
ok: [10.0.0.13]

TASK [del one file] ***********************************************************************
changed: [10.0.0.13]

PLAY RECAP **************************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0
```
### 4）注册变量：register模块可以存储指定命令的输出结果到一个定义的变量中
[register和setup详解](https://www.zhangshoufu.com/archives/683.html)
```yaml
[root@master_11 playbook]# cat z5.yaml 
- hosts: node3
  tasks:
    - name:
      shell: netstat -ntlp
      register: system_status
    
    - name: get system status
      debug: msg={{ system_status.stdout_lines }}
    
[root@master_11 playbook]# ansible-playbook z5.yaml 

PLAY [node3] ************************************************************************************************************************

TASK [Gathering Facts] **************************************************************************************************************
ok: [10.0.0.13]

TASK [shell] ************************************************************************************************************************
changed: [10.0.0.13]

TASK [get system status] ************************************************************************************************************
ok: [10.0.0.13] => {
    "msg": [
        "Active Internet connections (only servers)", 
        "Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name    ", 
        "tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      633/sshd            ", 
        "tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN      926/master          ", 
        "tcp6       0      0 :::8080                 :::*                    LISTEN      958/java            ", 
        "tcp6       0      0 :::22                   :::*                    LISTEN      633/sshd            ", 
        "tcp6       0      0 ::1:25                  :::*                    LISTEN      926/master          "
    ]
}

PLAY RECAP **************************************************************************************************************************
10.0.0.13                  : ok=3    changed=1    unreachable=0    failed=0   
```

## Playbook条件语句 when

```yaml
[root@master_11 playbook]# cat z8.yaml 
- hosts: all
  gather_facts: true
  tasks:
    - name: Create files except the host name is node3
      file: name=/tmp/{{ ansible_hostname }} state=touch
      when: ansible_hostname != "node_1_13"
```
执行结果

```bash
[root@master_11 playbook]# ansible-playbook z8.yaml 

PLAY [all] ***********************************************************************

TASK [Gathering Facts] ***********************************************************
ok: [10.0.0.12]
ok: [10.0.0.13]

TASK [Create files except the host name is node3] ********************************
skipping: [10.0.0.13]
changed: [10.0.0.12]

PLAY RECAP ***********************************************************************
10.0.0.12                  : ok=2    changed=1    unreachable=0    failed=0   
10.0.0.13                  : ok=1    changed=0    unreachable=0    failed=0   
```
从执行结果可以看出他把 node3这台主机跳过了，没有创建文件

## [PlayBook的循环](https://www.zhangshoufu.com/archives/706.html)

```yaml
[root@master_11 playbook]# cat  z9.yaml
- hosts: node3
  remote_user: root
  tasks:
    - name: new add user
      user: name={{ item.name }} groups={{ item.groups }} state=present
      with_items:
        - { name: 'zsf',groups: 'root' }
        - { name: 'zmy',groups: 'root' }
```
执行结果：

```yaml
[root@master_11 playbook]# ansible-playbook z9.yaml 

PLAY [node3] ***********************************************************************

TASK [Gathering Facts] ***************************************************************
ok: [10.0.0.13]

TASK [new add user] ********************************************************************
changed: [10.0.0.13] => (item={u'name': u'zsf', u'groups': u'root'})
changed: [10.0.0.13] => (item={u'name': u'zmy', u'groups': u'root'})

PLAY RECAP ***********************************************************************
10.0.0.13                  : ok=2    changed=1    unreachable=0    failed=0
```

## playBook忽略错误

```yaml
[root@master_11 playbook]# cat z14.yaml 
- hosts: node3
  tasks:
    - name: shell fales
      command: /bin/false
      ignore_errors: yes
    - name: touch new file
      file: path=/tmp/sucess state=touch
```
执行结果：
```yaml
[root@master_11 playbook]# ansible-playbook z14.yaml 

PLAY [node3] *************************************************************************************************

TASK [Gathering Facts] ***************************************************************************************
ok: [10.0.0.13]

TASK [shell fales] *******************************************************************************************
fatal: [10.0.0.13]: FAILED! => {"changed": true, "cmd": ["/bin/false"], "delta": "0:00:00.007013", "end": "2018-11-18 15:37:03.427976", "msg": "non-zero return code", "rc": 1, "start": "2018-11-18 15:37:03.420963", "stderr": "", "stderr_lines": [], "stdout": "", "stdout_lines": []}
...ignoring

TASK [touch new file] ****************************************************************************************
changed: [10.0.0.13]

PLAY RECAP ***************************************************************************************************
10.0.0.13                  : ok=3    changed=2    unreachable=0    failed=0 
```
按照正常情况，我们执行command命令之后，ansible判断这条命令没有执行成功，他就会给我退出执行，错误的下面全部都不执行了，但是我们加上`ignore_errors: yes`之后他就会忽略当前这一个任务的错误，不管这个任务执行是否成功都会继续执行

## Playbook tags标签
1、打标签
* 对一个对象打一个标签
* 对一个对象打多个标签

2、标签使用，通过tags和任务对象进行捆绑，控制部分或者指定的task执行
* -t: 执行指定的tag标签任务
* --skip-tags: 执行--skip-tags之外的标签任务


```yaml
[root@master_11 playbook]# cat z15.yml
- hosts: node3
  remote_user: root
  tasks:
    - name: Install Nfs Server
      yum: name=nfs-utils state=present
      tags:
        - install_nfs
        - install_nfs-server

    - name: Service Nfs Server
      service: name=nfs-server state=started enabled=yes
      tags: start_nfs-server
```

正常执行

```yaml
[root@master_11 playbook]# ansible-playbook  z15.yml

PLAY [all] ********************************************************************************************************************************

TASK [Gathering Facts] ********************************************************************************************************************
ok: [10.0.0.13]

TASK [Install Nfs Server] *****************************************************************************************************************
ok: [10.0.0.13]

TASK [Service Nfs Server] *****************************************************************************************************************
ok: [10.0.0.13]

PLAY RECAP ********************************************************************************************************************************
10.0.0.13                  : ok=3    changed=0    unreachable=0    failed=0
```

使用-t指定tags执行, 多个tags使用逗号隔开即可

```yaml
[root@master_11 playbook]# ansible-playbook -t install_nfs-server z15.yml

PLAY [all] ********************************************************************************************************************************

TASK [Gathering Facts] ********************************************************************************************************************
ok: [10.0.0.13]

TASK [Install Nfs Server] *****************************************************************************************************************
ok: [10.0.0.13]

PLAY RECAP ********************************************************************************************************************************
10.0.0.13                  : ok=2    changed=0    unreachable=0    failed=0
```

使用--skip-tags排除不执行的tags

```yaml
[root@master_11 playbook]# ansible-playbook --skip-tags install_nfs-server f10.yml

PLAY [all] ********************************************************************************************************************************

TASK [Gathering Facts] ********************************************************************************************************************
ok: [10.0.0.13]

TASK [Service Nfs Server] *****************************************************************************************************************
ok: [10.0.0.13]

PLAY RECAP ********************************************************************************************************************************
10.0.0.13                  : ok=2    changed=0    unreachable=0    failed=0
```

## Playbook Handlers 触发条件安装


```