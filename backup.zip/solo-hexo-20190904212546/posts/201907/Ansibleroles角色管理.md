title: Ansible roles角色管理
date: '2019-07-19 18:05:56'
updated: '2019-07-19 18:05:56'
tags: [Ansible]
permalink: /articles/2019/07/19/1563530756158.html
---
# Ansible roles角色管理
当我们刚开始学习和运用playbook的时候，我们可定会把playbook写成一个很大的文件，到后来可能我们会希望这些文件是可以方便去重用的，所以我们需要重新组织这些个文件。
基本上我们使用的方法就是基于include或者是roles来完成这项工作。

Roles 的概念来自于这样的想法：通过 include 包含文件并将它们组合在一起，组织成一个简洁、可重用的抽象对象。这种方式可使你将注意力更多地放在大局上，只有在需要时才去深入了解细节

## include 包含

```yaml
# possibly saved as tasks/foo.yml

- name: placeholder foo
  command: /bin/foo

- name: placeholder bar
  command: /bin/bar
```

他就等于下面这个

```yaml
tasks:

  - include: tasks/foo.yml
```

## roles 角色
roles的主要就是这些文件的应用
```bash
.
├── roles
│   └── nginx
│       ├── defaults
│       ├── files
│       ├── handlers
│       │   └── main.yml
│       ├── meta
│       ├── tasks
│       │   └── main.yml
│       ├── templates
│       └── vars
│           └── main.yml
└── site.yml
```
这个 playbook 为一个角色 ‘x’ 指定了如下的行为：

* 如果 roles/x/tasks/main.yml 存在, 其中列出的 tasks 将被添加到 play 中
* 如果 roles/x/handlers/main.yml 存在, 其中列出的 handlers 将被添加到 play 中
* 如果 roles/x/vars/main.yml 存在, 其中列出的 variables 将被添加到 play 中
* 如果 roles/x/meta/main.yml 存在, 其中列出的 “角色依赖” 将被添加到 roles 列表中 (1.3 and later)
* 所有 copy tasks 可以引用 roles/x/files/ 中的文件，不需要指明文件的路径。
* 所有 script tasks 可以引用 roles/x/files/ 中的脚本，不需要指明文件的路径。
* 所有 template tasks 可以引用 roles/x/templates/ 中的文件，不需要指明文件的路径。
* 所有 include tasks 可以引用 roles/x/tasks/ 中的文件，不需要指明文件的路径。

## 角色默认变量(Role Defaults variables)
角色默认变量允许你为included roles或者dependent roles设置默认变量。要创建默认变量，只需在roles目录下添加`defaults/main.yml`文件。这些变量在所有可用变量中拥有最低优先级，在其他地方定义的变量都会覆盖这个文件里面设置的变量

## roles实战
roles目录结构：

```yaml
[root@master_11 nginx]# tree .
.
├── hosts
├── roles
│   └── nginx
│       ├── handlers
│       │   └── main.yml
│       ├── tasks
│       │   ├── file
│       │   │   ├── blog.conf
│       │   │   └── nginx.repo
│       │   └── main.yml
│       └── vars
│           └── main.yml
└── site.yml
```

hosts节点配置文件，ansible的客户端

```yaml
[root@master_11 nginx]# cat hosts 
[node3]
10.0.0.13
```

roles的主配置文件，去调用其他的
```yaml
[root@master_11 nginx]# cat site.yml 
- hosts: node3
  remote_user: root
  roles:
    - nginx
```

tasks模块的配置文件

```yaml
[root@master_11 nginx]# cat roles/nginx/tasks/main.yml 
---
- name: copy install nginx install file repo
  copy: src=./file/nginx.repo dest=/etc/yum.repos.d/ 

- name: test nginx install status
  shell: rpm -qa | grep nginx &> /dev/null; echo $?
  register: nginx_status

- name: Install nginx for the first time
  yum: name={{ pack }} state=installed
  when: nginx_status != "0"

- name: rpm -qa nginx
  shell: "rpm -qa | grep nginx"
  register: install_nginx

- name: echo install_nginx
  debug: msg={{ install_nginx }}

- name: copy nginx file
  copy: src=./file/blog.conf dest=/etc/nginx/conf.d/
  notify: restart nginx
```

变量的模板
```yaml
[root@master_11 nginx]# cat roles/nginx/vars/main.yml 
pack: nginx
```

执行完成的过程：
```yaml
[root@master_11 nginx]# ansible-playbook -i hosts site.yml 

PLAY [node3] *************************************************************************************************

TASK [Gathering Facts] ***************************************************************************************
ok: [10.0.0.13]

TASK [nginx : copy install nginx install file repo] **********************************************************
ok: [10.0.0.13]

TASK [nginx : test nginx install status] *********************************************************************
 [WARNING]: Consider using the yum, dnf or zypper module rather than running rpm.  If you need to use command
because yum, dnf or zypper is insufficient you can add warn=False to this command task or set
command_warnings=False in ansible.cfg to get rid of this message.

changed: [10.0.0.13]

TASK [nginx : Install nginx for the first time] **************************************************************
changed: [10.0.0.13]

TASK [nginx : rpm -qa nginx] *********************************************************************************
changed: [10.0.0.13]

TASK [nginx : echo install_nginx] ****************************************************************************
ok: [10.0.0.13] => {
    "msg": {
        "changed": true, 
        "cmd": "rpm -qa | grep nginx", 
        "delta": "0:00:00.434742", 
        "end": "2018-11-18 21:07:39.068732", 
        "failed": false, 
        "rc": 0, 
        "start": "2018-11-18 21:07:38.633990", 
        "stderr": "", 
        "stderr_lines": [], 
        "stdout": "nginx-1.14.1-1.el7_4.ngx.x86_64", 
        "stdout_lines": [
            "nginx-1.14.1-1.el7_4.ngx.x86_64"
        ], 
        "warnings": [
            "Consider using the yum, dnf or zypper module rather than running rpm.  If you need to use command because yum, dnf or zypper is insufficient you can add warn=False to this command task or set command_warnings=False in ansible.cfg to get rid of this message."
        ]
    }
}

TASK [nginx : copy nginx file] *******************************************************************************
changed: [10.0.0.13]

RUNNING HANDLER [nginx : restart nginx] **********************************************************************
changed: [10.0.0.13]

PLAY RECAP ***************************************************************************************************
10.0.0.13                  : ok=8    changed=5    unreachable=0    failed=0   
```
