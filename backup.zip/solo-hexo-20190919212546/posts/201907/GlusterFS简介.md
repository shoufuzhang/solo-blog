title: ' GlusterFS 简介'
date: '2019-07-17 21:47:33'
updated: '2019-07-17 21:47:33'
tags: [分布式存储, GlusterFS]
permalink: /articles/2019/07/17/1563371253381.html
---
# GlusterFS 简介
## GlusterFS概述
GlusterFS (Gluster File System) 是一个开源的分布式文件系统，主要由 Z RESEARCH 公司负责开发。GlusterFS 是 Scale-Out 存储解决方案 Gluster 的核心，具有强大的横向扩展能力，通过扩展能够支持数PB存储容量和处理数千客户端。GlusterFS 借助 TCP/IP 或 InfiniBand RDMA 网络将物理分布的存储资源聚集在一起，使用单一全局命名空间来管理数据。GlusterFS 基于可堆叠的用户空间设计，可为各种不同的数据负载提供优异的性能。

GlusterFS 总体架构与组成部分如图1所示，它主要由存储服务器（Brick Server）、客户端以及 NFS/Samba 存储网关组成。不难发现，GlusterFS 架构中没有元数据服务器组件，这是其最大的设计这点，对于提升整个系统的性能、可靠性和稳定性都有着决定性的意义。

GlusterFS 支持 TCP/IP 和 InfiniBand RDMA 高速网络互联。
客户端可通过原生 GlusterFS 协议访问数据，其他没有运行 GlusterFS 客户端的终端可通过 NFS/CIFS 标准协议通过存储网关访问数据（存储网关提供弹性卷管理和访问代理功能）。
存储服务器主要提供基本的数据存储功能，客户端弥补了没有元数据服务器的问题，承担了更多的功能，包括数据卷管理、I/O 调度、文件定位、数据缓存等功能，利用 FUSE（File system in User Space）模块将 GlusterFS 挂载到本地文件系统之上，实现 POSIX 兼容的方式来访问系统数据。
![image.png](https://img.hacpai.com/file/2019/07/image-1deb4ebb.png)

## GlusterFS创建术语
* Brick: 最基本的存储单元，表示为trusted storage pool中输出的目录，供客户端挂载用。
* Volume: 一个卷。在逻辑上由N个bricks组成.
* FUSE: Unix-like OS上的可动态加载的模块，允许用户不用修改内核即可创建自己的文件系统。
* Glusterd: Gluster management daemon，要在trusted storage pool中所有的服务器上运行。
* POSIX: 一个标准，GlusterFS兼容。

## GlusterFS卷类型
为了满足不同应用对高性能、高可用的需求，GlusterFS 支持 7 种卷，即 `distribute`卷、`stripe`卷、`replica`卷、`distribute stripe`卷、`distribute replica` 卷、`stripe Replica`卷、`distribute stripe replica` 卷。其实不难看出，GlusterFS 卷类型实际上可以分为 3 种基本卷和 4 种复合卷，每种类型的卷都有其自身的特点和适用场景。
### 基本卷
#### 1, distribute volume分布式卷(类似raid 0但是数据不分片)默认
基于Hash算法将文件分布到所有的`brick server`上,只是单纯的扩大了磁盘空间,不具备冗余能力,数据丢了就丢了,由于`distribute volume`使用本地文件系统,因此存取效率并没有提高,相反会应为中间又加上了一层网络传输,效率反而降低了.另外本地存储设备的容量有限制,因此支持超大型文件会有一定的难度
![image.png](https://img.hacpai.com/file/2019/07/image-dab69ecc.png)



#### 2, stripe volume 条带卷(类似raid 0)
类似Raid 0,文件分成数据块以Round Robin(循环)方式分布到`brick server`上,并发粒度是数据块,支持超大文件,大文件的读写性能高(因为他是分块存储,可以同时多个磁盘写入)
![image.png](https://img.hacpai.com/file/2019/07/image-a7e3daba.png)

#### 3, replica volume 复制卷(类似Raid 1)
类似于Raid1,文件同步的复制到多个brick上,具有容错能力,写性能下降,读性能提升(待测),Replicated模式,也称作AFR(Auto File Replicated),同一个文件在多个镜像存储节点上保存多份,每个节点上都具有想用的目录结构和文件.replica volume是容器存储中较为推崇的一种.
![image.png](https://img.hacpai.com/file/2019/07/image-6e71ba6a.png)

### 复合卷
#### distribute stripe volume分布式条带卷
先组成条带式在组成分布式,集群节点最少4个节点,Brick server 数量是条带数的倍数,分布式的条带卷,volume和brick所包含的存储服务器必须是stripe的倍数,同时拥有分布式和条带式的功能.文件分布在四台文件存储服务器上, 创建卷的时候相邻的两个会组成条带,然后在组成分布式
![image.png](https://img.hacpai.com/file/2019/07/image-2be7732f.png)

#### distribute replica volume 分布式复制卷
Brick server是镜像数的倍数,先组合分布式在组合成复制卷,也是最少需要4台服务器,这个多少组成分布和多少个副本数是自己创建的时候定义的,在后面会介绍到
![image.png](https://img.hacpai.com/file/2019/07/image-47222d48.png)

#### stripe replica volume 条带复制卷
先组合成条带式在组合成复制卷,先把数据分块存放,然后在完整复制,类似 RAID 10，同时具有条带卷和复制卷的特点
![image.png](https://img.hacpai.com/file/2019/07/image-9a46c9c0.png)

#### distribute stripe replica volume 分布式条带复制卷
三种基础卷的合体
![image.png](https://img.hacpai.com/file/2019/07/image-408e3244.png)


## GlusterFS客户端常用命令

| 命令 | 功能 |
| :-: | :-: |
| gluster peer probe | 添加节点 |
| gluster peer detach | 移除节点 |
| gluster volume create | 创建卷 |
| gluster volume start $VOLUME_NAME | 启动卷 |
| gluster volume stop $VOLUME_NAME | 停止卷  |
| gluster volume delete $VOlUME_NAME | 删除卷 |
| gluster volume quota enable | 开启卷配额 |
| gluster volume quota disable | 关闭卷配额 |
| gluster volume quota limitusage | 设定卷配额 |


参考文档:

```bash
https://docs.gluster.org/en/latest/Quick-Start-Guide/Architecture/
```