title: MooseFS 基于keepalive的高可用(未完成)
date: '2019-07-17 21:34:40'
updated: '2019-07-17 21:34:40'
tags: [分布式存储, MFS]
permalink: /articles/2019/07/17/1563370479988.html
---
# MooseFS 基于keepalive的高可用
MooseFS Pro版自带高可用功能，因为我们没有花钱付费所以没办法用此功能，那么我们身为聪明的中国人，既然你不让我用你自带的，那我就自己搞一个

我们继续使用刚才的环境，如果你不知道请你看[环境搭建-主机规划](https://www.zhangshoufu.com/archives/700.html#i-3)

## 环境
我们在log日志服务器上安装另外一台master节点，让他和原来的master节点形成高可
## 在所有的客户端取消挂载，然后在Metalogger安装maste

```bash
[root@node_1_12 ~]# vim /etc/mfs/mfsexports.cfg
10.0.0.0/24 /mfs_test rw,admin,maproot=0:0,password=zhangshoufu,md5pass=MD5
[root@node_1_12 ~]# mkdir /mfs_test
[root@node_1_12 ~]# chown -R mfs.mfs /mfs_test
[root@node_1_12 ~]# systemctl restart moosefs-metalogger
[root@node_1_12 ~]# systemctl start moosefs-master
[root@node_1_12 ~]# systemctl enable moosefs-master
```

## 在master和metalogger上安装keepalive并配置启动
1）在master上

```bash
[root@master_11 ~]# yum -y install keepalived.x86_64 
[root@master_11 ~]# cat /etc/keepalived/keepalived.conf 
! Configuration File for keepalived

global_defs {
   router_id MFS_MASTER_DEVEL
}

vrrp_instance VI_1 {
    state MASTER
    interface eth0
    virtual_router_id 51
    priority 150
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass zhangshoufu
    }
    virtual_ipaddress {
        10.0.0.10
    }
}
```

2）在metalogger上配置
```bash
[root@node_1_12 ~]# yum -y install keepalived.x86_64
[root@node_1_12 ~]# cat /etc/keepalived/keepalived.conf 
! Configuration File for keepalived

global_defs {
   router_id MFS_DEVEL
}

vrrp_instance VI_1 {
    state MASTER
    interface eth0
    virtual_router_id 51
    priority 100
    advert_int 1
    authentication {
        auth_type PASS
        auth_pass zhangshoufu
    }
    virtual_ipaddress {
        10.0.0.10
    }
}
```

3）启动keepalive，并设为开机自动启动

```bash
[root@master_11 ~]#  systemctl start keepalived.service 
[root@node_1_12 ~]# systemctl enable keepalived.service 
[root@node_1_12 ~]#  systemctl start keepalived.service 
[root@node_1_12 ~]# systemctl enable keepalived.service 
```

4）在master上查看 VIP

```bash
[root@master_11 ~]# ip a show eth0
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:d2:23:f7 brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.11/24 brd 10.0.0.255 scope global noprefixroute eth0
       valid_lft forever preferred_lft forever
    inet 10.0.0.10/32 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 fe80::a00:27ff:fed2:23f7/64 scope link 
       valid_lft forever preferred_lft forever
```

## 把所有连接master服务器的地址改写成VIP

```bash
MASTER_HOST = 10.0.0.10
```

## 然后客户端重新挂载

```bash
[root@node_4_15 /]# mfsmount /tmp -o nonempty -H 10.0.0.10:/mfs_test
mfsmaster accepted connection with parameters: read-write,restricted_ip,admin ; root mapped to root:root
[root@node_4_15 /]# cd /tmp/
[root@node_4_15 tmp]# ls 
1.txt
```

## 测试master端down