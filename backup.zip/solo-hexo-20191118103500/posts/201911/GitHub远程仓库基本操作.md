title: GitHub 远程仓库基本操作
date: '2019-11-06 14:39:51'
updated: '2019-11-06 14:39:51'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573022391239.html
---
# GitHub 远程仓库基本操作
Git是分布式版本控制系统，同一个Git仓库，可以分布到不同的机器上，但是开发者必须在同一个网络中，且必须有一个项目的原始版本，通常的办法是让一台电脑充当服务器的角色（roles），每天24小时开机，其他每个人都从这个“服务器”仓库克隆一份代码到自己的电脑上，并且各自把各自的提交推送到服务器仓库里，也从服务器仓库里面拉去别人的提交，完全可以自己党建一台运行Git的服务器，但是现在跟适合的做法是使用免费的托管平台。
Git代码托管平台，首先推荐的是GitHub，好多开源项目都来自GitHub，但是GitHub只能新建公开的Git仓库，私有尚酷要收费，有时候访问还比较卡，如果你做的是一个开源项
目，可以首选 GitHub、coding。如果是公司自己内部使用的代码托管建议使用 Gitlab。

## GitHub公有仓库的使用
 github 是一个基于 git 的代码托管平台，付费用户可以建私人仓库，我们一般的免费用户只能使用公共仓库，也就是代码要公开。
 **[GitHub的官网:](https://github.com/)** https://github.com/
![image.png](https://img.hacpai.com/file/2019/11/image-cb1f3402.png)

注册账号这里我们不细说，相信聪明的你肯定知道如何注册账号，我们直接选择`sign in`登录账号
![image.png](https://img.hacpai.com/file/2019/11/image-c6aabaca.png)

登录上来之后的首页，简单介绍以下都是干什么的
![image.png](https://img.hacpai.com/file/2019/11/image-50d432e3.png)

点击首页上的`start a project`或`+ --> New repository`来创建一个新的项目
![image.png](https://img.hacpai.com/file/2019/11/image-1c4372e2.png)

然后仓库创建完成之后，就出现了三种使用此仓库的方式
![image.png](https://img.hacpai.com/file/2019/11/image-6e2973a4.png)


因为我们本地在`node3`上已经有仓库，我们直接选择第二种的方式来测试本地仓库推送数据到远程仓库，采用ssh的方式来推送

### 为本地test仓库，添加一个名为origin的远程仓库

```bash
[root@zsf_node3 git_test]# git remote add origin git@github.com:shoufuzhang/test.git
//当第一次推送的时候，他问你是否接受公钥，
[root@zsf_node3 git_test]# git push -u origin master
Permission denied (publickey).      //权限被拒绝
fatal: Could not read from remote repository.

Please make sure you have the correct access rights
and the repository exists.
```
因为我们使用的是ssh方式从GitHub上拉去内容，我们却没有配置GitHub仓库的秘钥，所以我们验证失败，会提示我们权限被拒绝，我们现在来把秘钥配置上

先生成一个秘钥，然后配置到GitHub仓库对应的位置
```bash
[root@zsf_node3 git_test]# ssh-keygen -t rsa 
Generating public/private rsa key pair.
Enter file in which to save the key (/root/.ssh/id_rsa): 
Enter passphrase (empty for no passphrase): 
Enter same passphrase again: 
Your identification has been saved in /root/.ssh/id_rsa.
Your public key has been saved in /root/.ssh/id_rsa.pub.
The key fingerprint is:
SHA256:AUSH4B44XHzDeqYAOHK7/ddIM76kcGhBLijB09feOVg root@zsf_node3
The key's randomart image is:
+---[RSA 2048]----+
|.  .o=+..        |
|*.o+. *o         |
|o*+o++ o.E       |
| o+=o.+ +..      |
|o .+++ oS+       |
|. ..oo  + .      |
|    +..o.=       |
|   . o.o+ .      |
|      ....       |
+----[SHA256]-----+
[root@zsf_node3 git_test]# cd /root/.ssh/
[root@zsf_node3 .ssh]# ls 
id_rsa  id_rsa.pub  known_hosts
```
![image.png](https://img.hacpai.com/file/2019/11/image-5d48c5cf.png)
![image.png](https://img.hacpai.com/file/2019/11/image-1e35b080.png)
![image.png](https://img.hacpai.com/file/2019/11/image-69f72423.png)


**注意：1，在gitHub上一个公钥只能对应一个账户，但是一个账户可以对应多个公钥，一个公钥在GitHub上唯一**

### 然后再次进行推送内容到远程仓库上：

```bash
[root@zsf_node3 git_test]# git push -u origin master
Counting objects: 11, done.
Compressing objects: 100% (7/7), done.
Writing objects: 100% (11/11), 1.23 KiB | 0 bytes/s, done.
Total 11 (delta 2), reused 0 (delta 0)
remote: Resolving deltas: 100% (2/2), done.
remote: 
remote: Create a pull request for 'master' on GitHub by visiting:
remote:      https://github.com/shoufuzhang/test/pull/new/master
remote: 
To github.com:shoufuzhang/test.git
 * [new branch]      master -> master   //master分支推送到远程仓库成功
Branch master set up to track remote branch master from origin.
```
![image.png](https://img.hacpai.com/file/2019/11/image-a38346f6.png)

我们已经能在远程的仓库上看到了我们推上去的内容了。

### 克隆远程仓库到本地
 如果我们需要在其他的客户端上使用上面的仓库，这时候我们将 Github 上的仓库克隆一份
 到对应的客户端上即，克隆之前首先需要打通客户端与 Github 之前的认证，具体可参见前
 面的相关内容，然后我们点击绿色按钮,
![image.png](https://img.hacpai.com/file/2019/11/image-df73475d.png)

我们可以点击`Use HTTPS`来切换下载的方式，可以选择ssh或者https,我们这个时候在`node1`节点上来完成这个拉去内容的动作

```bash
[root@zsf_node1 tmp]# git clone https://github.com/shoufuzhang/test.git
Cloning into 'test'...
remote: Enumerating objects: 11, done.
remote: Counting objects: 100% (11/11), done.
remote: Compressing objects: 100% (5/5), done.
remote: Total 11 (delta 2), reused 11 (delta 2), pack-reused 0
Unpacking objects: 100% (11/11), done.
[root@zsf_node1 tmp]# ls 
test
[root@zsf_node1 tmp]# cd test/
[root@zsf_node1 test]# ls -a 
.  ..  .git  passwd
```

我们在`node1`节点上创建一个文件，并把它推送到远程仓库

```bash
[root@zsf_node1 test]# touch node1_file
[root@zsf_node1 test]# git add node1_file
[root@zsf_node1 test]# git commit -m "change node1" node1_file
[master 8029914] change node1
 1 file changed, 0 insertions(+), 0 deletions(-)
 create mode 100644 node1_file 
 
 // 当我们在这台主机上没有配置ssh的时候，他会让你输入GitHub用户和密码
[root@zsf_node1 test]# git push -u origin master 
Username for 'https://github.com': 18163201@qq.com
Password for 'https://18163201@qq.com@github.com': 
Counting objects: 4, done.
Compressing objects: 100% (2/2), done.
Writing objects: 100% (3/3), 271 bytes | 0 bytes/s, done.
Total 3 (delta 0), reused 0 (delta 0)
To https://github.com/shoufuzhang/test.git
   311eef2..8029914  master -> master
Branch master set up to track remote branch master from origin.
```
![image.png](https://img.hacpai.com/file/2019/11/image-74c2d335.png)

### Git fetch 使用
上面我们在node1 向 GitHub 上的远程仓库推送了新的内容，此时对于`node3`上的`test`仓库来说，他的远程仓库已经更新，所以需要将这些更新取回本地，这时就需要用到`git fetch`命令

```bash
[root@zsf_node3 tmp]# git fetch 
fatal: Not a git repository (or any of the parent directories): .git
[root@zsf_node3 tmp]# cd /root/git_test/
[root@zsf_node3 git_test]# git fetch 
Warning: Permanently added the RSA host key for IP address '13.250.177.223' to the list of known hosts.
remote: Enumerating objects: 4, done.
remote: Counting objects: 100% (4/4), done.
remote: Compressing objects: 100% (2/2), done.
remote: Total 3 (delta 0), reused 3 (delta 0), pack-reused 0
Unpacking objects: 100% (3/3), done.
From github.com:shoufuzhang/test
   311eef2..8029914  master     -> origin/master
```
默认情况下，git fetch 取回所有分支(branch)的更新。如果只想取回特定分支的更新，可
以指定分支名。比如取回远程 origin 仓库的 master 分支可以这样写 git fetch origin master。
所取回的更新，在本地主机上要用"远程主机名/分支名"的形式读取。比如 origin 主机的
master，就要用 origin/master 读取。

```bash
//-r 查看远程分支
[root@zsf_node3 git_test]# git branch -r
  origin/master
//-a选项查看所有分支
[root@zsf_node3 git_test]# git branch -a 
* master
  remotes/origin/master
```

然后需要先合并当前本地的分支，分支完成之后才能重新进行推送。
![image.png](https://img.hacpai.com/file/2019/11/image-dd100d5a.png)
