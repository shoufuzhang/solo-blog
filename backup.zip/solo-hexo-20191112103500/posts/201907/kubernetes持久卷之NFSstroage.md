title: kubernetes持久卷之NFS stroage
date: '2019-07-19 17:40:35'
updated: '2019-07-19 17:40:35'
tags: [kubernetes, kubernetes数据持久化]
permalink: /articles/2019/07/19/1563529235225.html
---
# kubernetes持久卷之NFS stroage

```
作者:        张首富
QQ群:        895291458
个人博客:     zhangshoufu.com
文章核心:     kubernetes 通过nfs做持久存储的三种方式
```
nfs应该是kubernetes里面最简单的持久化存储方案了,因为懂Linux服务器的肯定都会使用nfs这个`网络文件系统`.
## kubernetes nfs持久卷存储
我们引用nfs存储的方式如下,
**1, 我们首先要建立好nfs提供的共享目录,在这里我不在啰嗦**

```bash
#cat /etc/exports
/data 192.168.0.0/16(anonuid=65534,anongid=65534,sync,rw,no_subtree_check,no_root_squash)
```
**2, 特别说明**
 想使用nfs做持久卷存储,就必须保证node节点先能访问挂载nfs服务,否则pod挂载不成功.
 
**3, pod中直接引用nfs持久卷存储**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: nfs-test
spec:
  containers:
  - name: nfs-pod
    image: nginx
    imagePullPolicy: IfNotPresent
    ports:
    - name: nfs-port
      containerPort: 80
      protocol: TCP
    volumeMounts:
    - name: nfs-test           #必须和volumes.name字段相等
      mountPath: /data
  volumes:
  - name: nfs-test
    nfs:
      path: /data              #nfs服务共享的目录
      server: 192.168.250      #nfs服务器的地址
```

## kubernetes nfs 之pv and pvc
我们可以利用nfs来创建pv,然后让容器使用pvc来引用pv
**1, 创建pv**
```yaml
#cat nfs-pv.yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: nfs-pv
  labels:
    nfs: nfs-pv
spec:
  capacity:
    storage: 5Gi
  volumeMode: Filesystem
  accessModes:
    - ReadWriteOnce
  persistentVolumeReclaimPolicy: Recycl
  nfs:
    path: /data
    server: 192.168.1.250
```

**2, 创建pvc声明**

```yaml
#cat nfs-pvc.yaml
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: logs-asr-pvc
spec:
  selector:
    matchLabels:
      nfs: nfs-pv
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 5Gi
  volumeMode: Filesystem
```
**3,在pod中引用这个pvc**

```yaml
...
volumes:
- name: asr-volume
  persistentVolumeClaim:
    claimName: logs-asr-pvc
...
```
**4,下面写一个完整版的挂在你pv 和pvc的pod**

```yaml
#先创建一个pv
apiVersion: v1
kind: PersistentVolume
metadata:
  name: nginx-nfs-pv
  lables:
    nfs: nginx-nfs-pv
spec:
  accessModes:
  - ReadWriteOnce
  capacity:
    storage: 5Gi
  volumeMode: Filesystem
  persistentVolumeReclaimPolicy: Recycl
  nfs:
    server: 192.168.1.250
    path: /data

---
#创建一个pvc,引用上面的pv
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: nginx-nfs-pvc
spec:
  selector:
    machLables:
      nfs: nginx-nfs-pv
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 5Gi
  volumeMode: Filesystem

---
#创建一个nginx的pod去引用这个pvc
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  serverName: web
spec:
  containers:
  - name: nginx
    image: nginx:1.14.0
    volumeMounts:
    - name: nginx-volume
      mountPath: /var/www/html
  volumes:
  - name: nginx-volume
    PersistentVolumeClaim:
    claimName: nginx-nfs-pvc
```