title: Docker核心-联合文件系统之AUFS（分层文件系统）
date: '2019-07-17 21:18:19'
updated: '2019-07-17 21:18:19'
tags: [Docker, AUFS]
permalink: /articles/2019/07/17/1563369499417.html
---
# Docker核心-联合文件系统之AUFS（分层文件系统）
1）什么是AUFS？
aufs（全称：advanced multi-layered unification filesystem，高级多层统一文件系统）用于为Linux文件系统实现联合挂载。
AUFS能将一台机器上的多个目录或文件，以联合的方式提供统一视图进行管理。

2）AUFS的特点是什么？
> · 最早docker所支持的storage driver（存储驱动程序）
· 使用这种方式，container启动速度较快
· 存储和内存的使用效率较高
· 支持COW(copy-on-write，多人共同阅读一个文件，谁想修改拷贝出去修改)
· 所有的文件和目录以及挂载点都必须在同一台机器上
· AUFS迟迟不能加入到linux内核主线之中，目前流行的发型版只有ubuntu支持AUFS
· docker的layer较深时效率较为低下
· 因为AUFS是文件级别的动作方式，单个文件很大时，性能和效率不是特别理想

3）AUFS在Docker中的使用
![](media/15403757211916/15403777263503.jpg)
AUFS把每个目录都作为一个AUFS branch，整整齐齐的垛在一起，在最上面提供了一个统一的视图union mount point进行管理。

4）Ubuntu下AUFS的演示
ubuntu使用的版本
root@zsf_docker:/tmp# uname -a
Linux zsf_docker 4.18.0-10-generic #11-Ubuntu SMP Thu Oct 11 15:13:55 UTC 2018 x86_64 x86_64 x86_64 GNU/Linux

准备：

```bash
root@zsf_docker:/tmp# mkdir /tmp/test_dir_1/{1..3} -p
root@zsf_docker:/tmp# mkdir /tmp/test_dir_2/{3..5} -p
root@zsf_docker:/tmp# mkdir /tmp/mount //创建挂载点
```
挂载：

```bash
root@zsf_docker:/tmp# mount -t aufs -o br=/tmp/test_dir_1=ro:/tmp/test_dir_2=rw none /tmp/mount
// -t 指定挂载类型
// -o 指定挂载类型
// br 挂载对象的文件夹
// ro/rw 指定文件的权限只读和可读写
// device 没有设备所以用none表示
```

查看挂载后的信息目录

```bash
root@zsf_docker:/tmp# tree /tmp/mount/
/tmp/mount/
├── 1
├── 2
├── 3
├── 4
└── 5
可以发现，他把相同的目录给覆盖了
```
挂载后确认2目录下只读

```bash
root@zsf_docker:/tmp# echo "zhang shoufu" >> /tmp/mount/2/test.txt
bash: /tmp/mount/2/test.txt: Read-only file system
```

然后测试目录3可不可以写入数据

```bash
root@zsf_docker:/tmp# echo "zhang shoufu" >> /tmp/mount/3/test.txt
bash: /tmp/mount/3/test.txt: Read-only file system
// 发现目录3里面还是不能写入，和我们的猜想不一样
经过思考原来是我们挂载的时候出了问题，我们把不可写的那一层放在上面了
```

重新挂载测试

```bash
root@zsf_docker:/tmp# umount mount/
root@zsf_docker:/tmp# mount -t aufs -o br=/tmp/test_dir_2=ro:/tmp/test_dir_1=rw none /tmp/mount
root@zsf_docker:/tmp# echo "zhang shoufu" >> /tmp/mount/3/test.txt
bash: /tmp/mount/3/test.txt: Read-only file system

root@zsf_docker:/tmp# umount mount/
root@zsf_docker:/tmp# mount -t aufs -o br=/tmp/test_dir_2=rw:/tmp/test_dir_1=ro none /tmp/mount
root@zsf_docker:/tmp# echo "zhang shoufu" >> /tmp/mount/3/test.txt
```
经过几次测试，我们可以发现AUFS会目录分层，起作用的是最上面一层的权限。如果数据能写入也只是在当前这个目录下生效，在原始只读的文件上没有实际写入

Docker技术在：不可写的images（文件）镜像上面在挂载一层可写层，虽然我们看着文件内容是改变了，但是实际上是未改变的

测试：

```bash
root@zsf_docker:/# mount -t aufs -o br=/tmp/test_dir_2=rw:/tmp/test_dir_1=ro none /tmp/mount
root@zsf_docker:/# cat /tmp/test_dir_1/1
zhang shoufu
root@zsf_docker:/# tree /tmp/
/tmp/
├── mount    //挂载后的目录，相同的目录叠加了
│   ├── 1
│   ├── 2
│   ├── 3
│   └── 4
├── test_dir_1
│   ├── 1
│   ├── 2
│   └── 3
└── test_dir_2
    ├── 2
    ├── 3
    └── 4

3 directories, 10 files
root@zsf_docker:/# cat /tmp/mount/1  //读取的时候是不会改变底层的内容
zhang shoufu
root@zsf_docker:/# tree /tmp/
/tmp/
├── mount
│   ├── 1
│   ├── 2
│   ├── 3
│   └── 4
├── test_dir_1
│   ├── 1
│   ├── 2
│   └── 3
└── test_dir_2
    ├── 2
    ├── 3
    └── 4

3 directories, 10 files
root@zsf_docker:/# echo "zsf" > /tmp/mount/1  //改完这个之后发现test_dir_2多了个1目录
root@zsf_docker:/# tree /tmp/
/tmp/
├── mount
│   ├── 1
│   ├── 2
│   ├── 3
│   └── 4
├── test_dir_1
│   ├── 1
│   ├── 2
│   └── 3
└── test_dir_2
    ├── 1
    ├── 2
    ├── 3
    └── 4

3 directories, 11 files
root@zsf_docker:/# cat /tmp/test_dir_1/1  //实际底层是没有改变的
zhang shoufu
root@zsf_docker:/# cat /tmp/mount/1       
zsf
root@zsf_docker:/# cat /tmp/test_dir_2/1
zsf
```
验证结果：
    1，docker写入数据实际上是加入了一层可写层
    2，虽然我们看到他的文件是改变了，但实际上底层镜像还是没有改变
    3，我们只是把这个文件复制出来再进行更改（copy-to-write模式）