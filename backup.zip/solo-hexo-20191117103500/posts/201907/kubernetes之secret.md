title: kubernetes 之 secret
date: '2019-07-19 17:42:23'
updated: '2019-07-19 17:42:23'
tags: [kubernetes, kubernetes数据持久化]
permalink: /articles/2019/07/19/1563529343247.html
---
# kubernetes 之 secret
```bash
作者: 张首富
时间: 2019-04-12
个人博客: www.zhangshoufu.com
QQ群: 895291458
```
## service Account Secret
为了能从Pod内部访问Kubernetes API，Kubernetes提供了Service Account资源。 Service Account会自动创建和挂载访问Kubernetes API的Secret，会挂载到Pod的 /var/run/secrets/kubernetes.io/serviceaccount目录中。

## Opaque Secret
Opaue类型的Secret是一个map结构(key-value)，其中vlaue要求以**base64**格式编码。

我们可以使用yaml文件手动创建Opaue Secret：

```bash
echo -n "admin" | base64
YWRtaW4=
echo -n "1f2d1e2e67df" | base64
MWYyZDFlMmU2N2Rm
```
secret.yaml:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: mysecret
type: Opaque
data:
  username: YWRtaW4=
  password: MWYyZDFlMmU2N2Rm
```
也可以从文件创建Secret，将文件内容保存到Secret中，这种情况多用于秘钥证书和配置文件：

```bash
kubectl create secret generic etcd-tls-secret  \
  --from-file=/etc/etcd/ssl/etcd.pem \
  --from-file=/etc/etcd/ssl/etcd-key.pem  \
  --from-file=/etc/etcd/ssl/ca.pem \
  -n kube-system


kubectl describe secret etcd-tls-secret -n kube-system
Name:           etcd-tls-secret
Namespace:      kube-system
Labels:         <none>
Annotations:    <none>

Type:   Opaque

Data
====
etcd-key.pem:   1675 bytes
etcd.pem:       1489 bytes
ca.pem:         1330 bytes
```
## 用于创建登录docker 私有仓库的认证文件
### 应用场景
当我们在k8s里面引用docker的时候,我们可能会从不同的Docker registries中拉去镜像,我们大家都知道如果我们想要从Docker registries拉取镜像我们就必须先要在docker宿主机上登录这个docker仓库,对于k8s这种自动化平台工具,我们手工登录显而易见是很蠢的办法,所以我们采用secret这种加密数据卷的方式来存放Docker registries登录的信息,让拉取的时候自动登录,从而实现自动化

### 创建docker认证使用的secret
我们使用如下命令获取帮助
```bash
kubectl create secret docker-registry --help
Options:
      --append-hash=false: Append a hash of the secret to its name.
      --docker-email='': Email for Docker registry
      --docker-password='': Password for Docker registry authentication
      --docker-server='https://index.docker.io/v1/': Server location for Docker registry
      --docker-username='': Username for Docker registry authentication
      --dry-run=false: If true, only print the object that would be sent, without sending it.
      --from-file=[]: Key files can be specified using their file path, in which case a default name will be given to
them, or optionally with a name and file path, in which case the given name will be used.  Specifying a directory will
iterate each named file in the directory that is a valid secret key.
      --generator='secret-for-docker-registry/v1': The name of the API generator to use.
```

### 举例

```bash
kubectl create secret docker-registry my-test-dockercfg --docker-username='test-docker-user' --docker-password='docker-password' --docker-server='https://192.168.1.222'
```
查看yaml详细信息:

```bash
[root@rke ~]# kubectl get  secret my-test-dockercfg -o yaml
apiVersion: v1
data:
  .dockerconfigjson: eyJhdXRocyI6eyJodHRwczovLzE5Mi4xNjguMS4yMjIiOnsidXNlcm5hbWUiOiJ0ZXN0LWRvY2tlci11c2VyIiwicGFzc3dvcmQiOiJkb2NrZXItcGFzc3dvcmQiLCJhdXRoIjoiZEdWemRDMWtiMk5yWlhJdGRYTmxjanBrYjJOclpYSXRjR0Z6YzNkdmNtUT0ifX19
kind: Secret
metadata:
  creationTimestamp: "2019-04-12T00:32:12Z"
  name: my-test-dockercfg
  namespace: default
  resourceVersion: "7089031"
  selfLink: /api/v1/namespaces/default/secrets/my-test-dockercfg
  uid: 6a483153-5cba-11e9-b923-e0d55e1cf4c9
type: kubernetes.io/dockerconfigjson
```

在yaml文件里面引用:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: test-secret
spec:
  containers:
    - name: nginx
      image: 192.168.1.222/nginx
  imagePullSecrets:
    - name: my-test-dockercfg
```

## 使用Secret的两种方式
### 将Secret挂载为Volume

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: mypod
  namespace: myns
spec: 
  containers:
    - name: mypod
      image: reids
      volumeMounts:
        - name: foo
          mountPath: /etc/foo
          readOnly: true
  volumes:
    - name: foo
      secret:
        secretName: mysecret
```

将Secret导出为环境变量:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: secret-env-pod
spec:
  containers:
    - name: mycontainer
      image: redis
      env:
        - name: SECRET_USERNAME
          valueFrom:
            secretKeyRef:
              name: mysecret
              key: username
        - name: SECRET_PASSWORD
          valueFrom:
            secretKeyRef:
              name: mysecret
              key: password
  restartPolicy: Never
```

参考资料:
https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/
https://kubernetes.io/docs/concepts/configuration/secret/