title: GoLang 变量 和 常量
date: '2019-07-19 17:50:41'
updated: '2019-07-19 17:50:41'
tags: [GO]
permalink: /articles/2019/07/19/1563529841850.html
---
# GoLang 变量 和 常量
## 变量
和别的语言的变量没有什么不同，变量相当于一块数据存储空间的命名，程序可以通过定义一个变量来申请一块数据存储空间，之后可以通过引用变量名来使用这块存储空间。
go语言对于变量和其他的语言的区别就是，**go语言定义的变量在下方必须被使用，否则报错**
### 变量的声明
对存粹的变量声明，G引入关键字`var`，而类型放在变量名字后

```go
var v1 int
var v2 float32
var v3 [5]int //数组
var v4 []int //切片
var v5 struct {
    f int
}
var v6 *int //指针
var v7 map[string]int //map，key为string类型，value为int类型
```
上面等同于

```go
var （
    v1 int
    v2 float32
    v3 [5]int
    v4 []int
    v5 struct {
        f int
    }
    v6 *int
    v7 map[string]int 
）
```

### 变量初始化
go语言默认变量的初始化的值为

```go
package main

import "fmt"

func main() {
	var (
		v1 int
		v2 float32
		v3 [5]int
		v4 []int
	)
	fmt.Println("int 初始化值为： ",v1)
	fmt.Println("float32 初始化值为： ",v2)
	fmt.Println("数组 初始化值为： ",v3)
	fmt.Println("切片 初始化值为： ",v4)
}
```
运行结果：
```
int 初始化值为：  0
float32 初始化值为：  0
数组 初始化值为：  [0 0 0 0 0]
切片 初始化值为：  []
```
变量定义的时候直接初始化赋值：

```go
package main

import "fmt"

func main() {
	var (
		v1 int = 10
		v2 float32 = 10.00
		v3 = [5]int{1,2,3,4,5}
		v4 = []int{1,2,3,4}
	)
	fmt.Println(v1,v2,v3,v4)
}
```

### 变量声明直接赋值

```go
package main

import "fmt"

func main() {

	v1 := 10
	v2 := 10.00
	v3 = [5]int{1, 2, 3, 4, 5}
	v4 = []int{1, 2, 3, 4}
	fmt.Println(v1, v2, v3, v4)
}
```
### 交叉赋值 
go替换两个变量值的时候不需要引用第三个变量，节省了内存空间
```go
package main

import "fmt"

func main() {

	v1 := 10
	v2 := 88
	v1, v2 = v2, v1
	fmt.Println(v1, v2)

}
```
### 匿名变量
_ (下划线)是个特殊的变量名，赋予它任何值都会被丢弃。
```go
package main

import (
	"fmt"
	"io/ioutil"
)

func main() {
	v1 ,v2 := 100,88.88
	fmt.Println(v1,v2)
	str,_ := ioutil.ReadFile("/etc/passwd")
	fmt.Println(str)
}
```
`_`最常使用的方式就是屏蔽一个接收值

### 注意
1）go对于已经声明但是未使用的变量会在编译阶段报错
2）大写字母开头的变量时公用变量，小写字母开头的变量是私有变量。
3）大写字母开头的函数也是一样

## 常量
### 定义常量
常量，就是在程序编译阶段就确定下来的值，而程序在运行时则无法改变该值。在Go程序中，常量可以是数值类型（包括整型、浮点型、和复数类型）、布尔类型、字符串类型。

```go
const constantName [type] = value
```
Go常量定义可以限定常量类型，但不是必需的。如果定义常量时没有指定类型，那么它是无类型常量 。只要这个常量在相应类型的值域范围内，就可以作为该类型的常量，


### 预定义常量
Go语言与定义了一些常量： true、false、iota
iota比较特殊，可以被认为是一个可以被编译器修改的常量，他默认的开始值是0，每次调用加1。遇到const关键字时被重置为0

```go
const (       // iota被重设为0
    c0 = iota // c0 == 0
    c1 = iota // c1 == 1
    c2 = iota // c2 == 2
)

const (
    a = 1 << iota // a == 1 (iota在每个const开头被重设为0)
    b = 1 << iota // b == 2
    c = 1 << iota // c == 4
)

const (
    u = iota * 42         // u == 0
    v float64 = iota * 42 // v == 42.0
    w = iota * 42         // w == 84
)

const x = iota // x == 0 (因为iota又被重设为0了)
const y = iota // y == 0 (同上)
```

如果两个const的赋值语句的表达式是一样的，那么可以省略后一个赋值表达式。因此，上面的前两个const语句可简写为：

```go
const (       // iota被重设为0
    c0 = iota // c0 == 0
    c1        // c1 == 1
    c2        // c2 == 2
)
const (
    a = 1 <<iota // a == 1 (iota在每个const开头被重设为0)
    b            // b == 2
    c            // c == 4
)
```
举例：

```go
package main
import (
	"testing"
)
const (
	Monday = iota + 1
	Tuesday
	Wednesday
)
func TestConstTest(t *testing.T) {
	t.Log(Wednesday,Tuesday)
}
const (
	Readable = 1 << iota
	Writable
	Executable
)
func TestConstTestYu(t *testing.T) {
	a := 7 // 0111
	//与 运算,当相同位置上都为1的时候才为1
	t.Log(a&Readable==Readable,a&Writable==Writable,a&Executable==Executable)
	a = 5 //0101
	t.Log(a&Readable==Readable,a&Writable==Writable,a&Executable==Executable)
}

```
## 枚举
枚举是指一系列相关的常量 。Go语言并不支持众多其他语言明确支持的enum关键字。在 const 后跟一对圆括号的方式定义一组常量，这种定义法在Go语言中通常用于定义枚举值。

比如关于一个星期中每天的定义,下面是一个常规的枚举表示法，其中定义了一系列整型常量：

```go
const (
    Sunday = iota
    Monday
    Tuesday
    Wednesday
    Thursday
    Friday
    Saturday
    numberOfDays // 这个常量没有导出
)
```