title: Go对文件的操作
date: '2019-08-24 09:52:24'
updated: '2019-08-24 09:52:24'
tags: [GO]
permalink: /articles/2019/08/24/1566611544198.html
---
# Go对文件的操作
## 获取文件的属性
我们使用 `os.Stat`函数来获取文件的属性，返回的是一个 自定义数据类型和错误

```go
func Stat(name string) (FileInfo, error)
```
文件类型FileInfo的定义如下

```go
type FileInfo interface {
    Name() string          //文件的名称
    Size() int64           //文件的大小,单位是字节
    Mode() FileMode        //文件的修改时间
    ModTime() time.Time    //文件的修改时间
    IsDir() bool           //文件是否为目录，是目录为true，不是为false
    Sys() interface{}
}
```
#### 举例：
```go
package main

import (
	"fmt"
	"os"
)


func main() {
	//1,获取文件属性
	fileInfo ,err := os.Stat("/Users/zhumengyuan/Desktop/error")
	if err!= nil {
		fmt.Println("err: ",err)
		return
	}
	fmt.Println("文件名称：",fileInfo.Name())
	fmt.Println("文件大小：",fileInfo.Size())
	fmt.Println("文件修改时间：",fileInfo.Mode())
	Bool := fileInfo.IsDir()
	if Bool {
		fmt.Printf("%s是一个目录",fileInfo.Name())
	}else {
		fmt.Printf("%s是一个文件",fileInfo.Name())
	}
}
```
执行结构：

```go
文件名称： error
文件大小： 10353
文件修改时间： -rw-r--r--
error是一个文件
```

## 2，对文件路径的操作
> 1,绝对路径
>   指从根目录开始的路径
> 2，相对路径
>   相对于当前的工程路径所在的路径（GOPATH）


```go
	fileName1 := "/Users/zhumengyuan/Desktop/error"
	fileName2 := "error"
	//判断路径是否为绝对路径，返回值为bool值
	fmt.Println(filepath.IsAbs(fileName1))
	fmt.Println(filepath.IsAbs(fileName1))
	//显示当前文件的绝对路径
	fmt.Println(filepath.Abs(fileName1))
	fmt.Println(filepath.Abs(fileName2))
```
执行结果
```go
true
false
/Users/zhumengyuan/Desktop/houtai.sql <nil>
/Users/zhumengyuan/go/src/awesomeProject/houtai.sql <nil>
```



## 获取当前文件的目录

```go
fileName1 := "/Users/zhumengyuan/Desktop/error"
fmt.Println("文件上两级目录是哪个：", path.Join(fileName1, "../../"))
fmt.Println("文件的父目录是哪个：",path.Join(fileName1, "../"))
```
执行结果

```go
文件上两级目录是哪个： /Users/zhumengyuan
文件的父目录是哪个： /Users/zhumengyuan/Desktop
```

## 创建目录

```go
os.Mkdir("/Users/zhumengyuan/Desktop/aa", 0777) // func Mkdir(name string, perm FileMode) error
err := os.Mkdir("/Users/zhumengyuan/Desktop/aa/bb/cc", 0644)
if err != nil {
	fmt.Println("err", err)  //err mkdir /Users/zhumengyuan/Desktop/aa/bb/cc: no such file or directory
}
os.MkdirAll("/Users/zhumengyuan/Desktop/aa/bb/cc", os.ModePerm) //相当于mkdir -p  os.MedePerm读取默认的权限
```
使用`os.Mkdir`的时候我们一次只能创建一个层级的目录，不能递归创建，如果我们想递归创建就需要使用`os.MkdirAll`
* 

## File 操作

```go
type File
//File代表一个打开的文件对象

func Create(name string) (*File, error)
//Create 采用模式0666（文件只拥有rw权限），如果文件已经存在会截断它（会清空文件）。如果成功，返回的未见对应可用于I/O；对应的文件描述符具有O_RDWR 模式。如果出错，错误地城类型的事 *PathError。

func Open(name string) (*File, error)
//Open打开文件用于读取，如果操作成功返回的文件对象的方法可用于读取数据；对应的文件描述符具有O_RDONLY(只读)模式。如果出错，错误底层数据是*PathError

func OpenFile(name string, flag int, perm FileMode) (*File, error)
//OpenFile是一个一般性的文件打开函数，大多数调用者都应用 Open 或者Create代替OpenFile 函数，他会使用指定的选项（如O_RDNLY等），指定的模式（如0666等）打开指定名称的文件，如果操作成功返回的文件对象可用于I/O，如果出错，错误底层数据是*PathError

func NewFile(fd uintptr, name string) *File
//NewFIle使用给出的Unix文件描述符和名称创建一个文件

```
### 文件操作权限

```go
const (
	// Exactly one of O_RDONLY, O_WRONLY, or O_RDWR must be specified.
	O_RDONLY int = syscall.O_RDONLY   //只读打开文件
	O_WRONLY int = syscall.O_WRONLY   //只写打开文件
	O_RDWR   int = syscall.O_RDWR     //读写模式打开文件 
	// The remaining values may be or'ed in to control behavior.
	O_APPEND int = syscall.O_APPEND   //写操作时将数据附加到文件尾部
	O_CREATE int = syscall.O_CREAT    //如果文件不存在将创建一个新文件
	O_EXCL   int = syscall.O_EXCL     //和O_CREAT配合使用，文件必须不存在	O_SYNC   int = syscall.O_SYNC     //打开文件用于同步I/O
	O_TRUNC  int = syscall.O_TRUNC    //如果可能，文件打开时清空
)
```
### 创建一个文件
```go
/*
		1,参数 打开的文件
		2， 以什么方式打开文件
		3，当文件不存在的时候创建出来的文件是什么权限
	*/
	fileErr, err := os.OpenFile("/Users/zhumengyuan/Desktop/error", os.O_RDONLY|os.O_WRONLY, 0755)
	if err != nil {
		fmt.Println("err", err)
		return
	}
	fmt.Println(fileErr)
	//关闭文件
	fileErr.Close()
```

## 删除文件或删除文件夹

```go
	err = os.Remove("/Users/zhumengyuan/Desktop/error")
	if err != nil {
		fmt.Println("err:", err)
		return
	}
	fmt.Println("删除文件成功")
	
	//递归删除，删除这个目录和这个目录下的所有文件
	err = os.Remove("/Users/zhumengyuan/Desktop/aa")
	if err != nil {
		fmt.Println("err:", err)   //err: remove /Users/zhumengyuan/Desktop/aa: directory not empty
		return
	}
	fmt.Println("删除aa目录成功")
	err = os.RemoveAll("/Users/zhumengyuan/Desktop/aa")
	if err != nil {
		fmt.Println("err:", err)
		return
	}
	fmt.Println("删除aa目录成功")
```