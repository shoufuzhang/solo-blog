title: kubernetes 通讯浅谈
date: '2019-10-13 21:21:48'
updated: '2019-10-14 08:23:46'
tags: [kubernetes]
permalink: /articles/2019/10/13/1570972908920.html
---
# kubernetes 通讯浅谈
我们在日常工作中，能遇见的情况只有下面三种，k8s集群内部之间的相互连接，k8s集群内部访问k8s集群外部的服务，还有就是k8s集群外部服务访问k8s集群内部的访问。下面我们来讲解下他们都是如何实现的，我们将使用分步的方式来讲解
## kubernetes集群内部的通讯
当k8s里面只有两个POD之间的通信是最为简单的
![image.png](https://img.hacpai.com/file/2019/10/image-3d720a5c.png)
上图所示是我们`Pod B`客户端去链接请求`Pod A`服务端，这个时候我们只需要把`Pod A`的地址告诉`Pod B`即可，这个时候`Pod A`扛不住请求了，我们需要在扩展一个`Pod A`
![image.png](https://img.hacpai.com/file/2019/10/image-846b5b6c.png)
那我门是不是就想要办法在`Pod A`服务端前面放个Nginx或者什么的来做负载，只有这样`Pod B`才能按照以前的地址去请求服务啊，所以我们这个时候在`Pod A`上面添加上一个`service`服务
![image.png](https://img.hacpai.com/file/2019/10/image-2bec39e9.png)
svc资源通过`matchLables`字段选择打有对应标签的`Pod`，这个时候`Pod B`在来请求服务的时候就直接去访问`SVC A`，我们告诉`Pod B` `SVC A`所对应的IP地址是什么，`SVC A`会自动负载到后端的`POD A`上，需要注意的是：当这个时候如果 A服务还是扛不住压力，那我们就只需要多启动几个`Pod A`就行了，启动的新的Pod之后，svc还是会根据`matchLables`把它自动添加到负载里面去
我们k8s集群里面不可能只有两种服务啊，肯定有很多服务，但我们不可能每个都手工去配置吧，所以这个时候就引入了`CoreDNS`的概念，我们用CoreDNS来维护svc 和clusterIP的关系
![image.png](https://img.hacpai.com/file/2019/10/image-1e052a0a.png)
其实这个时候 k8s集群内部的通讯就大致讲清楚了，但是这个里面有个及其特殊的svc：`headless svc`，这个svc当别的客户端来请求他的时候，他不会去负载的向下面pod去做请求，而是把下面POD的所有IP返回给客户端，由客户端自己来决定链接那个POD。

## k8s集群内部请求集群外部的服务
如果是单个服务，我们可以选择直接在内部直接连接外部的服务，但是如果外部服务是个集群的话，那如果我们还这样做就需要在外部集群前面做个负载，
![image.png](https://img.hacpai.com/file/2019/10/image-c62ebb28.png)
但是这样如果有很多个集群我们就要创建很多个nginx的4层负载，太麻烦了，我们可以把负载放到k8s集群里面，我们采用k8s的`svc`+`endpoints`来实现外部集群的负载均衡
![image.png](https://img.hacpai.com/file/2019/10/image-621d4038.png)
这个时候`svc`和`endpoint`是通过名字来进行绑定的，这样我们就实现了集群内部和集群外部通讯

## k8s集群外部和k8s集群内部通信
在实际工作中，除了k8s集群内部通讯，我认为就是这种通讯方式使用的比较多，因为我们在k8s上跑的集群不就是为了让客户来访问的吗？下面我们将下三种实现方式
### nodeport
nodeport是我们在node上面所端口绑定，所以node上都会开放此pord端口，我们任意请求其中一个node端口，即使这个pod没有落在这个node上也行，当请求到node port的时候他会自动转发到对应的Podip上来实现访问
![image.png](https://img.hacpai.com/file/2019/10/image-2f1e0ae4.png)
### hostport
必须pod落在那个node上，那个node才会开放对应的端口
### ingress
ingress是我们使用最普遍的暴漏k8s集群内部服务让外部来访问的方式，ingress是一类资源的统称，我们现在一般都适用ingress-nginx，关于ingress 请参考https://www.zhangshoufu.com/articles/2019/07/19/1563529715618.html， 这里不在细说


视频讲解：https://www.bilibili.com/video/av71139472