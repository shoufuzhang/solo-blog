title: docker垃圾回收机制
date: '2019-11-06 21:41:49'
updated: '2019-11-06 21:41:49'
tags: [Docker]
permalink: /articles/2019/11/06/1573047709254.html
---
# docker垃圾回收机制

```bash
作者: 张首富
时间: 2019-04-10
个人博客: www.zhangshoufu.com
QQ群: 895291458
```
## 说明
对于Docker来说,存在镜像/容器/存储卷和网络(iptables规则)这些对象.因此docker也会产生出这些对应的对象,这些对象会占据磁盘空间,当这些对象不会再被使用的时候,为了节省磁盘空间,就需要对这些对象进行清理,即docker的垃圾清理.我们这边针对docker 1.13 以后的版本进行清理
## docker的垃圾清理
### 清理停止的容器
当我们使用`docker stop $ContainerName`命令停止容器的时候,系统并不知道会删除这个容器,除非在运行此容器的时候设置了`-rm`参数,停止后的容器仍然会占据cipan的存储空间,通过`docker container prune`能够删除这些被停止后的容器

```bash
# docker container prune
WARNING! This will remove all stopped containers.
Are you sure you want to continue? [y/N] y
```
执行此命令时，默认会提示是否继续。如果在执行命令是设置了-f或–force字段，则会直接删除已所有已停止的容器。默认情况下，此命令执行时会删除所有的已停止的容器，也可以通过设置–filter字段，来过滤所要删除的容器。例如，下面的命令仅仅删除停止超过24小时的容器。

```bash
# docker container prune --filter "until=24h"
```

### 清除不使用的镜像
通过执行`docker images prune`命令可以清除所有不再使用的镜像，默认情况下此命令仅仅清除状态为dangling的镜像。
**什么样的镜像才为`dangling`的镜像:** 为未被打标签和没有被任何容器引用的镜像。
**什么情况下才会出现:** 原来为 mongo:3.2, 随着官方镜像维护, 发布了新版本后, 重新 docker pull mongo:3.2 时, mongo:3.2 这个镜像名被转移到了新下载的镜像身上, 而旧的镜像上的这个名称则被取消, 从而成为了 <none>. 除了 docker pull 可能导致这种情况, docker build 也同样可以导致这种现象. 由于新旧镜像同名, 旧镜像名称被取消, 从而出现仓库名、标签均为 <none> 的镜像.

```bash
# docker image prune

WARNING! This will remove all dangling images.
Are you sure you want to continue? [y/N] y
```
移除所有未被使用的镜像,这需要通过设置-a字段来实现,只要未被使用都会被删除

```bash
# docker image prune -a

WARNING! This will remove all images without at least one container associated to them.
Are you sure you want to continue? [y/N] y
```
执行此命令时，默认会提示是否继续。如果在执行命令是设置了-f或–force字段，则会直接进行删除操作。可以通过设置–filter字段，来过滤所要删除的镜像。例如，下面的命令仅仅删除停止创建超过24小时的镜像。

```bash
# docker image prune -a --filter "until=24h"
```

### 删除存储卷
存储卷可以被一个或者多个容器使用，也会占据磁盘空间。为保持数据，存储卷永远都不会自动被删除.
```bash
# docker volume prune

WARNING! This will remove all volumes not used by at least one container.
Are you sure you want to continue? [y/N] y
```
执行此命令时，默认会提示是否继续。如果在执行命令是设置了-f或–force字段，则会直接进行删除操作。默认情况下，此命令执行时会删除所有的未被使用的存储卷，也可以通过设置–filter字段，来过滤所要删除的存储卷。例如，下面的命令仅仅删除label值为keep的存储卷。
```bash
# docker volume prune --filter "label!=keep"
```

### 清除网络(iptables规则)
docker网络并不会占据磁盘空间，但是会创建iptables规则，桥网络设备和路由表。因此，但如何不再使用这些资源时，应该对其进行清理。

```bash
# docker network prune

WARNING! This will remove all networks not used by at least one container.
Are you sure you want to continue? [y/N] y
```
执行此命令时，默认会提示是否继续。如果在执行命令是设置了-f或–force字段，则会直接进行删除操作。默认情况下，此命令执行时会删除所有的未被使用的网络，也可以通过设置–filter字段，来过滤所要删除的网络。例如，下面的命令仅仅为被使用超过24小时的网络。

```bash
# docker network prune --filter "until=24h"
```

### 删除所有的对象(镜像,容器,网络,数据卷)
通过docker system prune命令能够快速的删除所有的未被使用的对象，包括镜像、容器、网络和存储卷。在docker 17.06.0之前，存储卷会同时被清理。在docker 17.06.1之后，需要通过设置–volumes字段，才会同时清理存储卷。

```bash
# docker system prune

WARNING! This will remove:
        - all stopped containers
        - all networks not used by at least one container
        - all dangling images
        - all build cache
Are you sure you want to continue? [y/N] y
```
如果所使用的docker 17.06.1之后的版本，则需要在命令后添加–volumes字段来清理存储卷的内容。

```bash
# docker system prune --volumes

WARNING! This will remove:
        - all stopped containers
        - all networks not used by at least one container
        - all volumes not used by at least one container
        - all dangling images
        - all build cache
Are you sure you want to continue? [y/N] y
```