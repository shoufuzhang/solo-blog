title: MFS（MooseFS分布式文件系统）
date: '2019-07-17 21:33:07'
updated: '2019-07-17 21:33:07'
tags: [分布式存储, MFS]
permalink: /articles/2019/07/17/1563370387410.html
---
# MFS（MooseFS分布式文件系统）
MooseFS[MFS]是一个具有容错性的网络分布式文件系统。它把数据分散存放在多个物理服务器上，而呈现给用户的则是一个统一的资源。 
**官网地址：**[http://www.moosefs.com/](http://www.moosefs.com/)
## MFS简介
MooseFS是一个具有容错性，高可用，高性能，扩展性强的网络分布式文件系统，他将数据分布在多个存储服务器上，这些存储服务器对用户而言就是一块虚拟磁盘，它符合POSIX并且像任何其他类UNIX文件系统一样支持：
* 分层结构：文件和文件夹
* 文件属性
* 特殊文件：
* 硬软链接
* 安全控制和ACL

MooseFS pro企业级架构图，我们使用的普通版，不具有下面的从服务器，不能直接使用它自带的高可用，我们后面介绍另外一种高可用方式`keepalive`
![image.png](https://img.hacpai.com/file/2019/07/image-bc5e62a2.png)
![](media/15423495865308/15423501714085.png)

## MooseFS的优点：
* 高可用性：存储节点(Chunk server)没有单点故障，文件系统的元数据在物理冗余服务器上保存为两个或多个副本，用户数据冗余冗余分布在系统的中存储服务器上
* 低成本的数据安全：MooseFS使用户能够节省大量硬盘空间，保持相同的数据冗余级别。
* 高性能性：支持高性能I/O操作，用户数据可以才雨多存储节点上同时读取/写入。

## MooseFS文件系统的四种角色（roles）
* 管理服务器（managing server ）master：
    负责各个数据存储服务器(chunk server)的管理，文件读写调度，文件空间回收以及恢复、多节点拷贝
    
* 元数据日志服务器（Metalogger server）Metalogger：
    负责备份master服务器的变化日志文件，文件类型为changelog_ml.*.mfs，以便于在master server出问题的时候接替其进行工作
    
* 数据存储服务器（data server）chunk server：
    听从管理服务器调度，提供存储空间，并未客户端提供数据传输。真正存储用户数据的服务器。存储文件时，首先把文件分成块，然后这些块在数据服务器chunkserver 之间复制（复制多少份可以被手工指定，建议设置为3）。数据服务器可以是多个，并且数量越多，可以使用的“磁盘空间”越大，可靠性也越高
    
* 客户机挂载使用 client computer ：
    挂载进程mfs服务器共享出的存储并使用。通过fuse内核接口挂载进程管理服务器上所管理的数据存储服务器共享出的硬盘。 共享的文件系统的用法和 nfs 相似。 使用 MFS 文件系统来存储和访问的主机称为 MFS 的客户端，成功挂接 MFS 文件系统以后，就可以像以前使用 NFS 一样共享这个虚拟性的存储了。
    
## MooseFS文件系统的工作流程
### 读取文件的流程
![image.png](https://img.hacpai.com/file/2019/07/image-97fd830e.png)
![](media/15423495865308/15423547513900.jpg)
1，客户端向master server服务器询问资源所在的位置
2，然后master server服务器返回资源在chunk server上所在的位置
3，客户端拿着返回的地址去找资源，然后chunk server返回实际的资源

### 存储数据的过程
![image.png](https://img.hacpai.com/file/2019/07/image-288e97ad.png)
![](media/15423495865308/15423547628967.jpg)
1，客户端告诉master server服务器他要存储数据
2，然后master server端去查找chunk server上空闲的位置
3，如果chunk server上还有空闲的位置，就会返回给master server位置
4，然后master server返回给客户端，然后客户端拿着这个位置去存储数据
5，chunk server把数据进行多分存储，存储完成之后会返回给客户端，
6，然后断开连接

## 安装构建MooseFS
### 主机规划

| 主机名 | 角色 | IP地址 |
| :-: | :-: | :-: |
| master_11  | Managing server | 10.0.0.11/24 |
| node_1_12 | Metalogger server | 10.0.0.12/24 |
| node_2_13 | chunk server 1 | 10.0.0.13/24 |
| node_3_14 | chunk server 2 | 10.0.0.14/24 |
| Node_4_15 | client computers  | 10.0.0.15/24 |

### 环境准备
实验所需要的主机都必须支持FUSE内核模块，因为mfs的客户端程序也就是加载mfs磁盘系统的命令是使用了fuse，因此只要是想要挂在mfs的服务器，必要的前提条件就是先安装fuse，这样编译mfs的时候才能通过
> FUSE：用户空间文件系统（Filesystem in Userspace）是操作系统中的概念，指完全在用户态实现的文件系统，，注：2.6内核以上都自带FUSE

* 所有的服务器采用：`centos 7.5`
* 关闭selinux和IPtables

### 开始搭建
1）在所有的服务器添加yum源

```bash
curl "http://ppa.moosefs.com/MooseFS-3-el7.repo" > /etc/yum.repos.d/MooseFS.repo
sed -i "/^gpgcheck/c gpgcheck=0" /etc/yum.repos.d/MooseFS.repo
yum clean  all 
yum list
```

2) 在主服务器上安装

```bash
[root@master_11 /]# yum install -y moosefs-master moosefs-cgi moosefs-cgiserv moosefs-cli
[root@master_11 /]# rpm -ql moosefs-master
/etc/mfs/mfsexports.cfg.sample
/etc/mfs/mfsmaster.cfg.sample
/etc/mfs/mfstopology.cfg.sample
```

3) 在metaloggers服务器上

```bash
[root@node_1_12 /]# yum install moosefs-metalogger -y
[root@node_1_12 /]# rpm -ql moosefs-metalogger
/etc/mfs/mfsmetalogger.cfg.sample
```

4) 在数据节点上chunk server

```bash
[root@node_2_13 monitor]# yum install moosefs-chunkserver  -y
[root@node_3_14 monitor]# yum install moosefs-chunkserver  -y
[root@node_2_13 monitor]# rpm -ql moosefs-chunkserver
/etc/mfs/mfschunkserver.cfg.sample
/etc/mfs/mfshdd.cfg.sample
```

5) 在客户节点上安装

```bash
[root@node_4_15 ~]# yum -y  install moosefs-client
[root@node_4_15 ~]# rpm -ql moosefs-client
/etc/mfs/mfsmount.cfg.sample
```

6) 在master端修改共享出去的目录和权限

```bash
[root@master_11 ~]# echo '10.0.0.0/24 /mfs_test rw,admin,maproot=0:0' >> /etc/mfs/mfsexports.cfg
[root@master_11 /]# systemctl start moosefs-master.service
[root@master_11 /]# systemctl enable moosefs-master.service
[root@master_11 /]# netstat -ntalp | grep mfsmaster
tcp        0      0 0.0.0.0:9419            0.0.0.0:*               LISTEN      3969/mfsmaster      
tcp        0      0 0.0.0.0:9420            0.0.0.0:*               LISTEN      3969/mfsmaster      
tcp        0      0 0.0.0.0:9421            0.0.0.0:*               LISTEN      3969/mfsmaster
```

7）在日志服务器上配置manage端的地址

```bash
[root@node_1_12 mfs]# vim /etc/mfs/mfsmetalogger.cfg
MASTER_HOST = 10.0.0.11
[root@node_1_12 mfs]# systemctl start moosefs-metalogger.service
[root@node_1_12 mfs]# systemctl enable moosefs-metalogger.service
[root@node_1_12 mfs]# netstat -ntalp | grep mfs
tcp        0      0 10.0.0.12:45152         10.0.0.11:9419          ESTABLISHED 2837/mfsmetalogger
// 可以看出log端和master端已经成功建立连接
```

8）修改chunk server端并启动

```bash
[root@node_2_13 mfs]# vim mfschunkserver.cfg
MASTER_HOST = 10.0.0.11
[root@node_2_13 mfs]# vim mfshdd.cfg
/tmp    //数据存放在哪个地方，一般工作中会配置一个独立的分区
[root@node_2_13 mfs]# systemctl start moosefs-chunkserver.service
[root@node_2_13 mfs]# systemctl enable moosefs-chunkserver.service
[root@node_2_13 mfs]# netstat -ntalp | grep mfs
tcp        0      0 0.0.0.0:9422            0.0.0.0:*               LISTEN      1387/mfschunkserver 
tcp        0      0 10.0.0.13:45530         10.0.0.11:9420          ESTABLISHED 1387/mfschunkserver 
// 可以看出他已经与master端建立连接了，另外一台chunk server也做同样的配置

[root@node_2_13 tmp]# ls 
00  22  44  66  88  AA                            C8  EA
01  23  45  67  89  AB                            C9  EB
02  24  46  68  8A  AC                            CA  EC
03  25  47  69  8B  AD                            CB  ED
04  26  48  6A  8C  AE                            CC  EE
// 分块存储，人类无法直接识别
```

9) 客户端挂载

```bash
[root@node_4_15 mfs]# vim mfsmount.cfg
mfsmaster=10.0.0.11
[root@node_4_15 mfs]# mfsmount /tmp/ -o nonempty -H 10.0.0.11:/mfs_test -p
mfsmaster accepted connection with parameters: read-write,restricted_ip,admin ; root mapped to root:root
挂载的目录是master管理端 mfshdd.cfg 里面的共享目录和权限，如果我没没有指定连接的密码，就需要使用 -o nonempty 参数来信任密码
```

10) 取消挂载

```bash
[root@node_4_15 ~]# umount -t fuse.mfs /tmp/
```

11）开启web界面

在master server上面执行

```bash
[root@master_11 ~]# mfscgiserv 
lockfile created and locked
starting simple cvimgi server (host: any , port: 9425 , rootpath: /usr/share/mfscgi)
```
然后浏览器访问IP:9425端口

## 优化操作
### 设定文件copy的份数（mfssetgoal）
在client 端执行命令
```bash
[root@node_4_15 tmp]# mfssetgoal -r 1 /tmp/
-r递归 1代表一份，然后在哪个挂载目录上实行
```

### 查看一个文件被复制了几份（mfscheckfile\mfsfileinfo）
在client端执行命令
```bash
mfscheckfile /tmp/sshd /tmp/1.txt 
/tmp/sshd:
 chunks with 1 copy:             1
/tmp/1.txt:
chunks with 1 copy:              1
// chunks with 1 copy 代表当前复制了1份
```

测试copy份数的设定是否成功
```bash
[root@node_4_15 tmp]# mfssetgoal -r 2 /tmp/
/tmp/:
 inodes with goal changed:                      47
 inodes with goal not changed:                   0
 inodes with permission denied:                  0
[root@node_4_15 tmp]# mfscheckfile /tmp/sshd /tmp/1.txt 
/tmp/sshd:
 chunks with 2 copies:            1
```

### mfsfileinfo 查看文件属性
mfsfileinfo的参数：
* -q：简洁模式，仅显示副本数，拷贝的份数
* -c：从chunkserver接收块校验和
* -s：计算文件签名(使用校验和)


```bash
[root@node_4_15 tmp]# mfsfileinfo /tmp/sshd 
/tmp/sshd:
        chunk 0: 0000000000000038_00000001 / (id:56 ver:1)
                copy 1: 10.0.0.13:9422 (status:VALID)
                copy 2: 10.0.0.14:9422 (status:VALID)
// 从上述可以看出两个副本存在的位置
```

### mfsgetclass 显示文件的副本数和目录的副本数

```bash
[root@node_4_15 tmp]# mfsgetsclass -r /tmp/
/tmp/:
 files with goal                2 :         46
 directories with goal          2 :          2
```

### mfsdirinfo 显示目录的状态

用法：mfsdirinfo [-nhHkmg] [-idfclsr] [-p] name [name ...]

* -n - 以简单格式显示数字
* -h-使用基数2前缀的“人类可读”数字（IEC 60027）
* -H - 使用基数10前缀（SI）的“可读”数字
* -k - 以千比数显示纯数字（二进制千 - 1024）
* -m - 在mebis中显示纯数字（二进制mega - 1024 ^ 2）
* -g - 以赤字显示纯数字（二进制千兆 - 1024 ^ 3）

'显示'开关：
* -i - 显示索引节点数
* -d - 显示目录数
* -f - 显示文件数
* -c - 显示块数
* -l - 显示长度
* -s - 显示大小
* -r - 显示realsize
'模式'开关：
* -p - 精确模式


```bash
[root@node_4_15 tmp]# mfsdirinfo -h /tmp/
/tmp/:
 inodes:           48           //当前使用的inode号
  directories:      2           //两个目录
  files:           46           //46个文件
 chunks:           33           //占用了33个块
 length:        28KiB           //文件的总大小是28K
 size:         2.3MiB           //块长度总和为2.3M
 realsize:     4.6MiB           //使用的磁盘空间，因为我们是复制了2份，所以。。
 
 [root@node_4_15 tmp]# mfsdirinfo -h -p /tmp/
/tmp/:
 inodes:           48
  directories:      2
  files:           46
 chunks:           33
 length:        28KiB
 size:         2.3MiB
 realsize:     4.6MiB
/tmp/ (precise data):
 inodes:           48
  directories:      2
  files:           46
 chunks:           33
 length:        28KiB
 size:         2.3MiB
 realsize:     4.6MiB
```

### mfssetgoal和mfsgetgoal命令
mfssetgoal设置目标copy的份数

```bash
mfssetgoal 3 /tmp  //tmp目录下的copy 3份，但是他里面的目录还是备份两份
mfssetgoal -r 3 /tmp  //tmp目录下所有的文件copy 3份，包括他里面的子目录
```

mfsgetgoal获取目标copy的份数

```bash
[root@node_4_15 tmp]# mfsgetgoal /tmp/
/tmp/: 2
[root@node_4_15 tmp]# mfsgetgoal /tmp/sshd
/tmp/sshd: 2
```

### mfsgetquota 获取执行目录给定的配额

```bash
[root@node_4_15 tmp]# mfsgetquota -h /tmp/
/tmp/: (current values | soft quota | hard quota) ; soft quota grace period: default
 inodes   |     47 |      - |      - |
 length   |  28KiB |      - |      - |
 当前值      软配额     硬配额
 
 [root@node_4_15 tmp]# mfsgetquota -h /tmp/123/
/tmp/123/: (current values | soft quota | hard quota) ; soft quota grace period: default
 inodes   |      0 |      - |      - |
 length   |     0B |      - |      - |
```

### mfsrsettrashtime和mfsgettrashtime命令 垃圾箱存放时间
删除的文件存放在“垃圾箱（trash bin）”的时间就是隔离时间（quarantine time）,这个时间可以用mfsgettrashtime 来验证，也可以用mfssettrashtime来设置。设置的时间是按照小时计算，设置的单位是秒，不满一小时就按一小时计算。

## mfs web展示界面介绍
![image.png](https://img.hacpai.com/file/2019/07/image-fa023487.png)
![](media/15423495865308/15425078911295.jpg)
* 1、当前master端的Ip地址
* 2、当前的mfs的版本
* 3、当前内存的使用
* 4、cpu的使用率
* 5、总共的磁盘大小
* 6、可用的磁盘大小


