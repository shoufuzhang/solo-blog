title: 安装启动FastDFS报错
date: '2019-07-17 21:43:15'
updated: '2019-07-17 21:43:15'
tags: [FastDFS, 分布式存储]
permalink: /articles/2019/07/17/1563370995106.html
---
# 安装启动FastDFS报错

```bash
-- Unit fdfs_trackerd.service has begun starting up.
Nov 05 19:15:39 zsf_tra_ser fdfs_trackerd[2304]: file /etc/fdfs/tracker.conf does not exist!
Nov 05 19:15:39 zsf_tra_ser systemd[1]: fdfs_trackerd.service: control process exited, code=exited status=2
Nov 05 19:15:38 zsf_tra_ser systemd[1]: Reloading.
Nov 05 19:15:39 zsf_tra_ser polkitd[636]: Unregistered Authentication Agent for unix-process:2278:446669 (system bus name :1.57
Nov 05 19:15:39 zsf_tra_ser polkitd[636]: Registered Authentication Agent for unix-process:2298:446676 (system bus name :1.58 [
Nov 05 19:15:39 zsf_tra_ser systemd[1]: Cannot add dependency job for unit fdfs_trackerd.target, ignoring: Unit not found.
Nov 05 19:15:39 zsf_tra_ser systemd[1]: Starting LSB: FastDFS tracker server...
-- Subject: Unit fdfs_trackerd.service has begun start-up
-- Defined-By: systemd
-- Support: http://lists.freedesktop.org/mailman/listinfo/systemd-devel
-- 
-- Unit fdfs_trackerd.service has begun starting up.
Nov 05 19:15:39 zsf_tra_ser fdfs_trackerd[2304]: file /etc/fdfs/tracker.conf does not exist!
Nov 05 19:15:39 zsf_tra_ser systemd[1]: fdfs_trackerd.service: control process exited, code=exited status=2
Nov 05 19:15:39 zsf_tra_ser systemd[1]: Failed to start LSB: FastDFS tracker server.
-- Subject: Unit fdfs_trackerd.service has failed
-- Defined-By: systemd
-- Support: http://lists.freedesktop.org/mailman/listinfo/systemd-devel
-- 
-- Unit fdfs_trackerd.service has failed.
-- 
-- The result is failed.
Nov 05 19:15:39 zsf_tra_ser systemd[1]: Unit fdfs_trackerd.service entered failed state.
Nov 05 19:15:39 zsf_tra_ser systemd[1]: fdfs_trackerd.service failed.
Nov 05 19:15:39 zsf_tra_ser polkitd[636]: Unregistered Authentication Agent for unix-process:2298:446676 (system bus name :1.58
Nov 05 19:19:51 zsf_tra_ser polkitd[636]: Registered Authentication Agent for unix-process:2337:471908 (system bus name :1.59 [
Nov 05 19:19:51 zsf_tra_ser systemd[1]: Cannot add dependency job for unit fdfs_trackerd.target, ignoring: Unit not found.
Nov 05 19:19:51 zsf_tra_ser systemd[1]: Starting LSB: FastDFS tracker server...
-- Subject: Unit fdfs_trackerd.service has begun start-up
-- Defined-By: systemd
-- Support: http://lists.freedesktop.org/mailman/listinfo/systemd-devel
```
**分析：**
刚安装完启动fastdfs就报错，要么就是安装有问题，要么就是安装好之后需要更改什么内容
明显错误`Nov 05 19:15:39 zsf_tra_ser fdfs_trackerd[2304]: file /etc/fdfs/tracker.conf does not exist!`然后去看对应的有么有这个文件，进入到这个目录之后发现确实没有`tracker.conf`的文件，但是有一个`tracker.conf.sample`文件。看到这聪明的您肯定就知道改怎么解决这个报错了
**报错解决方法：**
`cp tracker.conf.sample tracker.conf`