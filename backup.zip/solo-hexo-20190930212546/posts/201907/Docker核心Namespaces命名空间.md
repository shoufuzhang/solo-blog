title: Docker核心-Namespaces（命名空间）
date: '2019-07-17 21:19:40'
updated: '2019-07-17 21:19:40'
tags: [Docker, NameSpaces]
permalink: /articles/2019/07/17/1563369580339.html
---
# Docker核心-Namespaces（命名空间）

**1）概念：**

命令空间是Linux内核的一个强大的特性。每个容器都有自己单独的命令空间，运行在其中的应用都是独立在操作系用中运行一样。命名空间保证了容器之间彼此互不影响。
`命名空间 (namespaces) `是 Linux 为我们提供的用于`分离进程树、网络接口、挂载点以及进程间通信`等资源的方法。在日常使用 Linux 或者 macOS 时，我们并没有运行多个完全分离的服务器的需要，但是如果我们在服务器上启动了多个服务，这些服务其实会相互影响的，每一个服务都能看到其他服务的进程，也可以访问宿主机器上的任意文件，这是很多时候我们都不愿意看到的，我们更希望运行在同一台机器上的不同服务能做到完全隔离，就像运行在多台不同的机器上一样。当我们其中一个服务被黑客入侵了，那么其他服务也会遭受这个黑客攻击。
linux默认的时候是不能同时启动两个80端口的`apache`和`nginx`，但是我们利用命令空间技术就可以实现，每个进程之间互不关联。

**2）Linux上有哪些命名空间**
> 1，PID Namespaces（PID 命名空间，CLONE_NEWPID）
>   不同用户登录的进程就是通过`PID Namespaces` 来隔开的，且每个`Namespaces` 中可以有 相同的PID。所有的`LXC`进程在Docker中的父进程为Docker进程，每个 LXC 进程具有不同的`Namespaces`。同时由于允许嵌套，因此可以很方便的实现嵌套的 Docker 容器；
> 
> 2，Net Namespaces（网络命名空间，CLONE_NEWNET）
> 有了Pid Namespaces，每个Namespaces中的PID能够相互隔离，但是 `network port`还是共享host的端口。网络隔离是通过 `Net Namespaces`空间实现的，每个Net Namespaces 有独立的网络设备，IP地址，路由表，/proc/net目录。这样每个container的网络就能个离开。Docker默认采用veth的方式，将容器中的虚拟网卡同host上的一个Docker网桥Docker0连接在一起；
> 
> 3，IPC Namespaces(，CLONE_NEWPID)
> continer中进程交互采用了Linux常见的进程交互方法（interprocess communication 进程间通信– IPC），包括信号量、消息队列和共享内存等；然后同VM不同的是：continer的进程（procession）间交互实际上还是host上具有相同PID名字空间中的进程间交互，因此需要在IPC资源申请时加入Namespaces信息，每个IPC资源有一个唯一的32位ID
> 
> 4, Mount Namespaces(挂载命令空间，CLONE_NEWNS)
> 类似于chroot，将一个进程放到一个特点的目录执行。mount Namespaces允许不同Namespaces的进程看到的文件结构不同，这样每个Namespaces中的进程所看到的文件目录就被隔离开了。和chroot不同的是，每个Namespaces的container在/proc/mounts的信息只包含所在的Namespaces的mount point（挂载点）；
> 
> 5，UTS Namespaces
> UTS（UNIX Time-sahring system），允许每个continer都拥有独立的`hostname`和`domain name`，使其在网络上可以被视作一个独立的节点而非主机上的一个进程。
> 
> 6，User Namespacer（用户命令空间）
> 每个continer可以有不同的用户和组ID，可就时可以说每个continer可以用自己内部的用户，不用依赖于宿主机

## 3，作用
用于容器之间的资源进程隔离的
