title: Jenkins 创建 Maven 项目
date: '2019-11-06 14:58:03'
updated: '2019-11-06 14:58:03'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573023483832.html
---
# Jenkins 创建 Maven 项目
## 什么是Maven？
Maven 是一个项目管理和综合工具。Maven 提供了开发人员构建一个完整的生命周期框架。 开发团队可以自动完成项目的基础工具建设，Maven 使用标准的目录结构和默认构建生命周 期。
Maven 简化和标准化项目建设过程。处理编译，分配，文档，团队协作和其他任务的无缝连 接。 Maven 增加可重用性并负责建立相关的任务。
Maven 项目的结构和内容在一个 XML 文件中声明，pom.xml 项目对象模型(POM)，这是整 个 Maven 系统的基本单元。用来管理项目的构建，相关性和文档。最强大的功能就是 能够自动下载项目依赖库。

## 安装Maven
把Maven安装在Jenkins的机器上，只有安装在这台机器上才能直接拉去代码之后立马就封装war包
1）因为我们是把maven安装在jenkins机器上我们就不需要在一次安装jdk了，如果没安装需要安装jdk

2）获取Maven安装文件
官网：      http://maven.apache.org/download.cgi
清华镜像:   https://mirrors.tuna.tsinghua.edu.cn/apache/maven/

```bash
[root@node_2_13 /]# cd /usr/local/
[root@node_2_13 local]# wget https://mirrors.tuna.tsinghua.edu.cn/apache/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz
```

3) 安装maven

```bash
[root@node_2_13 local]# tar xf apache-maven-3.3.9-bin.tar.gz 
[root@node_2_13 local]# ln -s apache-maven-3.3.9 maven
[root@node_2_13 local]# echo "export PATH=$PATH:/usr/local/maven/bin" >> /etc/profile
[root@node_2_13 local]# source  /etc/profile
```

4) 检查 maven 是否安装成功

```bash
[root@node_2_13 local]# mvn -v
Apache Maven 3.3.9 (bb52d8502b132ec0a5a3f4c09453c07478323dc5; 2015-11-11T00:41:47+08:00)
Maven home: /usr/local/maven
Java version: 1.8.0_121, vendor: Oracle Corporation
Java home: /usr/java/jdk1.8.0_121/jre
Default locale: en_US, platform encoding: UTF-8
OS name: "linux", version: "3.10.0-862.el7.x86_64", arch: "amd64", family: "unix"
```

## Maven的安装目录

```bash
[root@node_2_13 local]# tree maven/ -L 1
maven/
├── bin             // mvn的运行脚本，这些脚本用来配置java命令
├── boot            // 该目录只包含一个文件，该文件是一个类加载器框架，Maven使用该框架加载自己的类库
├── conf            // 该目录包含了一个非常重要的文件 settings.xml。用于全局定义 Maven 的行为，也可以将该文件复制到~/.m2目录下
├── lib             // 该目录包含了所有Maven运行时需要的java类库
├── LICENSE
├── NOTICE
└── README.txt
```

## 常用 Maven 命令

首先我们创建一个名为 [hello-world](https://pan.baidu.com/s/16_zdP5caaXNG2Dxzri-uzw) 的 Maven 项目，项目的目录结构如下
```bash
[root@node_2_13 ~]# ls 
anaconda-ks.cfg  hello-world.tar.gz  mavn
[root@node_2_13 ~]# tar xf hello-world.tar.gz 
[root@node_2_13 ~]# tree hello-world
hello-world
├── pom.xml
└── src
    ├── main
    │   └── java
    │       └── com
    │           └── juvenxu
    │               └── mvnbook
    │                   └── helloworld
    │                       └── HelloWorld.java
    └── test
        └── java
            └── com
                └── juvenxu
                    └── mvnbook
                        └── helloworld
                            └── HelloWorldTest.java
```
我们在此项目的基本上测试常用的 maven 命令，这些命令必须在`pom.xml`在同级里面执行
* mvn clean 命令用于清理项目生产的临时文件，一般是模块下的 target 目录
* mvn package 命令用于项目打包，会在模块下的 target 目录生成 jar 或者 war 等文件
* mvn test 命令用于测试，用于执行 src/test/java/下的测试用例，使用
` -Dmaven.test.skip=true `参数可以跳过测试。
* mvn install 命令用于模块安装，将打包好的 jar/war 文件复制到你的本地仓库中，供其他模 块使用

## Maven 仓库

在 Maven 中，任何一个依赖、插件或者项目构建的输出，都可以称之为构件。Maven 在某 个统一的位置存储所有项目的共享的构件，这个统一的位置，我们就称之为仓库。(仓库就 是存放依赖和插件的地方)任何的构件都有唯一的坐标，Maven 根据这个坐标定义了构件在 仓库中的唯一存储路径。
Maven 仓库分为两类:本地仓库和远程仓库。远程仓库又可以大致分为以下三类:中央仓库， 这是 Maven 核心自带的远程仓库，它包含了绝大部分开源的构件;私服是一种特殊的远程 仓库，一般是为了节省带宽和时间，在企业局域网内架设的一个私有仓库服务器(如 nexus) 用其代理所有外部的远程仓库，内部的项目还可以部署到私服上供其他项目使用;还有就是 其他的公开的远程仓库，常见的有 Java.net Maven 库、JBoss Maven 库等。 默认配置下，Maven 根据坐标寻找构件的时候，首先他会查看本地仓库，如果本地仓库存在， 则直接使用;如果本地仓库不存在，则 Maven 就会去远程仓库查找，存在则先下载到本地 仓库使用，不存在 Maven 就会报错。

### 本地仓库
顾名思义，就是 Maven 在本地存储构件的地方。maven 的本地仓库，在安装 maven 后并不 会创建，它是在第一次执行 maven 命令的时候才被创建。maven 本地仓库的默认位置:无 论是 Windows 还是 Linux，在用户的目录下都有一个.m2/repository/的仓库目录，这就是 Maven 仓库的默认位置。这个可以通过修改.m2/settings.xml 文件(不存在可以创建)或者 maven 安装目录/conf/settings.xml 进行配置。
在 settings.xml 文件中，设置 localRepository 元素的值为想的仓库地址即可 
```xml
<settings>
          <localRepository>/opt/maven_repository</localRepository>
</settings>
```
通过我们建议修改.m2 目录下的 setting.xml 文件，修改只针对用户。

### 远程仓库
说到远程仓库先从最核心的中央仓库开始，中央仓库是默认的远程仓库，maven 在安装的时 候，自带的就是中央仓库的配置，所有的 maven 项目都会继承超级 pom，具体的说，包含 了下面配置的 pom 我们就称之为超级 pom
```xml
<repositories>
    <repository>
        <id>central</id>
        <name>Central Repository</name> 
        <url>http://repo.maven.apache.org/maven2</url>
        <layout>default</layout>
        <snapshots>
            <enabled>false</enabled> 
        </snapshots>
    </repository> 
</repositories>
```
中央仓库包含了绝大多数流行的开源 Java 构件，以及源码、作者信息、SCM、信息、许可证 信息等。一般来说，简单的 Java 项目依赖的构件都可以在这里下载得到。

### 私服
私服是一种特殊的远程仓库，它是架设在局域网内的仓库服务，私服代理广域网上的远程仓 库，供局域网内的 Maven 用户使用。当 Maven 需要下载构件的时候，它从私服请求，如果 私服上不存在该构件，则从外部的远程仓库下载，缓存在私服上之后，再为 Maven 的下载 请求提供服务。我们还可以把一些无法从外部仓库下载到的构件上传到私服上。
Maven 私服的 个特性:
1.节省自己的外网带宽:减少重复请求造成的外网带宽消耗
2.加速 Maven 构件:如果项目配置了很多外部远程仓库的时候，构建速度就会大大降低 
3.部署第三方构件:有些构件无法从外部仓库获得的时候，我们可以把这些构件部署到内部 仓库(私服)中，供内部 maven 项目使用
4.提高稳定性，增强控制:Internet 不稳定的时候，maven 构建也会变的不稳定，一些私服 软件还提供了其他的功能
5.降低中央仓库的负荷:maven 中央仓库被请求的数量是巨大的，配置私服也可以大大降低 中央仓库的压力
当前主流的 maven 私服:1.Apache 的 Archiva、2.JFrog 的 Artifactory 3.Sonatype 的 Nexus

### 配置使用远程仓库
在平时的开发中，我们往往不会使用默认的中央仓库，默认的中央仓库访问的速度比较慢， 访问的人或许很多，有时候也无法满足我们项目的需求，可能项目需要的某些构件中央仓库 中是没有的，而在其他远程仓库中有，如 JBoss Maven 仓库。这时，可以在 pom.xml 中配置 该仓库，代码如下:

```xml
<!-- 配置远程仓库 --> 
<repositories>
    <repository> 
        <id>jboss</id>
        <name>JBoss Repository</name> 
        <url>http://repository.jboss.com/maven2/</url> 
    <releases>
        <enabled>true</enabled>
        <updatePolicy>daily</updatePolicy> 
    </releases>
    <snapshots>
        <enabled>false</enabled> 
        <checksumPolicy>warn</checksumPolicy>
    </snapshots>
    <layout>default</layout> 
    </repository>
</repositories>
```
* repository:在 repositories 元素下，可以使用 repository 子元素声明一个或者多个远程仓库。 
* id:仓库声明的唯一 id，尤其需要注意的是，Maven 自带的中央仓库使用的 id 为 central， 如果其他仓库声明也使用该 id，就会覆盖中央仓库的配置。
* name:仓库的名称，让我们直观方便的知道仓库是哪个，暂时没发现其他太大的含义。 
* url:指向了仓库的地址，一般来说，该地址都基于 http 协议，Maven 用户都可以在浏览器 中打开仓库地址浏览构件。
* releases 和 snapshots:用来控制 Maven 对于发布版构件和快照版构件的下载权限。需要注 意的是 enabled 子元素，该例中 releases 的 enabled 值为 true，表示开启 JBoss 仓库的发布版 本下载支持，而 snapshots 的 enabled 值为 false，表示关闭 JBoss 仓库的快照版本的下载支 持。根据该配置，Maven 只会从 JBoss 仓库下载发布版的构件，而不会下载快照版的构件。 
* layout:元素值 default 表示仓库的布局是 Maven2 及 Maven3 的默认布局，而不是 Maven1 的布局。基本不会用到 Maven1 的布局。
* 其他:对于 releases 和 snapshots 来说，除了 enabled，它们还包含另外两个子元素 updatePolicy 和 checksumPolicy。
* 元素 updatePolicy 用来配置 Maven 从远处仓库检查更新的频率，默认值是 daily，表示 Maven 每天检查一次。其他可用的值包括:never-从不检查更新;always-每次构建都检查更新; 
* interval:X-每隔 X 分钟检查一次更新(X 为任意整数)。
* 元素 checksumPolicy 用来配置 Maven 检查校验和文件的策略。当构建被部署到 Maven 仓库 中时，会同时部署对应的检验和文件。在下载构件的时候，Maven 会验证校验和文件，如果 校验和验证失败，当 checksumPolicy 的值为默认的 warn 时，Maven 会在执行构建时输出警 告信息，其他可用的值包括:fail-Maven 遇到校验和错误就让构建失败;ignore-使 Maven 完 全忽略校验和错误

### 利用 Nexus 搭建私有 Maven 库
#### Nexus 介绍
Nexus 是一个强大的 Maven 仓库管理器，它极大地简化了本地内部仓库的维护和外部仓库的 访问。
Nexus 在代理远程仓库的同时维护本地仓库，以降低中央仓库的负荷,节省外网带宽和时间。 Nexus 是一套“开箱即用”的系统不需要数据库，它使用文件系统加 Lucene 来组织数据。
Nexus 使用 ExtJS 来开发界面，利用 Restlet 来提供完整的 REST APIs，通过 m2eclipse 与 Eclipse 集成使用。
Nexus 支持 WebDAV 与 LDAP 安全身份认证。
Nexus 还提供了强大的仓库管理功能，构件搜索功能，它基于 REST，友好的 UI 是一个 extjs 的 REST 客户端，它占用较少的内存，基于简单文件系统而非数据库。

#### Nexus安装配置
1）下载安装JDK
2）下载nexus和安装
下载地址:https://www.sonatype.com/download-oss-sonatype
```bash
[root@node_1_12 ~]# cd /usr/local/
[root@node_1_12 local]# tar xf nexus-3.13.0-01-unix.tar.gz 
[root@node_1_12 local]# ln -s nexus-3.13.0-01 nexus
[root@node_1_12 local]# echo "export PATH=$PATH:/usr/local/nexus/bin" >> /etc/profile
[root@node_1_12 local]# source /etc/profile
```
3) 启动nexus

```bash
[root@node_1_12 local]# nexus start
WARNING: ************************************************************ WARNING: Detected execution as "root" user. This is NOT recommended! WARNING: ************************************************************ Starting nexus
[root@node_1_12 local]# nexus status
WARNING: ************************************************************ WARNING: Detected execution as "root" user. This is NOT recommended! WARNING: ************************************************************ nexus is running.
```

上面启动成功后会警告不要使用 root 用户启动，这里可以新建一个用户，也可以指定 root 用户启动，使他不出现警告，下面配置指定 root 用户启动,编辑 bin 目录下的 nexus.rc 文件，修改内容为:
run_as_user="root"

#### 配置Maven项目使用Nexus 私仓

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">

  <pluginGroups>
  </pluginGroups>
  <proxies>
  </proxies>
  <servers>
<server>   
    <id>my-nexus-releases</id>   
    <username>admin</username>   
    <password>admin123</password>   
  </server>   
  <server>   
    <id>my-nexus-snapshot</id>   
    <username>admin</username>   
    <password>admin123</password>   
  </server>
  </servers>
  <mirrors>
<mirror>
  <id>nexus</id>
  <mirrorOf>*</mirrorOf>
  <url>http://10.0.0.12:8081/repository/maven-public/</url>
</mirror>
  </mirrors>
  <profiles>
  </profiles>
<profile>
  <id>nexus</id>
  <repositories>
    <repository>
      <id>central</id>
      <url>http://10.0.0.12:8081/repository/maven-public/</url>
      <releases><enabled>true</enabled></releases>
      <snapshots><enabled>true</enabled></snapshots>
    </repository>
  </repositories>
 <pluginRepositories>
    <pluginRepository>
      <id>central</id>
      <url>http://10.0.0.12:8081/repository/maven-public/</url>
      <releases><enabled>true</enabled></releases>
      <snapshots><enabled>true</enabled></snapshots>
    </pluginRepository>
  </pluginRepositories>
</profile>
<activeProfiles>
  <activeProfile>nexus</activeProfile>
</activeProfiles>
</settings>
```
上述文件中有三处需要替换URL的地方，URL在nexus web界面上有显示
![image.png](https://img.hacpai.com/file/2019/11/image-e81fc032.png)

配置完成后，当我们再次执行 mvn 命令时，下载构件的地址变为我们的私服地址
![image.png](https://img.hacpai.com/file/2019/11/image-53061c3e.png)

我们的私服也缓存了相应的构件在本地
![image.png](https://img.hacpai.com/file/2019/11/image-97473229.png)


## 创建 Maven Job
1、在 Gitlab 创建一个 java 的代码仓库，我们把前面在命令使用的 helloword 项目初始化为一个git仓库，然后 push 到我们的 Gitlab 上(具体方法请参考前面相关内容)。
![image.png](https://img.hacpai.com/file/2019/11/image-c48dbe1e.png)

2、在 jenkins 配置 maven 
打开系统管理—>全局工具配置页面，下拉新增一个 maven 配置。
![image.png](https://img.hacpai.com/file/2019/11/image-0f73ad42.png)

3、新建一个maven的项目
![image.png](https://img.hacpai.com/file/2019/11/image-ba045940.png)
![image.png](https://img.hacpai.com/file/2019/11/image-11e72de6.png)


配置从gitlab仓库拉取源码
![image.png](https://img.hacpai.com/file/2019/11/image-06374e25.png)

配置要执行的 maven 命令，保存配置，返回 job 主页面，执行构建。
![image.png](https://img.hacpai.com/file/2019/11/image-421d275d.png)

在“工作空间”我们可以看到构建后的产物。
![image.png](https://img.hacpai.com/file/2019/11/image-472b059a.png)


### 错误
![image.png](https://img.hacpai.com/file/2019/11/image-c2f2f8bb.png)

提示找不到JDK，两种情况：1，要么你压根就没按照JDK，只需要安装一下就行

2，你安装过了JDK还是提示你这个信息，那么你就需要给JDK的家目录手工指定一下即可

```bash
[root@node_2_13 maven]# rpm -qa | grep jd
[root@node_2_13 maven]# rpm -ql jdk1.8.0_121
。。。。。。
/usr/java/jdk1.8.0_121/release
/usr/java/jdk1.8.0_121/src.zip
然后java的家目录在/usr/java/jdk1.8.0_121,然后去添加jdk家目录
```
![image.png](https://img.hacpai.com/file/2019/11/image-1aa80352.png)
![image.png](https://img.hacpai.com/file/2019/11/image-fe1e7d8b.png)
![image.png](https://img.hacpai.com/file/2019/11/image-d95366fe.png)


然后就好了