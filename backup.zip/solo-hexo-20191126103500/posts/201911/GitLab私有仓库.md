title: GitLab 私有仓库
date: '2019-11-06 14:44:33'
updated: '2019-11-06 14:44:33'
tags: [CI-CD]
permalink: /articles/2019/11/06/1573022673341.html
---
# GitLab 私有仓库
**[GitLab官方网站](https://about.gitlab.com/)**

## 安装GitLub
1）安装依赖关系

```bash
[root@zsf_node1 /]# yum install -y curl policycoreutils-python openssh-server
```
2）手动安装的方式安装GitLab
![image.png](https://img.hacpai.com/file/2019/11/image-984a2dcf.png)
![image.png](https://img.hacpai.com/file/2019/11/image-a096057d.png)

我们这边选择`10.2.2`的软件包



## 操作GitLab
### 关闭注册功能
![image.png](https://img.hacpai.com/file/2019/11/image-4dbde04a.png)
![image.png](https://img.hacpai.com/file/2019/11/image-a64ae2a0.png)

然后下拉保存，退出登录之后在查看
![image.png](https://img.hacpai.com/file/2019/11/image-02d4fbe8.png)
![image.png](https://img.hacpai.com/file/2019/11/image-b2bf4708.png)


可以自行上传两个图片观看两个图片所处的位置，然后点击`save`保存，保存之后点击`Preview last save`
![image.png](https://img.hacpai.com/file/2019/11/image-ff1da347.png)


### 创建用户组
![image.png](https://img.hacpai.com/file/2019/11/image-a34a112f.png)
![image.png](https://img.hacpai.com/file/2019/11/image-32a9dd2b.png)
![image.png](https://img.hacpai.com/file/2019/11/image-23ed0e6c.png)

咱们去这个地方看一下我们刚才创建的那个`group`组，
![image.png](https://img.hacpai.com/file/2019/11/image-3fc5ac86.png)
![image.png](https://img.hacpai.com/file/2019/11/image-7f2ce7db.png)


**添加用户到组**
![image.png](https://img.hacpai.com/file/2019/11/image-a6c03168.png)


### 创建仓库
![image.png](https://img.hacpai.com/file/2019/11/image-8fe998b6.png)


### 本地仓库和GitLab仓库连接
1）创建ssh秘钥，然后绑定在GitLab用户上，和GitHub操作一样
2) 创建一个远程仓库的连接，一个仓库可以建立多个远程仓库的连接

```bash
[root@zsf_node3 git_test]# git remote 
origin
[root@zsf_node3 git_test]# git remote add gitlab_origin git@10.0.0.11:test_directort/git_test.git
[root@zsf_node3 git_test]# git remote 
gitlab_origin
origin
```

3）推送内容

```bash
//推送这个所有分支里面的所有内容，可以把--all换成指定的分支名，只推送这一个分支
[root@zsf_node3 git_test]# git push -u gitlab_origin --all
//推送所有的tag标签
[root@zsf_node3 git_test]# git push -u gitlab_origin --tags
[root@zsf_node3 git_test]# 
```

### 设置保护分支（普通用户不能对这branch上push内容）
![image.png](https://img.hacpai.com/file/2019/11/image-28844c53.png)


### 普通用户提供合并申请
1）普通用户登录web页面
![image.png](https://img.hacpai.com/file/2019/11/image-bf81fa74.png)


2）选择一个项目，点击进入
![image.png](https://img.hacpai.com/file/2019/11/image-02420776.png)

3）填写申请
![image.png](https://img.hacpai.com/file/2019/11/image-202401a2.png)
![image.png](https://img.hacpai.com/file/2019/11/image-d6f610b2.png)

### 删除库
![image.png](https://img.hacpai.com/file/2019/11/image-692d396e.png)


### GitLab数据库备份
1) 在配置文件(/ect/gitlab/gitlab.rb)中加入
```bash
gitlab_rails['backup_path'] = '/data/backup/gitlab'
gitlab_rails['backup_keep_time'] = 604800				备份保留时间，单位s
```

2) Gitlab更改完配置文件需要使用下述命令重载
```bash
[root@zsf_node1 test]# gitlab-ctl reconfigure
```

3）自动创建备份目录，然后更改用户属组

```bash
[root@zsf_node1 test]# ll -d /data/backup/gitlab/
drwx------ 2 git root 6 Nov 12 19:31 /data/backup/gitlab/
[root@zsf_node1 test]# cd /data/backup/gitlab/
[root@zsf_node1 gitlab]# ll -d .
drwx------ 2 git root 6 Nov 12 19:31 .
```

4）执行备份命令

```bash
[root@zsf_node1 gitlab]# /usr/bin/gitlab-rake gitlab:backup:create    #执行备份命令
[root@zsf_node1 gitlab]# ls 
1542022523_2018_11_12_10.2.2_gitlab_backup.tar   #包括所有的库和文档
```

5）把备份加入定时任务

```bash
加入定时任务
0 2 * * * /usr/bin/gitlab-rake gitlab:backup:create &> /dev/null
```

### Gitlab数据恢复
1）停止数据写入
```bash
[root@zsf_node1 gitlab]# gitlab-ctl stop unicorn
ok: down: unicorn: 0s, normally up
[root@zsf_node1 gitlab]# gitlab-ctl stop sidekiq
ok: down: sidekiq: 1s, normally up
```

2）查看停止的状态

```bash
[root@zsf_node1 gitlab]# gitlab-ctl status 
run: gitaly: (pid 709) 42820s; run: log: (pid 708) 42820s
run: gitlab-monitor: (pid 700) 42820s; run: log: (pid 698) 42820s
run: gitlab-workhorse: (pid 714) 42820s; run: log: (pid 713) 42820s
run: logrotate: (pid 121977) 3219s; run: log: (pid 717) 42820s
run: nginx: (pid 701) 42820s; run: log: (pid 693) 42820s
run: node-exporter: (pid 704) 42820s; run: log: (pid 702) 42820s
run: postgres-exporter: (pid 718) 42820s; run: log: (pid 706) 42820s
run: postgresql: (pid 695) 42820s; run: log: (pid 691) 42820s
run: prometheus: (pid 716) 42820s; run: log: (pid 710) 42820s
run: redis: (pid 720) 42820s; run: log: (pid 707) 42820s
run: redis-exporter: (pid 712) 42820s; run: log: (pid 711) 42820s
down: sidekiq: 14s, normally up; run: log: (pid 694) 42820s
down: unicorn: 18s, normally up; run: log: (pid 705) 42820s
```

3）恢复数据重启服务

```bash
gitlab-rake gitlab:backup:restore BACKUP=1542022523_2018_11_12_10.2.2
// 如果遇到输入yes的一路yes下去
lgitlab-ctl restart
```