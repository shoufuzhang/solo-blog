title: GlusterFS快速安装
date: '2019-07-17 21:47:55'
updated: '2019-07-17 21:47:55'
tags: [分布式存储, GlusterFS]
permalink: /articles/2019/07/17/1563371275639.html
---
# GlusterFS快速安装
## 安装前准备
这边最少需要三台机器,所有机器关闭防火墙和Selinux,所有机器需要两块硬盘,

```bash
systemctl stop firewalld
systemctl disable firewalld
setenforce 0
sed -i "s#SELINUX=enforcing#SELINUX=disabled#g" /etc/selinux/config
```
添加hosts文件,其实通过IP地址也能做集群,但是不建议这种方式,因为我们通过域名你就是替换节点ip地址只要是域名不变,我们的glusterfs集群还能使用
```bash
cat >> /etc/hosts<<'EOF'
192.168.1.253 glusterfs01
192.168.1.238 glusterfs02
192.168.1.244 glusterfs03
EOF
```
格式化硬盘,我们这边采用/dev/sdb 这个硬盘

```bash
fdisk /dev/sdb
Command (m for help): n
Partition type:
   p   primary (1 primary, 0 extended, 3 free)
   e   extended
Select (default p): p
然后一路回车,创建磁盘分区
mkfs.xfs /dev/sdb1
创建挂载点:
mkdir -p /guiji
mount -t auto /dev/sdb1 /guiji
```

### 服务端和客户端最好有个ntp时间服务器,确保机器时间一致
搭建ntp时间服务器的教程,请[移动到这里](https://www.zhangshoufu.com/2018/10/17/ntp-wang-luo-shi-jian-fu-wu-qi-network-time-protoc/)
##安装Glusterfs 服务

添加安装源,如果不添加无法安装glusterfs-server

```bash
yum install centos-release-gluster
```
安装glusterfs服务

```bash
yum install -y glusterfs glusterfs-server glusterfs-fuse glusterfs-rdma glusterfs-geo-replication glusterfs-devel
```
启动glusterfs服务

```bash
systemctl start glusterd
systemctl enable glusterd
```

## 初始化集群
将节点加入到glusterfs集群中,需要到三台机器节点上都执行下面命令

```bash
gluster peer probe gluster01
gluster peer probe gluster02
gluster peer probe gluster03
```
注意如果没有配置hosts主机名这个地方是不能进行解析的,
在glusterfs01机器上查看gluster集群

```bash
[root@glusterfs01 gv0]# gluster peer  status
Number of Peers: 2

Hostname: glusterfs02
Uuid: 2ff8038e-bd5b-4dbe-a33e-6eb756314a50
State: Peer in Cluster (Connected)

Hostname: glusterfs03
Uuid: b77cd401-a8c3-4c5d-8ab7-e2a1ab72aac3
State: Peer in Cluster (Connected)
```

## 创建设置glusterfs volume
在三台机器上都创建如下目录
```bash
mkdir -p /guiji/pv1
```
然后在其中任何一台机器上执行下面这个命令

```bash
gluster volume create gv0 replica 3 glusterfs01:/guiji/pv1 glusterfs02:/guiji/pv1 glusterfs03:/guiji/pv1
gluster volume start gv0
```
注意: 这个地方默认是不可以直接使用挂载点开创建的,需要在挂载点下面创建子目录

查看确认卷已经启动

```bash
[root@glusterfs01 ~]# gluster volume info

Volume Name: gv0
Type: Replicate
Volume ID: 24650e7b-e14a-416d-a151-c2588a26e795
Status: Started
Snapshot Count: 0
Number of Bricks: 1 x 3 = 3
Transport-type: tcp
Bricks:
Brick1: glusterfs01:/guiji/gv0
Brick2: glusterfs02:/guiji/gv0
Brick3: glusterfs03:/guiji/gv0
Options Reconfigured:
transport.address-family: inet
nfs.disable: on
performance.client-io-threads: off
```
字段解读:

```bash
Volume Name:  创建的这个glusterfs卷的名称,客户端挂在的时候回使用到这个内容
Type: Replicate 存储的类型,这个为副本类型
status: 当前这个卷的状态
Number of Bricks: 存储的状态
```
查看状态
```bash
[root@glusterfs01 ~]# gluster volume status
Status of volume: gv0
Gluster process                             TCP Port  RDMA Port  Online  Pid
------------------------------------------------------------------------------
Brick glusterfs01:/guiji/gv0                49152     0          Y       20554
Brick glusterfs02:/guiji/gv0                49152     0          Y       19241
Brick glusterfs03:/guiji/gv0                49152     0          Y       19278
Self-heal Daemon on localhost               N/A       N/A        Y       20577
Self-heal Daemon on glusterfs03             N/A       N/A        Y       19301
Self-heal Daemon on glusterfs02             N/A       N/A        Y       19264

Task Status of Volume gv0
------------------------------------------------------------------------------
There are no active volume tasks
```
## 客户端挂在写入数据
安装软件,支持挂在glusterfs格式的文件
```bash
yum install centos-release-gluster -y
yum install -y glusterfs-6.0-1*   glusterfs-fuse-6.0-1*
```
在客户端也需要配置hosts解析

```bash
cat >> /etc/hosts<<'EOF'
192.168.1.253 glusterfs01
192.168.1.238 glusterfs02
192.168.1.244 glusterfs03
EOF
```
挂在glusterfs提供的目录

```bash
mount -t glusterfs glusterfs01:/gv0 /mnt
```
然后写入数据测试

```bash
touch  /mnt/{1..10}
```
然后去glusterfs上面检查文件存不存在,因该是存在的