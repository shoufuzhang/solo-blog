title: MFS 配置文件详解
date: '2019-07-17 21:33:37'
updated: '2019-07-17 21:33:37'
tags: [分布式存储, MFS]
permalink: /articles/2019/07/17/1563370417370.html
---
# 配置文件详解
## mfsmaster.cfg master主配置文件详解

```bash
#######运行选项######################
# WORKING_USER = mfs   #运行master守护进程的用户，默认是mfs
# WORKING_GROUP = mfs  #运行master守护进程的用户组，默认是mfs
# SYSLOG_IDENT = mfsmaster #要在syslog消息中放置的进程名称（默认为mfsmaster），消息默认是记录在/var/log/messages里
# LOCK_MEMORY = 0       #是否执行mlockall()以避免mfsmaster 进程溢出（默认为0)； 
# LIMIT_GLIBC_MALLOC_ARENAS = 4  #仅限于Linux：将malloc区域限制为给定值 - 防止服务器使用大量虚拟内存（默认为4）
# DISABLE_OOM_KILLER = 1 #仅限Linux：禁用内存killer（默认为1）
# NICE_LEVEL = -19       #运行守护进程的良好级别（默认为-19;注意：进程必须以root身份启动以提高优先级，如果优先级设置失败，进程保留开始的好水平）
# FILE_UMASK = 027       #为组和其他设置默认umask（用户始终为0，默认为027，块写入组并阻止所有其他）
# DATA_PATH = /usr/local/mfs-3.0.94/var/mfs #在哪里存储守护进程锁文件（默认为/usr/local/mfs-3.0.94/var/mfs）
# EXPORTS_FILENAME = /usr/local/mfs-3.0.94/etc/mfs/mfsexports.cfg #mfsexports.cfg文件的位置（默认为/usr/local/mfs-3.0.94/etc/mfs/mfsexports.cfg）
# TOPOLOGY_FILENAME = /usr/local/mfs-3.0.94/etc/mfs/mfstopology.cfg #mfstopology.cfg文件的位置（默认为/usr/local/mfs-3.0.94/etc/mfs/mfstopology.cfg）
# BACK_LOGS = 50         #元数据更改日志文件数（默认值为50），产生changelog.0.mfs-changelog.49.mfs,50个这样的日志文件用于存放元数据更改记录。
# METADATA_SAVE_FREQ = 1 #master多久会保存一次元数据，默认是1小时。
# BACK_META_KEEP_PREVIOUS = 1  #要保留的以前的元数据文件数（默认值为1），metadata.mfs.back.1留下一个这样的备份文件。
# CHANGELOG_PRESERVE_SECONDS = 1800 #在内存中必须保留多少秒的更改日志（默认为1800;这设置最小值，由于日志保存在5k块中，实际数量可能会更大一些;零会禁用额外的日志存储）
# MISSING_LOG_CAPACITY = 100000     #在主机中将存储多少个缺失的块（最多可分配 100*MISSING_LOG_CAPACITY 字节的内存）
#######命令连接选项#####################
# MATOML_LISTEN_HOST = *      #监听的IP地址，用于metalogger与masters间的连接，*表示任何。
# MATOML_LISTEN_PORT = 9419   #监听端口默认是9419，用于metalogger与masters间的连接
#######CHUNKSERVER连接选项###############
# MATOCS_LISTEN_HOST = *      #监听chunkservers连接的IP地址，默认是所有
# MATOCS_LISTEN_PORT = 9420   #监听端口默认是9420
# MATOCS_TIMEOUT = 10               #master-chunkserver连接的默认超时时间（默认为10秒）
# AUTH_CODE = mfspassword           #可选认证字符串。 定义时 - 只有具有相同AUTH_CODE的块服务器才允许连接到该主站。 当未定义（默认） - 然后所有chunkservers是允许的。如果要打开chunkserver身份验证，
#则首先在所有chunkserver中定义AUTH_CODE（并重新加载/重新启动它们），然后取消注释此选项并重新加载/重新启动master重新加载当前连接 chunkservers没有断开连接。 当chunkservers将进行新的连接时，将使用新的AUTH_CODE。
# REMAP_BITS = 24                   #可选IP类重映射。
# REMAP_SOURCE_IP_CLASS = 192.168.1.0
# REMAP_DESTINATION_IP_CLASS = 10.0.0.0
#######CHUNKSERVER工作选项##############
#REPLICATIONS_DELAY_INIT = 300           #开始复制前的初始延迟（秒）（默认为300）
# CHUNKS_LOOP_MAX_CPS = 100000           #Chunks循环不应该比每秒钟检查更多的块数（默认为100000）
# CHUNKS_LOOP_MIN_TIME = 300             #Chunks循环不应该在比给定的数字少的秒钟内完成（默认值为300）
# CHUNKS_SOFT_DEL_LIMIT = 10             #在一个chunk服务器上删除的最大块数（默认值为10）
# CHUNKS_HARD_DEL_LIMIT = 25             #在一个chunkserver上最多删除的块数（默认为25）
# CHUNKS_WRITE_REP_LIMIT = 2,1,1,4       #最大数量的块复制到一个chunkserver，第一个限制是比较危险的块(块只有一个副本)；第二个限制是undergoal块(块的拷贝数量低于指定的目标)；
#第三个限制是平衡与周围空间使用服务器之间的算术平均数；第四个限制是其他服务器之间的平衡(极低或极高的空间使用情况)；这里mfs官方建议是第一个数字大于等于第二，第二大于或等于第三，第四大于或等于第三，即(第一个限制 > = 第二个限制 > = 第三个限制< = 第四个限制)。
# CHUNKS_READ_REP_LIMIT = 10,5,2,5       #从一个chunkserver复制的最大块数（默认为10,5,2,5）一个数字等于四个相同数字，以冒号分隔，限制组与写入限制相同，数字之间的关系也应该相同 在写限制（1st> = 2nd> = 3rd <= 4th）
# CS_HEAVY_LOAD_THRESHOLD = 100          #chunkserver负载值默认100
# CS_HEAVY_LOAD_RATIO_THRESHOLD = 5.0    #chunkserver负荷阈值率(默认值为5.0,每当chunkserver负载比先前指定的阈值高并且这一比率高于平均负载,然后chunkserver切换到“grace(优雅)”模式)
# CS_HEAVY_LOAD_GRACE_PERIOD = 900       #定义chunkserver将在“grace”模式下保持多长时间（以秒为单位）
# ACCEPTABLE_PERCENTAGE_DIFFERENCE = 1.0 #chunkserver的空间使用量的最大差异百分比（默认值为1.0;有效值：0.1 - 10.0）
# PRIORITY_QUEUES_LENGTH = 1000000       #优先队列的长度(濒危,undergoal等块-应该首先处理块,默认值是1000000)。
# CS_MAINTENANCE_MODE_TIMEOUT = 0        #服务器可以处于维护模式的最大秒数（默认值为0 - 这意味着“永远”）。
# CS_TEMP_MAINTENANCE_MODE_TIMEOUT = 1800 #服务器可以处于“临时”维护模式的最大秒数（重新连接服务器自动切换回正常模式后，服务器切换到此模式，默认值为1800）
###########客户连接选项########################
# MATOCL_LISTEN_HOST = *                 #用于监听客户端（安装）连接的IP地址（*表示任何）
# MATOCL_LISTEN_PORT = 9421              #端口监听客户端（mount）连接（默认为9421）
###########客户工作选择########################
# SESSION_SUSTAIN_TIME = 86400           #维持断开的客户端会话的时间（以秒为单位;默认值为86400 = 1天）
# QUOTA_DEFAULT_GRACE_PERIOD = 604800    #软配额的默认宽限期（秒）（默认为604800 - 7天）不推荐使用：QUOTA TIME_LIMIT
# ATIME_MODE = 0                         
#修改模式（默认为0 - 访问期间始终修改atime）
#所有模式：
#0 - 始终修改文件，文件夹和符号链接的atime。
#1 - 始终修改atime，但仅在文件的情况下（在文件夹和符号链接的情况下不要修改atime）。
#2 - 仅在ctime或mtime低于当前时间高于ctime或mtime时修改atime，当前atime早于24h时，修改atime。 在访问期间对所有对象进行操作（如Linux中的“relatime”选项）。
#3 - 与上述相同但仅在文件的情况下。 如果文件夹和符号链接不能修改atime。
#4 - 在访问期间不要修改atime（如“noatime”选项）。
```

## mfsexports.cfg 配置文件详解

```bash
# cat /usr/local/mfs/etc/mfs/mfsexports.cfg  #这里就跟NFS的/etc/exports文件类似，就是允许让哪些客户端来进行挂载

一行的格式：[ip range] [path] [options]

ip范围:

*：表示任何ip（与0.0.0.0/0相同）

A.B.C.D：表示单个IP

A.B.C.D-E.F.G.H : IP地址范围

A.B.C.D / XX：A.B.C.D网络和子网掩码

A.B.C.D/E.F.G.H ： A.B.C.D网络与E.F.G.H网络掩码
path:

. ：特殊的“路径",意思是“元”

/...：路径在mfs结构

options:

ro/rw/readonly/readwrite：从字面意思就可以看出来只读/读写/只读/读写

alldirs：任何子目录都可以以root身份加载

dynamicip：ip仅在第一次身份验证期间进行测试，则客户端可以使用来自任何ip的相同会话ID

ignoregid：组ID（gid）

admin：管理权限 - 当前：允许操纵配额值

maproot=UID[:GID]：将所有根（uid零）操作视为用户执行的操作，其中uid等于UID，gid等于GID（如果GID未指定，则为该用户的默认gid）

mapall=UID[:GID}：如上所述，对于所有操作（对于这两个选项，UID和/或GID可以指定为主机上存在的用户名或组名）

password=TEXT：强制认证使用给定的密码

md5pass=MD5：如上所述，但是密码被定义为MD5哈希（MD5指定为128位十六进制数）

minversion=VER：仅允许版本号等于或大于VER的客户端（VER可以指定为X或X.Y或X.Y.Z）

mingoal=N : 不允许将目标设定在N以下（N应该是从'1'到'9'的数字）

maxgoal=N：不允许将目标设定在N（N以上）

mintrashtime=TIMEDURATION：不要将垃圾时间设置在TIME DURATION之下（时间DURATION可以按照设定顺序指定秒数或元素＃W，＃D，＃H，＃M，＃S的组合）

maxtrashtime=TIMEDURATION：不允许设置超过TIMEDURATION的时间（TIMEDURATION可以指定如上）

默认值：

readonly,maproot=999:999,mingoal=1,maxgoal=9,mintrashtime=0,maxtrashtime=4294967295
```

## mfsmetalogger.cfg 配置文件详解

```bash
###########运行选项############################
# WORKING_USER = mfs
# WORKING_GROUP = mfs
# SYSLOG_IDENT = mfsmetalogger    #要在syslog消息中放置的进程名称（默认为mfsmetalogger）
# LOCK_MEMORY = 0                 
# LIMIT_GLIBC_MALLOC_ARENAS = 4
# DISABLE_OOM_KILLER = 1
# NICE_LEVEL = -19
# FILE_UMASK = 027
# DATA_PATH = /usr/local/mfs-3.0.94/var/mfs
# BACK_LOGS = 50
# BACK_META_KEEP_PREVIOUS = 3      #要保留的以前的元数据文件数（默认为3），metadata_ml.mfs.back.1-metadata_ml.mfs.back.3留下三个这样的备份文件。
# META_DOWNLOAD_FREQ = 24          #元数据下载频率以小时为单位（默认为24，应至少为BACK_LOGS/2）。注意这里是要修改的一般改为1.
META_DOWNLOAD_FREQ = 1
##########MASTER连接选项######################
# MASTER_RECONNECTION_DELAY = 5    #如果未连接，则在下次尝试重新连接到主机之前延迟秒（默认为5）
# BIND_HOST = *                    #用于与主机连接的本地地址（默认为*，即默认本地地址）
# MASTER_HOST = mfsmaster          #MooseFS主机，只允许在单主机安装中使用IP（默认为mfsmaster），这里也是需要修改的地方。
# MASTER_PORT = 9419               #master的端口
# MASTER_TIMEOUT = 10              #与master连接的超时时间，默认是10秒钟
```

## mfschunkserver.cfg配置文件详解

```bash
##########运行选项###########################
# WORKING_USER = mfs
# WORKING_GROUP = mfs
# SYSLOG_IDENT = mfschunkserver  #在syslog消息中放置的进程名称（默认为mfschunkserver）
# LOCK_MEMORY = 0
# LIMIT_GLIBC_MALLOC_ARENAS = 4
# DISABLE_OOM_KILLER = 1
# NICE_LEVEL = -19
# FILE_UMASK = 027
# DATA_PATH = /usr/local/mfs-3.0.94/var/mfs  #在哪里存储守护进程锁文件（默认为/usr/local/mfs-3.0.94/var/mfs）
# HDD_CONF_FILENAME = /usr/local/mfs-3.0.94/etc/mfs/mfshdd.cfg  #mfshdd.cfg文件位置，分配给MFS磁盘空间的配置文件的位置
# HDD_TEST_FREQ = 10  #块测试周期（默认值为10秒）
# HDD_LEAVE_SPACE_DEFAULT = 256MiB       #每个硬盘驱动器上应该留下多少空间（默认值：256MiB）
# HDD_REBALANCE_UTILIZATION = 20         #批量服务器允许在hdd空间重新平衡上花费的总工作时间的百分比
# HDD_ERROR_TOLERANCE_COUNT = 2          #在单个硬盘驱动器上以给定的秒数（PERIOD）容许多少个I/O错误（COUNT);如果错误数量超过此设置，则有害的硬盘驱动器将被标记为损坏
# HDD_ERROR_TOLERANCE_PERIOD = 600
# HDD_FSYNC_BEFORE_CLOSE = 0             #在chunk关闭前启用/禁用fsync
# HDD_SPARSIFY_ON_WRITE = 1              #在写入期间启用/禁用sparsification（跳过零）
# WORKERS_MAX = 250                      #最大的活跃会话数
# WORKERS_MAX_IDLE = 40                  #最大的空闲会话数
###########与master连接选项#################
# LABELS =                               #标签字符串（默认为空 - 无标签）
# BIND_HOST = *                          #用于master连接的本地地址（默认为*，即默认本地地址）
# MASTER_HOST = mfsmaster                #MooseFS主机，只允许在单主机安装中使用IP（默认为mfsmaster）。这里是要修改的地方。
# MASTER_PORT = 9420                     #与master端连接的端口
# MASTER_TIMEOUT = 10                    #与master连接的超时时间（默认为10秒）
# MASTER_RECONNECTION_DELAY = 5          #如果未连接，则在下次尝试重新连接到主机之前延迟秒（默认为5）
# AUTH_CODE = mfspassword                #authentication字符串（仅当master需要授权时才使用）
##########客户端连接选项####################
# CSSERV_LISTEN_HOST = *                 #IP地址来监听客户端（挂载）连接（*表示任何）
# CSSERV_LISTEN_PORT = 9422              #端口监听客户端（mount）连接（默认为9422）
```

## fsmshdd.cfg 配置文件详解

```bash
该文件保留硬盘驱动器的安装点（路径）的定义以与块服务器一起使用。

一个路径可以从多个字符开始，这些字符可以切换其他选项：

*：表示这个硬盘被标记为删除，所有数据将被复制到其他硬盘驱动器（通常在其他chunkserver上）

<：表示来自此硬盘驱动器的所有数据都应该移动到其他硬盘驱动器

>：表示来自其他硬盘驱动器的所有数据都应移动到该硬盘驱动器

〜：表示总计数的重大变化不会将此驱动器标记为损坏

如果同时使用“<”和“>”驱动器，那么只能在这些驱动器之间移动数据

可以指定可选的空间限制（在每个安装点之后），有两种方法：

将空间设置为在硬盘驱动器上未使用（这覆盖了mfschunkserver.cfg的默认设置）

限制在硬盘上使用的空间，如：/mnt/hd4 -5GiB或/mnt/hd4 1.5TiB
```

## mfsmount.cfg 挂载文件

```bash
#可选的mfsmount.cfg文件可用于指定mfsmount的默认值。 默认安装选项可以在一行以逗号分隔或多行指定。如（下面一看就能明白就不解释了）：
# nosuid,nodev
# mfsmaster=mfsmaster    
# mfspassword=secret    #主要是这里，如果master设置了挂载密码，如果你这里不设置就要手工输了，然后如果客户端想开机自动挂载就需要在这里设置密码了。
#默认安装点也可以设置。 默认安装点必须以“/”开头，并且是一个完全限定的路径。如：
# /mnt/mfs
```