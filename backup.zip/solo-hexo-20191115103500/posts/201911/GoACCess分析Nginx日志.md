title: GoACCess 分析Nginx日志
date: '2019-11-07 13:59:57'
updated: '2019-11-07 13:59:57'
tags: [Nginx]
permalink: /articles/2019/11/07/1573106397586.html
---
# GoACCess 分析Nginx日志
## 叙述
GoAccess 是一款开源(MIT许可证)的且具有交互视图界面的实时 Web 日志分析工具，通过你的 Web 浏览器或者 *nix 系统下的终端程序即可访问。

能为系统管理员提供快速且有价值的 HTTP 统计，并以在线可视化服务器的方式呈现。 GoAccess 解析指定的 Web 日志文件并将统计结果输出到 X 终端。功能如下：

* **通用统计:** 此面板展示了几个主要指标，比如：有效和无效请求的数量，分析这些数据所花费的时间，独立访客的情况，请求的文件，静态文件(CSS, ICO, JPG 等)的完整URL，404错误，被解析的日志文件的大小以及消耗的带宽。
* **独立访客:** 此面板按照日期展示了访问次数，独立访客数，以及累计消耗的带宽等指标。具有相同IP，相同访问时间，相同的 UserAgent 的 HTTP 请求将会被识别为独立访客。默认情况下包含了网络爬虫。
您也可以选择使用 --date-spec=hr 参数将按照日期分析修改为按照小时，例如：05/Jun/2016:16 。这对于希望在小时级别去跟踪每日流量非常有帮助。
请求的文件: 此面板展示您服务器上被请求次数最多的文件。包含访问次数，独立访客数，百分比，累计消耗带宽，使用的协议，请求方式。
* **请求的静态文件:** 列出请求频率最高的静态文件类型，例如： JPG, CSS, SWF, JS, GIF, 和 PNG , 以及和上一个面板一样的其他指标。 另外静态文件可以被添加到配置文件中。
404 或者文件未找到: 展示内容与之前的面板类似，但是其数据包含了所有未找到的页面，以及俗称的 404 状态码。
* **主机:** 此面板展示主机自身的详细信息。能够很好的发现不怀好意的爬虫以及识别出是谁吃掉了你的带宽。
扩展面板将向您展示更多信息，比如主机的反向DNS解析结果，主机所在国家和城市。如果开启了 参数，选择想查看的 IP 地址并按回车，将会显示 UserAgent 列表。
* **操作系统:** 此面板将显示主机使用的操作系统的信息。GoAccess 将尽可能尝试为每一款操作系统提供详细的信息。
浏览器: 此面板将显示来访主机使用的浏览器信息。GoAccess 将尽可能尝试为每一款浏览器提供详细的信息。
* **访问次数:** 此面板按小时报告。因此将显示24个数据点，每一个均对应每一天的某一个小时。
使用 --hour-spec=min 参数可以设定为按每十分钟报告，并将以 16:4 的格式显示时间。这对发现服务器的峰值访问时段很有帮助。
* **虚拟主机:** 此面板将显示从访问日志中解析出来的不同的虚拟主机的情况。此面板仅在日志格式中启用了 %v 参数时显示。
* **来路URL:** 如果问题主机通过其他的资源访问了你的站点，以及通过从其他主机上的链接或者跳转到你的站点，则这些来路URL将会被显示在此面板。可以在配置文件中通过 `--ignore-panel` 开启此功能。(默认关闭)
* **来路站点:** 此面板将仅显示主机的部分，而不是完整的URL。
关键字: 报告支持用在谷歌搜索，谷歌缓存，谷歌翻译上使用关键字。目前仅支持通过 HTTP 使用谷歌搜索。 可以在配置文件中通过 `--ignore-panel` 开启此功能。(默认关闭)
* **地理位置:** 根据 IP 地址判断地理位置。统计数据按照大洲和国家分组。需要地理位置模块的支持。
* **HTTP 状态码:** 以数字表示的 HTTP 请求的状态编码。
* **远程用户(HTTP验证)** 通过 HTTP 验证来确定访问文档的权限。如果文档没有被密码保护起来，这部分将会显示为 “-”。此面板默认为开启，除非在日志格式变量中设置了参数 %e 。

## 存储
GoAccess 支持三种类型的存储方式。请根据你的需要和系统环境进行选择。

### 默认哈希表
内存哈希表可以提供较好的性能，缺点是数据集的大小受限于物理内存的大小。GoAccess 默认使用内存哈希表。如果你的内存可以装下你的数据集，那么这种模式的表现非常棒。此模式具有非常好的内存利用率和性能表现。
### Tokyo Cabinet 磁盘 B+ 树
使用这种模式来处理巨大的数据集，大到不可能在内存中完成任务。当数据提交到磁盘以后，B+树数据库比任何一种哈希数据库都要慢。但是，使用 SSD 可以极大的提高性能。往后您可能需要快速载入保存的数据，那么这种方式就可以被使用。
### Tokyo Cabinet 内存哈希表
作为默认哈希表的替换方案。因为使用通用类型在内存表现以及速度方面都很平均。

## 配置
GoAccess 拥有多个配置选项。获取完整的最新配置选项列表，请运行：./configure --help

--enable-debug
使用调试标志编译且关闭编译器优化。
--enable-utf8
宽字符支持。依赖 Ncursesw 模块。
--enable-geoip=<legacy|mmdb>
地理位置支持。依赖 MaxMind GeoIP 模块。 legacy 将使用原始 GeoIP 数据库。 mmdb 将使用增强版 GeoIP2 数据库。
--enable-tcb=<memhash|btree>
Tokyo Cabinet 存储支持。 memhash 将使用 Tokyo Cabinet 的内存哈希数据库。btree 将使用 Tokyo Cabinet 的磁盘 B+Tree 数据库。
--disable-zlib
禁止在 B+Tree 数据库上使用 zlib 压缩。
--disable-bzip
禁止在 B+Tree 数据库上使用 bzip2 压缩。
--with-getline
使用动态扩展行缓冲区用来解析完整的行请求，否则将使用固定大小(4096)的缓冲区。
--with-openssl
使 GoAccess 与其 WebSocket 服务器之间的通信能够支持 OpenSSL。

## 安装
centos 安装

```bash
#配置好epel源
yum -y install goaccess
```
### 更改goaccess的配置
/ect/goaccess.conf
```bash
1.配置文件修改
[root@abcdocker ~]# vim /ect/goaccess.conf
time-format %H:%M:%S
date-format %d/%b/%Y
log-format %h %^[%d:%t %^] "%r" %s %b "%R" "%u"


2.配置文件参数说明
%x 匹配 time-format 和 date-format 变量的日期和时间字段。用于使用时间戳来代替日期和时间两个独立变量的场景。
%t 匹配 time-format 变量的时间字段。
%d 匹配 date-format 变量的日期字段。
%v 根据 canonical 名称设定的服务器名称(服务区或者虚拟主机)。
%e 请求文档时由 HTTP 验证决定的用户 ID。
%h 主机(客户端IP地址，IPv4 或者 IPv6)。
%r 客户端请求的行数。这些请求使用分隔符(单引号，双引号)引用的部分可以被解析。否则，需要使用由特殊格式说明符(例如：%m, %U, %q 和 %H)组合格式去解析独立的字段。
注意: 既可以使用 %r 获取完整的请求，也可以使用 %m, %U, %q and %H 去组合你的请求，但是不能同时使用。
%m 请求的方法。
%U 请求的 URL。
注意: 如果查询字符串在 %U中，则无需使用 %q。但是，如果 URL 路径中没有包含任何查询字符串，则你可以使用 %q 查询字符串将附加在请求后面。
%q 查询字符串。
%H 请求协议。
%s 服务器回传客户端的状态码。
%b 回传客户端的对象的大小。
%R HTTP 请求的 "Referer" 值。
%u HTTP 请求的 "UserAgent" 值。
%D 处理请求的时间消耗，使用微秒计算。
%T 处理请求的时间消耗，使用带秒和毫秒计算。
%L 处理请求的时间消耗，使用十进制数表示的毫秒计算。
%^ 忽略此字段。
%~ 继续解析日志字符串直到找到一个非空字符(!isspace)。
~h 在 X-Forwarded-For (XFF) 字段中的主机(客户端 IP 地址，IPv4 或者 IPv6)。
```
### Nginx配置

为了提供Goaccess分析精准度，需要配置Nginx的log_format

```bash
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_cookie" "$http_referer" '
                       '"$http_user_agent" "$http_x_forwarded_for"';
access_log  logs/access_web.log  main;

#在http标签配置的，默认就有开启就ok
```

##GoAccess 显示
### GoAccess 控制台模式

```bash
goaccess -a -d -f /var/log/nginx/access.log -p /etc/goaccess.conf 

常用参数：
#常用参数
-a --agent-list 启用由主机用户代理的列表。为了更快的解析，不启用该项
-d --with-output-resolver 在HTML/JSON输出中开启IP解析，会使用GeoIP来进行IP解析
-f --log-file 需要分析的日志文件路径
-p --config-file 配置文件路径
-o --output 输出格式，支持html、json、csv
-m --with-mouse 控制面板支持鼠标点击
-q --no-query-string 忽略请求的参数部分
--real-time-html 实时生成HTML报告
--daemonize 守护进程模式，--real-time-html时使用
```
控制台操作方法

```bash
F1   主帮助页面
F5   重绘主窗口
q    退出
1-15 跳转到对应编号的模块位置 
o    打开当前模块的详细视图
j    当前模块向下滚动
k    当前模块向上滚动
s    对模块排序
/    在所有模块中搜索匹配
n    查找下一个出现的位置
g    移动到第一个模块顶部
G    移动到最后一个模块底部
```
![image.png](https://img.hacpai.com/file/2019/11/image-a32e85d4.png)


### GoAccess HTML模式

```bash
goaccess -a -d -f /var/log/nginx/access.log -p /etc/goaccess.conf -o /var/log/nginx/html/go-access.html
```

我们需要给这个日志放到nginx里面展示出去
![image.png](https://img.hacpai.com/file/2019/11/image-c1a2474f.png)

#GoAccess Daemonize
GoAccess可以使用daemonize模式运行，并提供创建实时HTML的功能，只需要在启动命令后添加--real-time-html和--daemonize参数即可

```bash
goaccess -a -d -f /var/log/nginx/access.log -p /etc/goaccess.conf -o /var/log/nginx/html/go-access.html --real-time-html --daemonize
```

## 日志切割
日志切割后可以使用`--keep-db-file`来读取新的日志文件