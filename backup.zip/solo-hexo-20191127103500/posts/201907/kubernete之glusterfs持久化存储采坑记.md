title: kubernete之glusterfs 持久化存储采坑记
date: '2019-07-19 17:41:50'
updated: '2019-07-19 17:41:50'
tags: [kubernetes, kubernetes数据持久化, GlusterFS]
permalink: /articles/2019/07/19/1563529310681.html
---
# kubernete之glusterfs 持久化存储采坑记
## 安装glusterfs
如果你对glusterfs不熟悉可以看这个地方:[GlusterFS快速安装](https://www.zhangshoufu.com/tags/GlusterFS)
```bash
# 在每个节点上创建目录
mkdir -p /guiji/volume
# 创建glusterfs卷
gluster volume create k8s-volume replica 3 192.168.1.253:/guiji/volume
192.168.1.238:/guiji/volume 192.168.1.244:/guiji/volume

# 启动这个卷
gluster volume start k8s-volume

# 停止ctime
gluster volume set k8s-volume ctime off

```
## 在每个k8s集群节点上开启dm_thin_pool内核模块

```bash
modprobe dm_thin_pool
```
## 创建EndPoint (k8s集群内部访问外部的集群)

```yaml
---
kind: Endpoints
apiVersion: v1
metadata:
  name: glusterfs-cluster   #这个名字必须要和svc的名称一样
subsets:
- addresses:
  - ip: 192.168.1.253
  ports:
  - port: 1000
- addresses:
  - ip: 192.168.1.238
  ports:
  - port: 1000
- addresses:
  - ip: 192.168.1.244
  ports:
  - port: 1000
```
这个里面的port端口可以随便设置,默认是1,你可以随意设置,

创建一个svc
```yaml
---

kind: Service
apiVersion: v1
metadata:
  name: glusterfs-cluster   #这个必须要和EndPoint一样
spec:
  ports:
  - port: 1000
```

创建一个测试pod,看看挂载是否成功
```yaml
---
apiVersion: v1
kind: Pod
metadata:
  name: glusterfs-test
spec:
  containers:
  - name: glusterfs-test
    image: nginx
    volumeMounts:
    - mountPath: "/mnt/glusterfs"
      name: glusterfsvol
  volumes:
  - name: glusterfsvol
    glusterfs:
      endpoints: glusterfs-cluster
      path: k8s-volume
      readOnly: false
```

## pv and pvc
创建一个pv
```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: gluster-nginx-pv
  labels:
    pv: gluster-volume
spec:
  capacity:
    storage: 10Gi
  accessModes:
  - ReadWriteMany
  glusterfs:
    endpoints: glusterfs-cluster
    path: k8s-volume
    readOnly: false

```

创建一个pvc
```yaml
---
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: gluster-nginx-pvc
spec:
  selector:
    matchLabels:
      pv: gluster-volume
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 10Gi
```
 创建个pod引用
 
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx-test-glutser-pv
spec:
  containers:
  - name: nginx-test-glutser-pv
    image: nginx:1.14.1
    volumeMounts:
    - name: gluster-volume
      mountPath: /var/www/html
  volumes:
  - name: gluster-volume
    persistentVolumeClaim:
      claimName: gluster-nginx-pvc
```
