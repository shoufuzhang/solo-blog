title: Ansible 条件选择
date: '2019-07-19 18:05:01'
updated: '2019-07-19 18:05:01'
tags: [Ansible]
permalink: /articles/2019/07/19/1563530701155.html
---
# Ansible 条件选择
## when 判断语句
在我们批量推送配置文件或者什么时候，我们可能需要期中某一台或者有相同特征的某几台主机不推送配置文件，或者某个特定的主机跳过某个模块，这些操作我们就需要利用`when`模块来完成此操作

```yaml
[root@master_11 playbook]# cat z8.yaml 
- hosts: all
  gather_facts: true
  tasks:
    - name: Create files except the host name is node3
      file: name=/tmp/{{ ansible_hostname }} state=touch
      when: ansible_hostname != "node_1_13"
```

**执行结果：**

```yaml
[root@master_11 playbook]# ansible-playbook z8.yaml 

PLAY [all] ***********************************************************************

TASK [Gathering Facts] ***********************************************************
ok: [10.0.0.12]
ok: [10.0.0.13]

TASK [Create files except the host name is node3] ********************************
skipping: [10.0.0.13]
changed: [10.0.0.12]

PLAY RECAP ***********************************************************************
10.0.0.12                  : ok=2    changed=1    unreachable=0    failed=0   
10.0.0.13                  : ok=1    changed=0    unreachable=0    failed=0   
```
从执行结果可以看出他把 node3这台主机跳过了，没有创建文件


## when使用正则判断匹配
```yaml
- hosts: all
  gather_facts: true
  tasks:
    - name: Create files except the host name is node3
      file: name=/tmp/{{ ansible_hostname }} state=touch
      when: ansible_hostname|regex_search('(^[^n])')
```
when可以使用`regex_search`正则过滤器来完成，语法：`字符串|regex_search('(正则条件)')`

## when 可以利用布尔值来确定上述任务是否成功

```bash
[root@master_11 playbook]# cat z8.yaml 
- hosts: node3
  gather_facts: true
  vars:
    epic: true

  tasks:
    - shell: echo "shell sucess"
      when: epic

    - shell: echo "shell error"
      when: not epic    
```